import Vue from 'vue'
import Router from 'vue-router'

import Login from "../views/Login";
import Content from "../components/Content";

//安装路由
Vue.use(Router);

export default new Router({
  routes: [
    {
      //路由路径
      path: '/login',
      //跳转的组件
      component: Login
    },
    {
      //路由路径
      path: '/content',
      name: 'Content',
      //跳转的组件
      component: Content
    }
  ]
});
