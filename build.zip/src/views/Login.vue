<template>
  <div class="login-wrap">
    <div class="ms-login">
      <div class="ms-title">活动配置后台管理系统</div>
      <el-form :model="loginForm" :rules="rules" ref="loginForm" label-width="0px" class="ms-content">
        <el-form-item prop="adminName">
          <el-input v-model="loginForm.adminName" placeholder="请输入账号">
            <el-button slot="prepend" icon="el-icon-user"></el-button>
          </el-input>
        </el-form-item>
        <el-form-item prop="password">
          <el-input type="password" v-model="loginForm.password" placeholder="请输入密码" show-password>
            <el-button slot="prepend" icon="el-icon-lock"></el-button>
          </el-input>
        </el-form-item>
        <el-form-item prop="code">
          <el-input v-model="loginForm.code" placeholder="请输入验证码">
            <el-button slot="append" :disabled="canClick" @click="getCode">{{btnText}}</el-button>
          </el-input>
        </el-form-item>
        <div class="login-btn"><el-button type="primary" @click="submitForm()">登录</el-button></div>
      </el-form>
    </div>
  </div>

</template>

<script>
import login from '../api/user'
    export default {
      data: function() {
        return {
          timmer: null,
          btnText: '获取验证码',
          canClick: false,
          countdown: 60,
          loginForm: {
            adminName: '',
            password: '',
            code: ''
          },
          rules: {
            adminName: [{ required: true, message: '请输入移动号码', trigger: 'change' },
              {pattern:/^1\d{10}$/,message: '请输入正确的用户移动手机号', trigger: 'change'}
              // {pattern:/^1\d{10}$/,message: '请输入正确的用户移动手机号', trigger: 'change'}
            ],
            password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
            code: [{ required: true, message: '请输入验证码', trigger: 'blur' },
              {pattern:/^\d{6}$/,message: '请输入正确的验证码', trigger: 'change'}]
          }
        };
      },
      methods: {
        submitForm() {
          let that = this;
          that.$refs.loginForm.validate((valid) => {
            if (valid) {
              login(that.loginForm).then(res=>{
                if (res.flag) {
                  that.$store.dispatch("setUserInfo",{adminName:that.loginForm.adminName})
                  that.$message({
                    type: 'success',
                    message: '登录成功'
                  });
                  sessionStorage.setItem('n',this.loginForm.adminName)
                  that.$router.push({path:"/activity/index"});
                } else {
                  this.$message({
                    type: 'error',
                    message: `${res.message}`
                  });
                }
              }).catch(err=>{
                console.log(err)
              })
            } else {
              // this.$message.error('请输入账号和密码');
              console.log('error submit!!');
              return false;
            }
          });
        }
      }


    }
</script>


<style scoped>

  .ms-title {
    width: 100%;
    line-height: 50px;
    text-align: center;
    font-size: 20px;
    color: #fff;
    border-bottom: 1px solid #ccc9dd;
  }
  .ms-login {
    position: absolute;
    left: 50%;
    top: 50%;
    width: 350px;
    margin: -190px 0 0 -175px;
    border-radius: 5px;
    background: rgba(255, 255, 255, 0.3);
    overflow: hidden;
  }
  .ms-content {
    padding: 30px 30px;
  }
  .login-btn {
    text-align: center;
  }
  .login-btn button {
    width: 100%;
    height: 36px;
    margin-bottom: 10px;
  }
</style>
