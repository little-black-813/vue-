import request from '../utils/axios'

export const login = params => request({
  url:`/data/user/login`,
  data:params,
  method:'post'
});

