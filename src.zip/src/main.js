import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import './plugins/element.js'
import clipboard from 'vue-clipboard2';
import  'element-ui/lib/theme-chalk/index.css'
import './assets/css/icon.css';
Vue.config.productionTip = false
Vue.use(clipboard)

const whitRoute = ['Login'];

router.beforeEach((to, from, next) => {
   // next() // 已登录
  //  console.log(sessionStorage.getItem('n'))
   if(whitRoute.indexOf(to.name)>-1){
     console.log('---')
   	next();
   }else{
    //  console.log(sessionStorage.getItem('n'))
   	if (sessionStorage.getItem('n')) {
    	 next() // 已登录
  	 }else{
  	 	next('/login');
  	 }
   }
})

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
