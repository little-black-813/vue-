export const noticeRouter = {
    path: '/notice',
    component: () => import('@/components/Layout.vue'),
    meta: {
      title: '公告管理'
    },
    hidden: false,
    children: [{
        path: "index",
        component: () => import('@/views/notice/index.vue'),
        name: "Notice",
        meta: {
          title: '公告管理'
        },
    },
    {
      path: 'add',
      component: () => import('@/views/notice/addorEdit.vue'),
      name: 'NoticeAdd',
      hidden: true,
      meta: {
        title: '新增公告',
        activeMenu: '/notice/index'
      }
    },{
      path: 'edit',
      component: () => import('@/views/notice/addorEdit.vue'),
      name: 'NoticeEdit',
      hidden: true,
      meta: {
        title: '编辑公告',
        activeMenu: '/notice/index'
      }
    },],
  }
