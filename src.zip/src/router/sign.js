export const signRouter = {
    path: '/sign',
    component: () => import('@/components/Layout.vue'),
    meta: {
      title: '签到管理'
    },
    hidden: false,
    children: [{
        path: "index",
        component: () => import('@/views/sign/index'),
        name: "SignList",
        meta: {
          title: '签到管理'
        },
      },
      {
        path: 'add',
        component: () => import('@/views/sign/add.vue'),
        name: 'SignAdd',
        hidden: true,
        meta: {
          title: '新增签到',
          activeMenu: '/sign/index'
        }
      },
      {
        path: 'edit',
        component: () => import('@/views/sign/edit.vue'),
        name: 'SignEdit',
        hidden: true,
        meta: {
          title: '编辑签到',
          activeMenu: '/sign/index'
        }
      },
      {
        path: 'detail',
        component: () => import('@/views/sign/detail.vue'),
        name: 'SignDetail',
        hidden: true,
        meta: {
          title: '签到详情',
          activeMenu: '/sign/index'
        }
      },
      // {
      //   path: '/data',
      //   component: () => import('@/views/activity/dataMan/index'),
      //   name: 'SignDataMan',
      //   meta: {
      //     title: '签到数据管理'
      //   },
      //   hidden: false,
      // }
      
    ],
  }
