export const blessingBagRoute = {
    path: '/bag',
    component: () => import('@/components/Layout.vue'),
    meta: {
      title: '拆福袋管理'
    },
    hidden: false,
    children: [{
        path: "index",
        component: () => import('@/views/bag/index'),
        name: "BlessingBagMan",
        meta: {
          title: '拆福袋活动'
        },
      },
      {
        path: 'add',
        component: () => import('@/views/bag/add.vue'),
        name: 'BlessingBagAdd',
        hidden: true,
        meta: {
          title: '新增拆福袋活动',
          activeMenu: '/bag/index'
        }
      },
      {
        path: 'edit',
        component: () => import('@/views/bag/edit.vue'),
        name: 'BlessingBagEdit',
        hidden: true,
        meta: {
          title: '编辑拆福袋活动',
          activeMenu: '/bag/index'
        }
      },
      {
        path: 'record',
        component: () => import('@/views/bag/bannerRecord.vue'),
        name: 'BannerRecord',
        hidden: true,
        meta: {
          title: 'banner目标客户',
          activeMenu: '/bag/index'
        }
      },
      {
        path: 'ex-record',
        component: () => import('@/views/bag/exchangeRecord'),
        name: 'BlessingBagDataMan',
        meta: {
          title: '兑换记录',
          activeMenu: '/bag/index'
        },
        hidden: true,
      }
    ]
}
