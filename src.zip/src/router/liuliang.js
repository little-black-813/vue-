export const liuliangRouter = {
    path: '/card',
    component: () => import('@/components/Layout.vue'),
    meta: {
      title: '家庭流量'
    },
    hidden: false,
    children: [{
        path: "index",
        component: () => import('@/views/liuliang/AddCard.vue'),
        name: "Card",
        meta: {
          title: '家庭流量-卡券'
        },
    },
    /* {
        path: "add",
        component: () => import('@/views/liuliang/AddCard.vue'),
        name: "CardAdd",
        meta: {
          title: '新增卡券'
        },
    } */],
  }
