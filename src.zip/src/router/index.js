import Vue from 'vue'
import VueRouter from 'vue-router'

import {daiyanroute} from './daiyan.js';
import { liuliangRouter } from './liuliang.js'
import {noticeRouter} from './notice.js'
import {signRouter} from './sign.js'
import { medicalroute } from './medical.js'
import { blessingBagRoute } from './blessingBag.js'
import { interestroute } from './interest.js'
Vue.use(VueRouter)
const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}
const routes = [{
    path: '/',
    redirect: '/activity/index',
    hidden: true,
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/Login.vue'),
    meta: {
      title: '登录'
    },
    hidden: true
  },
  {
    path: '/activity',
    component: () => import('../components/Layout.vue'),
    meta: {
      title: '抽奖活动管理'
    },
    hidden: false,
    children: [{
        path: "index",
        component: () => import('../views/activity/index'),
        name: "activityList",
        meta: {
          title: '抽奖活动管理'
        },
      },
      {
        path: 'add',
        component: () => import('../views/activity/add.vue'),
        name: 'ActivityAdd',
        hidden: true,
        meta: {
          title: '新增活动',
          activeMenu: '/activity/index'
        }
      },
      {
        path: 'edit',
        component: () => import('../views/activity/edit.vue'),
        name: 'ActivityEdit',
        hidden: true,
        meta: {
          title: '编辑活动',
          activeMenu: '/activity/index'
        }
      },
      {
        path: 'detail',
        component: () => import('../views/activity/detail.vue'),
        name: 'ActivityDetail',
        hidden: true,
        meta: {
          title: '活动详情',
          activeMenu: '/activity/index'
        }
      },
      {
        path: 'record',
        component: () => import('../views/activity/record.vue'),
        name: 'ActivityrRecord',
        hidden: true,
        meta: {
          title: '目标中奖客户',
          activeMenu: '/activity/index'
        }
      },
      {
      path: 'uprecord',
      component: () => import('../views/activity/uprecord.vue'),
      name: 'ActivityrUpRecord',
      hidden: true,
      meta: {
        title: '弹窗目标用户',
        activeMenu: '/activity/index'
      }
    },
      {
        path: '/data',
        component: () => import('../views/activity/dataMan/index'),
        name: 'ActivityDataMan',
        meta: {
          title: '数据管理'
        },
        hidden: false,
      },
      {
        path: '/coupons',
        component: () => import('../views/activity/coupons/index'),
        name: 'ActivityCoupons',
        meta: {
          title: '虚拟卡券管理'
        },
        hidden: false,
      },
      {
        path: '/coast',
        component: () => import('../views/activity/coast'),
        name: 'ActivityCoast',
        meta: {
          title: '话费单管理'
        },
        hidden: false,
      },
    ]
  },
  /* {
  	path: '/data',
  	component: () => import('@/components/Layout.vue'),
  	meta: {
  	  title: '数据管理'
  	},
    hidden:false,
  	children:[
  		{
  			path: 'index',
  			component: () => import('@/views/dataMan/index'),
  			meta: {
  			  title: '数据管理'
  			}
  		},
      {
        path:'record',
        component: () => import('@/views/dataMan/prizeRecord.vue'),
        name:'DataRecord',
        hidden:true,
        meta: { title: '活动详情', activeMenu:'/data/index'}
      },
  	]
  } */
  daiyanroute,
  liuliangRouter,
  noticeRouter,
  signRouter,
  medicalroute,
  blessingBagRoute,
  interestroute
]
const router = new VueRouter({
  // mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
