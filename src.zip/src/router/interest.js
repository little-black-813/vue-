export const interestroute = {
  path: '/interest',
  component: () => import('@/components/Layout.vue'),
  meta: {
    title: '权益查询'
  },
  hidden: false,
  children: [{
      path: "index",
      component: () => import('@/views/interest/index'),
      name: "interestMan",
      meta: {
        title: '权益查询'
      },
    },
    {
      path: 'add',
      component: () => import('@/views/interest/add.vue'),
      name: 'interestAdd',
      hidden: true,
      meta: {
        title: '新增权益查询',
        activeMenu: '/interest/index'
      }
    },
    {
      path: 'edit',
      component: () => import('@/views/interest/edit.vue'),
      name: 'interestEdit',
      hidden: true,
      meta: {
        title: '编辑权益查询',
        activeMenu: '/interest/index'
      }
    },
    {
      path: 'detail',
      component: () => import('@/views/interest/detail.vue'),
      name: 'interestDetail',
      hidden: true,
      meta: {
        title: '权益查询记录',
        activeMenu: '/interest/index'
      }
    }
  ],
}
