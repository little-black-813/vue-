export const daiyanroute = {
    path: '/daiyan',
    component: () => import('@/components/Layout.vue'),
    meta: {
      title: '带盐活动管理'
    },
    hidden: false,
    children: [{
        path: "index",
        component: () => import('@/views/daiyan/index'),
        name: "DaiYanMan",
        meta: {
          title: '带盐活动管理'
        },
      },
      {
        path: 'add',
        component: () => import('@/views/daiyan/add.vue'),
        name: 'DaiYanAdd',
        hidden: true,
        meta: {
          title: '新增带盐',
          activeMenu: '/daiyan/index'
        }
      },
      {
        path: 'edit',
        component: () => import('@/views/daiyan/edit.vue'),
        name: 'DaiYanEdit',
        hidden: true,
        meta: {
          title: '编辑带盐',
          activeMenu: '/daiyan/index'
        }
      },
      {
        path: 'data',
        component: () => import('@/views/daiyan/dataMan/index'),
        name: 'DaiYanDataMan',
        meta: {
          title: '数据记录'
        },
        hidden: false,
      }
    ],
  }
