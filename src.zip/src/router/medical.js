export const medicalroute = {
  path: '/medical',
  component: () => import('@/components/Layout.vue'),
  meta: {
    title: '套餐体检站'
  },
  hidden: false,
  children: [{
      path: "index",
      component: () => import('@/views/medical/index'),
      name: "medicalMan",
      meta: {
        title: '套餐体检站'
      },
    },
    {
      path: 'add',
      component: () => import('@/views/medical/add.vue'),
      name: 'medicalAdd',
      hidden: true,
      meta: {
        title: '新增套餐体检',
        activeMenu: '/medical/index'
      }
    },
    {
      path: 'edit',
      component: () => import('@/views/medical/edit.vue'),
      name: 'medicalEdit',
      hidden: true,
      meta: {
        title: '编辑套餐体检',
        activeMenu: '/medical/index'
      }
    },
    {
      path: 'detail',
      component: () => import('@/views/medical/detail.vue'),
      name: 'medicalDetail',
      hidden: true,
      meta: {
        title: '体检记录',
        activeMenu: '/medical/index'
      }
    }
  ],
}
