const activityList=[
        {
          activityType:'0',
          activityName:'家庭流量共享'
        },
        {
          activityType:'1',
          activityName:'抽奖活动'
        },
        {
          activityType:'2',
          activityName:'带盐活动'
        }
      ];
const noticeList=[{ 
        type:'0',
        name:'活动下线'
      },
      {
        type:'1',
        name:'公告提示'
      }]
export  {
  activityList,
  noticeList
}
