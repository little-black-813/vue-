import axios from 'axios'
import router from '@/router'
import {
  Notification,
  Message
} from 'element-ui'
// 根据环境不同引入不同api地址
import store from '../store'
import { judgePath } from '../utils/utils';
const path = judgePath();
const request = axios.create({
  baseURL: '',
  withCredentials:true,
  crossDomain:true
})
// 拦截器
request.interceptors.request.use(
  config => {

    if(process.env.NODE_ENV!=='development'){
      if(config.url.split('/')[1].match(/(dy|api)/)){
        config.baseURL = judgePath()
      }else{
          config.baseURL = judgePath()+'/testLottery/api'   // 测试
          // config.baseURL = judgePath()+ '/manager/api'; //生产
      }
    }else{
      // if(config.url.split('/')[1].match(/(bagActivity)/)){
      //   config.baseURL = judgePath()
      // }else{
      //   config.baseURL = judgePath()+'/manager/api';//生产环境
      // }

       //config.baseURL = judgePath()+'/testLottery/api';//测试环境
      config.baseURL = "http://localhost:7109";//本地环境
    }

    store.dispatch('setLoading', true);
    if (config.method.toLowerCase() === 'post') {
      config.headers['Content-Type'] = 'application/json;charset=utf-8;'
    }
    return config
  },
  error => {
    // do something with request error
    return Promise.reject(error)
  }
)

// response拦截器
request.interceptors.response.use(response => {
  store.dispatch('setLoading', false);
  // store.dispatch('setError', false);
  const res = response.data;
  // 流文件直接返回
  if(!!res.size){
    return res
  }
  // console.log(res.flag || res.resultStat==='SUCCESS')
  if (res.flag || res.code ==='200' || res.resultStat==='SUCCESS' || res.code==='0000') {
    return res;
  }
  console.log('res---',res,res.msg,(res.message || res.mess || res.msg))
  Message({
    showClose: true,
    message: `${res.message || res.mess || res.msg }`,
    type: 'error'
  });
  return Promise.reject('err')
}, err => {
  store.dispatch('setLoading', false);
  // store.dispatch('setError', true);
  // router.push({path:'/err'})
  err.message = '网络错误，请稍后再试'
  if (err && err.response) {
    switch (err.response.status) {
      case 400:
        err.message = '请求错误'
        break
      case 403:
        err.message = '拒绝访问'
        break
      case 404:
        err.message = `请求地址出错: ${err.response.config.url}`
        break
      case 405:
        err.message = '请求地址出错:'
        break
      case 408:
        err.message = '请求超时'
        break
      case 500:
        err.message = '网络错误，请稍后再试'
        break
      case 501:
        err.message = '网络错误，请稍后再试'
        break

      case 502:
        err.message = '网络错误，请稍后再试'
        break

      case 503:
        err.message = '网络错误，请稍后再试'
        break

      case 504:
        err.message = '网络错误，请稍后再试'
        break

      case 505:
        err.message = 'HTTP版本不受支持'
        break

      default:
    }
  }
  Notification.error({
    title: '错误信息',
    message: `${err.message}`
  });
  // Toast(err.message)
  return Promise.reject(err)
})
export default request
