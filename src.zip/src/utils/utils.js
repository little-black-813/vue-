import { baseWechatUrl } from './config'
//,baseApiAli,baseApi
export const judgePath = ()=>{
  let api = baseWechatUrl;
  // if(document.domain==='wx.online-cmcc.cn'){
  //     api = baseApiAli;
  // }else if(document.domain==='wechat.jxydzx.cn'){
  //     api = baseWechatUrl;
  // }
  return api;
}
/**
 * 空对象判断
 * @param obj
 * @returns {boolean}
 */
export function isEmptyObject(obj) {

  for (let key in obj) {
    return false
  };
  return true
};
/**
 * 判断空值
 */
export const isEmptyValue = (val) => {
  // val = val.replace(/\"|&nbsp;|\\/g, '').replace(/(^\s*)|(\s*$)/g, '')

  if (val === '' || val === null || val === 'null' || val === undefined || val === 'undefined')     return true;
  return false;
}
export const formatDate = (date,fmt)=>{
  console.log(date)
  if(!date) return;
	if (/(y+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    let o = {
        'M+': date.getMonth() + 1,
        'd+': date.getDate(),
        'H+': date.getHours(),
        'm+': date.getMinutes(),
        's+': date.getSeconds()
    };
    for (let k in o) {
        if (new RegExp(`(${k})`).test(fmt)) {
            let str = o[k] + '';
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? str : padLeftZero(str));
        }
    }
    return fmt;
}
function padLeftZero(str) {
    return ('00' + str).substr(str.length);
}

export const exportExcel = (file,filenames)=>{
  let blob = new Blob([file], { type: 'application/octet-stream' })
  let fileName = filenames
  // 如果后端返回文件名
  // let contentDisposition = res.headers['content-disposition'];
  // let fileName = decodeURI(contentDisposition.split('=')[1]);
  if ('download' in document.createElement('a')) {
    // 非IE下载
    let link = document.createElement('a')
    link.download = fileName
    link.style.display = 'none'
    link.href = URL.createObjectURL(blob)
    document.body.appendChild(link)
    link.click()
    URL.revokeObjectURL(link.href) // 释放URL 对象
    document.body.removeChild(link)
  } else {
    // IE10+下载
    navigator.msSaveBlob(blob, fileName)
  }
}
