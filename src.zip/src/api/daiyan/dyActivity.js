import request from '@/utils/axios'
//活动列表
export const getActivityData = params=>{
  return request({
    url: '/dy/api/data/dyActivity/queryAll',
    method: 'get',
    params: params
  });
}
//获取活动链接
export const getLinkReq = params=>{
  return request({
    url: '/dy/api/data/activityManager/getLink',
    method: 'get',
    params: params
  });
}
//创建活动基础信息
export const createOrEditBaseActivityReq = params=>{
  return request({
    url: params.reqUrl,
    method: 'post',
    data: params.creatForm
  });
}
//查询数据
export const getData = params=>{
  return request({
        url: '/dy/api/data/questionnaire/selectTodayData',
        method: 'get',
        params: params
    });
}
export const getQuAndHBReq = params=>{
  return request({
        url: '/dy/api/data/questionnaire/total',
        method: 'get',
        params: params
    });
}
//调查问卷详情
export const getQuestionDetailReq = params=>{
  return request({
        url: '/dy/api/data/questionnaire/details',
        method: 'get',
        params: params
    });
}
//奖品列表
export const getPrizeListReq = params =>{
  return request({
        url: '/dy/api/data/dyPrize/queryAll',
        method: 'get',
        params: params
    });
}
// 新增奖品,编辑
export const addPrizeReq = params =>{
  return request({
        url: params.reqUrl,
        method: 'post',
        data: params.prizeForm
    });
}
//删除
export const delPrizeReq = params => {
  return request({
        url: params.reqUrl,
        method: 'get',
        params: params.prizeForm
    })
}
//查询活动详情
export const searchDYDetail = params => {
  return request({
        url: '/dy/api/data/dyActivity/queryActivity',
        method: 'get',
        params: params
    })
}
