import request from '@/utils/axios'

export const getData = params=>{
  return request({
        url: '/data/activityManager/findAllActivityData',
        method: 'get',
        params: params
    });
}
export const getLotteryInfoReq = params => {
  return request({
        url: '/data/activityManager/getLotteryInfo',
        method: 'get',
        params: params
    });
}
