import request from '@/utils/axios'

export const getData = params=>{
  return request({
        url: '/notice/findAll',
        method: 'get',
        params: params
    });
}
