import request from '@/utils/axios'
//卡券列表列表
export const getCoastData = params=>{
  return request({
    url: '/data/prize/findPhoneBill',
    method: 'get',
    params: params
  });
}
//修改处理状态
export const modifyStatus = params=>{
  return request({
    url: '/data/prize/processPhoneBill',
    method: 'get',
    params: params
  });
}
