import request from '@/utils/axios'
//活动列表
export const getActivityData = params=>{
  return request({
        url: '/data/activityManager/getActivityInfo',
        method: 'get',
        params: params
    });
}
//获取活动链接
export const getLinkReq = params=>{
  return request({
        url: params.url,
        method: 'get',
        params: params.data
    });
}
//创建活动基础信息
export const createOrEditBaseActivityReq = params=>{
  return request({
        url: params.reqUrl,
        method: 'post',
        data: params.creatForm
  });
}
//设置活动次数规则
export const setOrEditRulesReq = params=>{
  return request({
        url: params.reqUrl,
        method: 'post',
        data: params.ruleForm
  });
}
//设置分享信息
export const setShareReq = params=>{
  return request({
        url: params.reqUrl,
        method: 'post',
        data: params.shareForm
  });
}
//设置图片
export const setImgReq = params=>{
  return request({
        url: '/data/activity/setActivityImage',
        method: 'post',
        data: params
  });
}
//获取目标客户列表
export const getMuBiaoInfoReq = params => {
  return request({
        url: '/data/activityManager/selectAllZhongjiangInfo',
        method: 'get',
        params: params
  });
}
//获取弹窗目标客户列表
export const getTanCInfoReq = params => {
  return request({
        url: '/data/activityManager/selectAllPopTargetInfo',
        method: 'get',
        params: params
  });
}
//删除活动
export const updateActivityState = params => {
  return request({
    url:'/data/activityManager/updateActivityState',
    method:'post',
    data:params
  })
}
