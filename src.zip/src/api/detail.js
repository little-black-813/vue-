import request from '@/utils/axios'
//获取详细信息
export const getDetailReq = params => {
  return request({
        url: '/data/activityManager/selectActivityInfoById',
        method: 'get',
        params: params
    });
}

//中奖记录
export const getRecordsReq = params => {
  return request({
        url: '/data/activityManager/winLotteryInfo',
        method: 'get',
        params: params
    });
}
//获取奖品名称

export const getPrizeListReq = params => {
  return request({
        url: '/data/activityManager/prizeName',
        method: 'get',
        params: params
    });
}
//抽奖情况
export const getLotteryReq = params => {
  return request({
        url: '/data/activityManager/getActivityLotteryInfo',
        method: 'get',
        params: params
    });
}