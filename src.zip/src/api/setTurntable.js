import request from '@/utils/axios'
//获取转盘列表
export const getTurnListReq = params => {
  return request({
        url: '/data/plate/getPlate',
        method: 'get',
        params: params
  });
}
// 新增奖品,编辑
export const setPrizeReq = params =>{
  return request({
        url: params.reqUrl,
        method: 'post',
        data: params.turntableForm
    });
}
