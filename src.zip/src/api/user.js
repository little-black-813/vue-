import request from '../utils/axios'
/**
 * 登陆
 */
export const login = params => request({
  url:'/data/user/userLogin',
  data:params,
  method:'post'
});
export const getCode = params => request({
  url:`/data/sms/sendCaptcha`,
  params:params,
  method:'post'
});
/**
 * 退出
 */

export const signout = () => request({
  method:'post',
  url:'/data/user/loginOut'
});
