import request from '@/utils/axios'
//获取奖品列表
export const getPrizeListReq = params =>{
  return request({
        url: '/data/activityManager/signWinLotteryInfo',
        method: 'get',
        params: params
    });
}
//签到导出
export const getRecordsReq = params =>{
  return request({
        url: '/data/excelExport/excelExportSignLottery',
        method: 'get',
        params: params
    });
}
