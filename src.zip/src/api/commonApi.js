import request from '@/utils/axios';

export function getMainInfoReq (params) {
  return request({
	  url: params.url,
	  method: 'GET',
	  params: params.data
  })
}
//创建活动基础信息
export const postReq = params=>{
  return request({
    url: params.reqUrl,
    method: 'post',
    data: params.form
  });
}
