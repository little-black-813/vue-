import request from '@/utils/axios'
//获取奖品列表
export const getPrizeListReq = params =>{
  return request({
        url: '/data/prize/getPrizeByActivityId',
        method: 'get',
        params: params
    });
}
// 新增奖品,编辑
export const addPrizeReq = params =>{
  return request({
        url: params.reqUrl,
        method: 'post',
        data: params.prizeForm
    });
}
//删除

export const delPrizeReq = params => {
  console.log(params, 'parms')
  return request({
        url: params.reqUrl,
        method: 'get',
        params: params.prizeForm
    })
}

export const delPrizeReqmedical = params => {
  return request({
        url: params.reqUrl,
        method: 'post',
        data: params.prizeForm
    })
}
