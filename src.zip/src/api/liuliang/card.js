import request from '@/utils/axios'
//活动列表
export const getCardData = params=>{
  return request({
        url: '/campaign/findAll',
        method: 'get',
        params: params
    });
}
export const createTimeReq = params=>{
  return request({
        url: params.reqUrl,
        method: 'post',
        data: params.creatForm
  });
}