import request from '@/utils/axios'
//卡券列表列表
export const getCouponsData = params=>{
  return request({
    url: '/data/prize/findCoupons',
    method: 'get',
    params: params
  });
}
//修改处理状态
export const modifyStatus = params=>{
  return request({
    url: '/data/prize/processCoupons',
    method: 'get',
    params: params.couponsForm
  });
}

