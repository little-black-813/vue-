<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app',
  created() {
  	//在页面加载时读取sessionStorage里的状态信息
  	  if (sessionStorage.getItem("store") ) {
  	      this.$store.replaceState(Object.assign({}, this.$store.state,JSON.parse(sessionStorage.getItem("store"))))
  	  }
	  console.log('refresh-11')
  	  //在页面刷新时将vuex里的信息保存到sessionStorage里
  	  window.addEventListener("beforeunload",()=>{
        console.log('refresh',this.$store.state)
  	      sessionStorage.setItem("store",JSON.stringify(this.$store.state))
  	  })
  },
  mounted() {
    this.$store.dispatch('setLoading',false);
  }
}
</script>

<style>
@import url("assets/css/reset.css");
#app{
  min-width: 1200px;
  _width:1200px;
  overflow-x: auto;
}
.pagination{
  margin: 20px 0;
  text-align: center;
}
</style>
