const state = {
  activityId:'',
  activityBaseInfo: {
    activityInfo: {},
  },
  editBaseInfo :{
    activityInfo: {},
  }
}
const mutations = {
  save_activityBaseInfo(state, baseInfo) {
    state.activityBaseInfo = { ...state.activityBaseInfo,
      ...baseInfo
    };
  },
  save_editBaseInfo(state, baseInfo) {
    state.editBaseInfo.activityInfo = baseInfo.activityInfo;
  },
  save_activityId(state,id){
    state.activityId = id;
  }
}
const actions = {
  setEditbaseInfo({commit},baseInfo){
    commit('save_editBaseInfo',baseInfo)
  },
  setActivityBaseInfo({
    commit
  }, baseInfo) {
    commit('save_activityBaseInfo', baseInfo)
  },
  setActivityId({commit},id){
    commit('save_activityId', id);
  }
}
export default {
  namespaced: true,
  state,
  mutations,
  actions
}