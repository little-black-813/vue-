const state = {
  activityId:'',
  activityBaseInfo: {
  },
  editBaseInfo :{
  },
  httpDomain: ''
}
const mutations = {
  setActivityBaseInfo(state, baseInfo) {
    state.activityBaseInfo = baseInfo;
  },
  setEditBaseInfo(state, baseInfo) {
    state.editBaseInfo = baseInfo;
  },
  setActivityId(state,id){
    state.activityId = id;
  },
  setHttpDomain(state,param){
    state.httpDomain = param;
  }
}
export default {
  namespaced: true,
  state,
  mutations,
}
