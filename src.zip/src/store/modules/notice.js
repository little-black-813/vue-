const state = {
  baseInfo: {
  },

}
const mutations = {
  save_baseInfo(state, baseInfo) {
    state.baseInfo = { ...state.baseInfo,
      ...baseInfo
    };
  },
}
const actions = {
  setBaseInfo({
    commit
  }, baseInfo) {
    commit('save_baseInfo', baseInfo)
  },

}
export default {
  namespaced: true,
  state,
  mutations,
  actions
}
