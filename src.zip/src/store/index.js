import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const modulesFiles = require.context('./modules', true, /\.js$/);
// you do not need `import app from './modules/app'`
// it will auto require all vuex module from modules file
const modules = modulesFiles.keys().reduce((modules, modulePath) => {
  // set './app.js' => 'app'
  const moduleName = modulePath.replace(/^\.\/(.*)\.\w+$/, '$1')
  const value = modulesFiles(modulePath)
  modules[moduleName] = value.default
  return modules
}, {});

export default new Vuex.Store({
  state: {
    userInfo: {},
    loading:false,//页面数据家在
    activityId:'',
    activityBaseInfo: {
      activityInfo: {},
      setInfo: {},
      ruleInfo: {},
      shareInfo: {},
      prizeList: []
    },
    editBaseInfo :{
      activityInfo: {},
      /* setInfo: {},
      ruleInfo: {},
      shareInfo: {},
      prizeList: [] */
    }
  },
  mutations: {
    save_UserInfo(state, userInfo) {
      state.userInfo = userInfo;
    },
    save_activityBaseInfo(state, baseInfo) {
      state.activityBaseInfo = { ...state.activityBaseInfo,
        ...baseInfo
      };
    },
    save_editBaseInfo(state, baseInfo) {
      state.editBaseInfo.activityInfo = baseInfo.activityInfo;
    },
    SET_Loading(state,loading){
      state.loading = loading;
    },
    save_activityId(state,id){
      state.activityId = id;
    }
  },
  actions: {
    setUserInfo({
      commit
    }, params) {
      commit('save_UserInfo', params)
    },
    setEditbaseInfo({commit},baseInfo){
      commit('save_editBaseInfo',baseInfo)
    },
    setActivityBaseInfo({
      commit
    }, baseInfo) {
      commit('save_activityBaseInfo', baseInfo)
    },
    setLoading({commit},flag){
      commit('SET_Loading', flag)
    },
    setActivityId({commit},id){
      commit('save_activityId', id);
    }
  },
  modules,
  getters: {
    getUserInfo: state => state.userInfo,
  }
})
