<template>
  <div class="card-style-border">
    <h2 class="font16">中奖纪录</h2>
    <div class="handle-box">
      <label style="font-size: 14px;">导出条件设置：</label>
      <label for="selectDay">开始日期：</label>
      <el-date-picker
        id="selectDay"
        class="marginR"
        size="small"
        v-model="exportData.startTime"
        type="date"
        placeholder="选择开始日期"
        value-format="yyyy-MM-dd"
      ></el-date-picker>
      <label for="selectEnd">结束日期：</label>
      <el-date-picker
        id="selectEnd"
        class="marginR"
        size="small"
        v-model="exportData.endTime"
        type="date"
        placeholder="选择结束日期"
        value-format="yyyy-MM-dd"
      ></el-date-picker>
      <label for="prizeType">奖品类型：</label>
      <el-cascader
      class="marginR"
            :options="prizeList"
            :props="cascaderProps"
            size="small"
            filterable
            :clearable="true"
            :collapse-tags="true"
            placeholder="请选择相关奖品"
            @change="handleChange"
       ></el-cascader>
       <!-- <el-button class="marginR" size="small" >查询</el-button> -->
       <el-button size="small" type="primary"  @click="excleLottery()">导出</el-button>
    </div>
    <!-- <div class="handle-box">
      <label for="prizeType">奖品类型：</label>
      <el-select id="prizeType" v-model="queryRecore.prizeType" class="marginR" size="small" multiple placeholder="请选择奖品类型">
          <el-option
            v-for="item in prizeTypeList"
            :key="item.prizeType"
            :label="item.label"
            :value="item.prizeType">
          </el-option>
        </el-select>
    </div> -->
    <el-table :data="lotterRecordData.list" style="width: 100%">
      <el-table-column label="序号" type="index" width="90px"></el-table-column>
      <el-table-column v-for="(items, indexs) in lotterRecordLabel" :key="indexs" :prop="items.prop" :label="items.lable" :formatter="items.formatter"></el-table-column>
    </el-table>
    <div class="page-wrapper">
      <el-pagination
        class="current-page"
        layout="prev, pager, next, total,jumper"
        :total="lotterRecordData.total"
        @current-change="recordPageChange"
        :current-page.sync="queryRecore.pageSize"
        :page-size="queryRecore.limite"
        background
      >
      </el-pagination>
    </div>

  </div>
</template>

<script>
import qs from 'qs';
import {judgePath,formatDate} from '@/utils/utils'
import {getRecordsReq,getPrizeListReq} from 'api/detail'
const prizeTypeList=['','话费','业务类','第三方H5','虚拟业务卡券'];
export default{
  data(){
    return{
      loading:false,
      cascaderProps:{
        expandTrigger:'click',
        multiple:true
      },
      prizeList:[

      ],
      prizeTypeList:[
        {
          label: '话费',
          prizeType: '1',
        },
        {
          label: '业务类',
          prizeType: '2'
        },
        {
          label: '第三方H5',
          prizeType: '3'
        },
        {
          label: '虚拟业务卡券',
          prizeType: '4'
        }
      ],
      lotterRecordLabel: [
        { lable: '手机号', type: 'normal', prop: 'userMobile' },
        { lable: '中奖时间', type: 'normal', prop: 'createTime' },
        { lable: '奖项', type: 'normal', prop: 'prizeType',formatter:function(row,column,cellvalue){
      		return prizeTypeList[cellvalue*1];
      	} },
        { lable: '奖品名称', type: 'normal', prop: 'priceName' }
      ],
      lotterRecordData: {
        list:[],
        total:0,
      },
      exportData:{startTime:'',endTime:'',prizeMap:''},
      queryRecore:{
        // prizeType:[],
        pageSize:1,
        limite:10,
        // startTime:'',
        // endTime:''
      },
    }
  },
  created() {
    const {id} = this.$route.query;
    this.getRecord(id);
    this.getPrizeName();
  },
  methods:{
    excleLottery(){
      // console.log(qs.stringify(this.exportData,{encodeValuesOnly: true,encode: false}))
      const {id} = this.$route.query;
      let a = document.createElement("a");
      a.href =`${judgePath()}/manager/api/data/excelExport/TypeTwo?activityId=${id}&${qs.stringify(this.exportData,{encodeValuesOnly: true,encode: false})}`;
      document.body.appendChild(a);
      a.click();  //下载
      URL.revokeObjectURL(a.href);    // 释放URL 对象
      document.body.removeChild(a);   // 删除 a 标签
    },
    recordPageChange(val){
      const {id} = this.$route.query;
      this.$set(this.queryRecore, 'pageSize', val);
       this.getRecord(id);
    },
    getRecord(id){
      getRecordsReq({activityId:id,...this.queryRecore}).then(res=>{
        if(res.flag){
          this.lotterRecordData = {
            list:res.data.data,
            total:res.data.total
          }
        }else{
          this.$message({
            type: 'error',
            message: `${res.message}`
          });
        }
      }).catch(err=>{
        console.log(err)
      })
    },
    getPrizeName(){
      const {id} = this.$route.query;
      getPrizeListReq({activityId:id}).then(res=>{
        let c1=[],c2=[],c3=[],c4=[];
        for(let i=0;i<=res.data.length-1;i++){
          let item =res.data[i];
          switch (item.prizeType){
            case '1':
            c1.push({value:item.prizeId,label:item.priceName,})
              break
            case '2':
              c2.push({value:item.prizeId,label:item.priceName});
              break;
            case '3':
              c3.push({value:item.prizeId,label:item.priceName});
              break;
            case '4':
              c4.push({value:item.prizeId,label:item.priceName});
              break;
          }
        }
        this.prizeList =[
          {
            label: '话费',
            value: '1',
            children:c1
          },
          {
            label: '业务类',
            value: '2',
            children:c2
          },
          {
            label: '第三方H5',
            value: '3',
            children:c3
          },
          {
            label: '虚拟业务卡券',
            value: '4',
            children:c4
          }
        ];
      })
    },
    handleChange(value){
      this.exportData.prizeMap = value.join('_')
    }
  }
}
</script>

<style lang="less" scoped="scoped">
  .card-style-border {
    border: 1px dashed #666;
    padding: 20px 30px;
    background-color: #ffffff;
    margin-bottom: 15px;
    .font16 {
      font-size: 16px;
      color: #333;
      font-weight: normal;
    }
    .fr{
      float: right;
    }
    .page-wrapper{
      margin: 20px auto;
      padding: 10px 0;
      text-align: center;
    }
    .handle-box {
      margin: 20px 0;
      label{
        font-size: 12px;
        color: #464545;
      }
    }
    .marginR{
      margin-right: 10px;
    }
  }
  ::v-deep{
    .el-date-editor.el-input, .el-date-editor.el-input__inner{
      width: 140px;
    }
    .el-select{
      width: 240px;
    }
    .el-cascader{
      width: 260px;
      // width: 88%;
    }
  }
</style>
