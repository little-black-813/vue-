<template>
  <div class="base-wrapper">
    <p class="base-title">活动图片设置</p>
    <el-form ref="setForm" :model="setForm.idObj" :rules="setRule" label-width="180px" class="creat-act-form">
     <template v-for="item in issign == 'sign'? signList : formList">
       <template v-if="(item.prop==='personPhoto'&&isShowPerson)" ></template>
       <!-- <el-form-item v-if="(item.prop==='personPhoto'&&isShowPerson)"  :key="item.prop" :label="item.label+item.prop+'：'" :prop="item.prop">
         <el-input
           type="hidden"
           v-model="setForm.idObj[item.prop]"
         ></el-input>
         <span>{{item.prop==='personPhoto' ? 'personPhoto' : 1}}</span>
          <v-uploadimg :labelKey="item.prop" :id="getId" :imgUrl="setForm.formUrl[item.prop]"/>
        </el-form-item> -->
        <el-form-item v-else  :key="item.prop" :label="item.label+'：'" :prop="item.prop">
          <el-input
            type="hidden"
            v-model="setForm.idObj[item.prop]"
          ></el-input>
           <v-uploadimg :labelKey="item.prop" :id="getId" :upImagSize="item.upImagSize" :imgUrl="setForm.formUrl[item.prop]"/>
         </el-form-item>
     </template>
      <el-form-item>
        <el-button  @click="prevForm()">上一步</el-button>
        <el-button type="primary" v-if="issign != 'sign'" @click="submitForm('setForm')">立即创建</el-button>
        <el-button type="primary" v-else @click="signSubmitForm('setForm')">立即创建</el-button>
        <!--<el-button type="danger" @click="resetForm('setForm')">重置</el-button>-->
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import bus from 'components/common/bus';
import {mapState} from 'vuex';
import {setImgReq} from 'api/activity'
import {isEmptyObject,isEmptyValue} from '@/utils/utils'
import vUploadimg from 'components/common/uploadImg'
export default {
  components:{
    vUploadimg
  },
  data() {
    return {
      issign: '',
      formList:[
        {
          label:"活动背景图",
          prop:"settingPhoto",
          upImagSize:'750px x 1334px'
        },
        {
          label:"活动标题",
          prop:"titlePhoto",
          upImagSize:'577px x 158px'
        },
        {
          label:"转盘背景图",
          prop:"themePhoto",
          upImagSize:'688px x 688px'
        },
        {
          label:"转盘按钮背景图",
          prop:"lotteryNumPhoto",
          upImagSize:'198px x 209px'
        },
        {
          label:"'我的奖品'背景图",
          prop:"prizePhoto",
          upImagSize:'283px x 93px'
        },
        {
          label:"'个人中心'背景图",
          prop:"personPhoto",
          upImagSize:'283px x 93px'
        },
        {
          label:"规则按钮背景图",
          prop:"activityRulePhoto",
          upImagSize:'208px x 82px'
        },

      ],
      signList:[
        {
          label:"活动背景图",
          prop:"settingPhoto",
          upImagSize:'750px x 1334px'
        },
        {
          label:"活动标题",
          prop:"titlePhoto",
          upImagSize:'577px x 158px'
        },
        {
          label:"转盘标题",
          prop:"themePhoto",
          upImagSize:'562px x 129px'
        },
        {
          label:"转盘背景",
          prop:"beginPhoto",
          upImagSize:'750px x 1334px'
        }
      ],
      creatForm: {
        idObj:{
          settingPhoto: '',
          titlePhoto: '',
          prizePhoto: '',
          activityRulePhoto: '',
          themePhoto:'',
          lotteryNumPhoto:'',
          personPhoto:'',
          beginPhoto: ''
        },
        formUrl:{
          settingPhoto: '',
          titlePhoto: '',
          prizePhoto: '',
          activityRulePhoto: '',
          themePhoto:'',
          lotteryNumPhoto:'',
          personPhoto:'',
          beginPhoto: ''
        },
      },
      rules: {
        settingPhoto: [{ required: true, message: '请上传活动背景图', trigger: 'change' }],
        titlePhoto: [{ required: true, message: '请上传活动标题背景图', trigger: 'change' }],
        prizePhoto: [{ required: true, message: '请上传我的奖品按钮背景图', trigger: 'change' }],
        activityRulePhoto: [{ required: true, message: '请上传活动按钮背景图', trigger: 'change' }],
        lotteryNumPhoto: [{ required: true, message: '请上传转盘按钮背景图', trigger: 'change' }],
        themePhoto: [{ required: true, message: '请上传转盘背景图', trigger: 'change' }],
        beginPhoto: [{ required: false, message: '请上传转盘背景图', trigger: 'change' }],
      }
    };
  },
  props:['type'],
  computed:{
    isShowPerson(){//是否展示上传个人中心图标
		if(this.type==='edit'){
			const { homePageUrl } = this.$store.state.editBaseInfo.activityInfo;
			// console.log(isEmptyValue(homePageUrl))
			return isEmptyValue(homePageUrl)
		}else{
			const { homePageUrl } = this.$store.state.activityBaseInfo.activityInfo;
			// console.log(isEmptyValue(homePageUrl))
			return isEmptyValue(homePageUrl)
		}

    },
    setForm(){//初始化表格
      let setInfo = {};
      if(this.type==='edit'){
        setInfo.formUrl = this.$store.state.editBaseInfo.activityInfo;
        setInfo.idObj = this.creatForm.idObj;
      }else{
		  setInfo = this.$store.state.activityBaseInfo.setInfo
      }
      if(isEmptyObject(setInfo)){
        return this.creatForm;
      }
      return setInfo;
    },
    setRule(){
      const setInfo = this.$store.state.editBaseInfo.activityInfo;
      // console.log(this.isShowPerson)
      if(this.type==='edit'){
        return {};
      }else{
        this.rules.personPhoto =  [{ required: !this.isShowPerson, message: '请上传个人中心背景图', trigger: 'change' }]
      }
      this.$set(this.rules , 'beginPhoto' , [{ required: (this.$route.query.key === 'sign'), message: '请上传个人中心背景图', trigger: 'change' }] )

      return this.rules;
    },
    getId(){
    	let id=this.$store.state.activityId;
    	if(this.type==='edit'){
    		id = this.$route.query.id;
    	}
      return id;
    }
  },
  created() {
    bus.$on('imgUrlCallback',params=>{
      // console.log(params.labelKey)
      this.setForm.idObj[params.labelKey]  =params.id;
      this.setForm.formUrl[params.labelKey] = params.url;
    })
    // 判断是否是从签到页面发起的饿创建活动
    this.issign = this.$route.query.key
    // console.log(this.issign, 'tupian')
  },
  beforeDestroy() {
    bus.$off('imgUrlCallback')
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.$set(this.setForm.idObj, 'activityType', 'plateActivity')
          // console.log(this.setForm.idObj, 'this.setForm.idObj')
          setImgReq({...this.setForm.idObj,activityId:this.getId}).then(res=>{
            if(res.flag){
              //存储vuex，上一步时，可以会显
              if(this.type==='edit'){
                this.$store.dispatch('setEditbaseInfo',{activityInfo:{...this.setForm.formUrl}})
              }else{
                this.$store.dispatch('setActivityBaseInfo',{setInfo:this.setForm})
              }

              bus.$emit('activityOp','add');
            }
          })
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    signSubmitForm (formName) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            this.$set(this.setForm.idObj, 'activityType', 'plateActivity')
            setImgReq({...this.setForm.idObj,activityId:this.getId}).then(res=>{
              if(res.flag){
                //存储vuex，上一步时，可以会显
                if(this.type==='edit'){
                  this.$store.dispatch('setEditbaseInfo',{activityInfo:{...this.setForm.formUrl}})
                }else{
                  this.$store.dispatch('setActivityBaseInfo',{setInfo:this.setForm})
                }
                bus.$emit('activityOp','sign');
              }
            })
          } else {
            console.log('error submit!!');
            return false;
          }
        });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
      // console.log(this.$refs[formName].resetFields())
    },
    prevForm(){
      bus.$emit('activityOp','minus');
    }
  }
};
</script>

<style scoped="scoped" lang="less">
.base-wrapper {
  .line{
    text-align: center;
  }
  .base-title{
    font-size: 20px;
    margin: 15px 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid #EEEEEE;
  }
  .creat-act-form{
    width: 60%;
  }
}
</style>
