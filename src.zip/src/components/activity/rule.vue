<template>
  <div class="base-wrapper">
    <p class="base-title">设置抽奖规则</p>
    <el-form ref="ruleForm" :model="ruleForm" :rules="rules" label-width="220px" class="creat-act-form">

      <el-form-item label="单用户最大抽奖次数：" prop="maxLotteryNum">
        <el-input-number v-model.trim="ruleForm.maxLotteryNum" controls-position="right" placeholder="单用户每次最大抽奖次数" :min="0"></el-input-number>
      </el-form-item>
      <!-- 是否允许重复中奖 -->
      <!-- <el-form-item label="是否允许重复中奖：" prop="allowRepeatedWin">
        <el-radio-group v-model="ruleForm.allowRepeatedWin">
            <el-radio :label="1">是</el-radio>
            <el-radio :label="0">否</el-radio>
          </el-radio-group>
      </el-form-item> -->
      <el-form-item label="单用户分享获得次数：" prop="shareNum">
        <el-input-number v-model.trim="ruleForm.shareNum" placeholder="单用户分享获得次数" controls-position="right" :min="0"></el-input-number>
      </el-form-item>
      <el-form-item label="单用户默认抽奖次数：" prop="maxLotteryTime">
        <el-input-number v-model.trim="ruleForm.maxLotteryTime" placeholder="单用户默认抽奖次数" controls-position="right" :min="0"></el-input-number>
      </el-form-item>
      <el-form-item>
        <el-button  @click="prevForm()">上一步</el-button>
        <el-button type="primary" @click="submitForm('ruleForm')">立即创建</el-button>
        <!--<el-button type="danger" @click="resetForm('ruleForm')">重置</el-button>-->
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import bus from 'components/common/bus';
import {mapState} from 'vuex';
import { setOrEditRulesReq } from 'api/activity.js';
import {isEmptyObject} from '@/utils/utils'
export default {
  data() {
    return {
      creatForm: {
        maxLotteryNum:0,
        allowRepeatedWin:0,
        maxLotteryTime:0,
        shareNum:0
      },
      rules: {
        allowRepeatedWin: [{ required: true, message: '是否允许重复中奖', trigger: 'change' }],
        maxLotteryNum: [{ required: true, message: '单用户每日最大抽奖次数', trigger: 'blur' }],
        maxLotteryTime: [{ required: true, message: '单用户默认抽奖次数', trigger: 'blur' }],
        shareNum: [{ required: true, message: '单用户分享获取抽奖次数',trigger: 'blur' }]
      }
    };
  },
  props:['type'],
  computed:{
    ruleForm(){
      let ruleInfo = {};
      if(this.type==='edit'){
       ruleInfo = this.$store.state.editBaseInfo.activityInfo;
      }else{
        ruleInfo = this.$store.state.activityBaseInfo.ruleInfo;
      }
      if(isEmptyObject(ruleInfo)){
        return this.creatForm;
      }
      return ruleInfo;
    },
    getId(){
     let id=this.$store.state.activityId;
     if(this.type==='edit'){
      id = this.$route.query.id;
     }
      return id;
    }
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          //判断编辑还是新增
          let s_id = this.$store.state.activityId;
          let reqUrl ='/data/activity/setActivityRule';
          if(this.type==='edit'){
          	s_id =  this.$route.query.id;
          }
          setOrEditRulesReq({ruleForm:{...this.ruleForm,activityId:s_id},reqUrl}).then(res=>{
            if(res.flag){
               this.$message({
                  message: '恭喜你，设置抽奖规则成功。',
                  type: 'success'
                });
                //存储vuex，上一步时，可以会显
                if(this.type==='edit'){
                  this.$store.dispatch('setEditbaseInfo',{activityInfo:this.ruleForm})
                }else{
                  this.$store.dispatch('setActivityBaseInfo',{ruleInfo:this.ruleForm})
                }

              bus.$emit('activityOp','add');
            }else{
              this.$message.error(`${res.message}`);
            }
          })

        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    prevForm(){
      bus.$emit('activityOp','minus');
    }
  }
};
</script>

<style scoped="scoped" lang="less">
.base-wrapper {
  .line{
    text-align: center;
  }
  .base-title{
    font-size: 20px;
    margin: 15px 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid #EEEEEE;
  }
  .creat-act-form{
    width: 60%;
  }
}
</style>
