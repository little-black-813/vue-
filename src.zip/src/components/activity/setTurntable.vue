<template>
  <div class="base-wrapper">
    <p class="base-title">转盘</p>
    <div class="handle-box">
      <el-button plain type="primary" size="medium" @click="addPrize()">增加转盘元素</el-button>
    </div>
    <el-table :data="tableData" ref="turntTable" :select-on-indeterminate="false" class="prize-table" @selection-change="handleSelectionChange" style="width: 80%">
      <!-- <el-table-column type="selection" align="center" width="55"></el-table-column> -->
      <el-table-column label="序列号" type="index" align="center" width="90px"></el-table-column>
      <el-table-column v-for="(items, indexs) in turnList.lableList" :key="indexs" :prop="items.prop" :label="items.lable" align="center"></el-table-column>
      <el-table-column label="缩略图" align="center">
        <template slot-scope="scope">
          <el-image class="table-td-thumb" :src="scope.row.imgId" :preview-src-list="[scope.row.imgId]"></el-image>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="editPrizeRow(scope.row, scope.$index)">编辑</el-button>
          <el-button type="text" size="small" @click="delPrizeRow(scope.row, scope.$index)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="footer">
      <el-button @click="prevForm()">上一步</el-button>
      <el-button type="danger" @click="nextForm()">下一步</el-button>
    </div>
    <v-setturndialog v-if="addVisiable" c="prizeCb" :show="addVisiable" :formInit="selRow[0]" :type="editType" :selInd="selInd"></v-setturndialog>
    <v-deldialog v-if="delVisiable" url="/data/plate/deletePlate" :show="delVisiable" :name="selRow[0].imgName" :id="selRow[0].id" :selInd="selInd"></v-deldialog>
  </div>
</template>

<script>
import bus from 'components/common/bus';
import { mapState } from 'vuex';
import vSetturndialog from 'components/dialog/AddSetTurn';
import vDeldialog from 'components/dialog/delDialog';
import { getTurnListReq } from 'api/setTurntable'
import { isEmptyObject,judgePath,isEmptyValue } from '@/utils/utils';
export default {
  components: {
    vSetturndialog,
    vDeldialog
  },
  data() {
    return {
      creatUrl: '',
      editType:this.type,
      addVisiable:false,
      delVisiable:false,
      selInd:'',//选择table的下标
      turnList: {
        lableList: [
          {
            lable: '奖品项目名称',
            type: 'normal',
            prop: 'imgName'
          },
          {
            lable: '业务链接',
            type: 'normal',
            prop: 'imgLink'
          },
        ],
      },
      tableData: [],
      selRow: []
    };
  },
  props:['type'],
  computed: {
    getId(){
     if(this.type==='edit'){
     	return this.$route.query.id;
     }
     if(this.type==='add'){
       return this.$store.state.activityId
     }
    }
  },
  created() {
    this.getTurnList();
    bus.$on('turnCb',params=>{
      // console.log('turnCb',params)
      this.addVisiable = params.show;
      this.selRow = [];
      this.selInd = '';
      if(params.reqFlag){
        this.getTurnList();
      }
    });
    bus.$on('closeDel',params=>{
      // console.log(params)
      this.delVisiable = params.show;
      this.selRow = [];
      this.selInd = '';
      if(params.reqFlag){
        this.getTurnList();
      }
    });
  },
  beforeDestroy() {
    bus.$off('turnCb');
    bus.$off('closeDel');
  },
  methods: {
    getTurnList(p){
      getTurnListReq({activityId:this.getId}).then(res=>{
        if(res.flag){
        	this.tableData = res.data
        }
      })
    },
    prevForm() {
      bus.$emit('activityOp', 'minus');
    },
    nextForm(){
      if(this.tableData.length!==8){
        this.$message({
          message: `奖项设置不足8个。`,
          type: 'error'
        });
        return;
      }
      bus.$emit('activityOp', 'add');
    },
    addPrize() {
      if(this.tableData.length===8){
        this.$message({
          message: `奖项设置已经满足8个，请勿添加。`,
          type: 'error'
        });
        return;
      }
      this.addVisiable = true;
    },
    editPrizeRow(row,ind){
      this.addVisiable = true;
      this.selRow = [row];
      this.selInd = ind;
    },
    delPrizeRow(row,ind){
      this.selRow = [row];
      // console.log(this.selRow)
      this.selInd = ind;
      this.delVisiable = true
    },
    handleSelectionChange(val) {
      let arr = val;
      if (arr.length > 1) {
        this.$refs.turntTable.toggleRowSelection(val[0]);
        this.selRow = [val[0]]
      } else {
        this.selRow = [val[0]]
      }
    }
  }
};
</script>

<style scoped="scoped" lang="less">
.base-wrapper {
  .line {
    text-align: center;
  }
  .base-title {
    font-size: 20px;
    margin: 15px 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eeeeee;
  }
  .prize-table {
    margin: 20px auto;
  }
  .footer {
    text-align: center;
  }
  .handle-box {
    width: 80%;
    text-align: right;
    margin: 0 auto;
  }
  .upload-file {
    display: inline-block;
    margin-right: 20px;
  }
  .table-td-thumb {
    display: block;
    margin: auto;
    width: 40px;
    height: 40px;
  }
}
::v-deep {
  .el-table__header th .el-checkbox {
    display: none;
  }
}
</style>
