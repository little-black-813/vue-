<template>
  <div class="base-wrapper">
    <p class="base-title">奖品设置</p>
    <div class="handle-box">
      <el-button plain type="primary" size="medium" @click="addPrize()">增加奖品</el-button>
    </div>
    <el-table :data="tableData" ref="prizeTable" :select-on-indeterminate="false" class="prize-table" @selection-change="handleSelectionChange" style="width: 80%">
      <!-- <el-table-column type="selection" align="center" width="55"></el-table-column> -->
      <el-table-column label="序列号" type="index" align="center" width="90px"></el-table-column>
      <el-table-column v-for="(items, indexs) in prizeList.lableList" :key="indexs" :prop="items.prop" :label="items.lable" align="center" :formatter="items.formatter"></el-table-column>

      <el-table-column label="操作" align="center">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="editPrizeRow(scope.row, scope.$index)">编辑</el-button>
          <el-button type="text" size="small" @click="delPrizeRow(scope.row, scope.$index)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination">
      <el-pagination
        background
        :hide-on-single-page="true"
        layout="total, prev, pager, next"
        :current-page="query.pageSize"
        :page-size="query.limite"
        :total="total"
        @current-change="handlePageChange"
      ></el-pagination>
    </div>

    <div class="footer">
      <el-button @click="prevForm()">上一步</el-button>
      <el-button plain type="primary">完成</el-button>
      <!-- <el-button type="danger" @click="createLink()">生成链接</el-button> -->
    </div>
   <!-- <v-linkdialog v-if="linkVisiable" :editType="editType"  action="finsh" :show="linkVisiable"  :activityId="getId"></v-linkdialog> -->
    <v-prizedialog v-if="addVisiable" c="prizeCb" :show="addVisiable" :formInit="selRow[0]" :type="editType" :selInd="selInd"></v-prizedialog>
    <v-deldialog v-if="delVisiable" url="/dy/api/data/dyPrize/deletePrize" :show="delVisiable" :name="selRow[0].prizeName" :id="selRow[0].id" :selInd="selInd"></v-deldialog>
  </div>
</template>

<script>
import bus from 'components/common/bus';
import { mapState } from 'vuex';
import vLinkdialog from 'components/dialog/LinkDialog';
import vPrizedialog from 'components/daiyan/AddPrizeDialog';
import vDeldialog from 'components/daiyan/delDialog';
import { getPrizeListReq } from 'api/daiyan/dyActivity.js'
import { isEmptyObject,judgePath,isEmptyValue } from '@/utils/utils';
const rangeList = {
      "1":"一等奖",
      "2":"二等奖",
      "3":"三等奖",
    }
export default {
  components: {
    vLinkdialog,
    vPrizedialog,
    vDeldialog
  },
  data() {
    return {
      creatUrl: '',
      editType:this.type,
      linkVisiable:false,
      addVisiable:false,
      delVisiable:false,
      selInd:'',//选择table的下标
      extendData:{
        activityId:this.$store.state.activityId,
        prizeId:''
      },
      prizeList: {
        lableList: [
          {
            lable: '奖品等级',
            type: 'normal',
            prop: 'scope',
            formatter:function(row, column, cellValue, index){
              return rangeList[cellValue]
            }
          },
          {
            lable: '奖品名称',
            type: 'normal',
            prop: 'prizeName'
          },
          {
            lable: '数量',
            type: 'normal',
            prop: 'prizeNumber'
          },

        ],

      },
      tableData: [],
      query:{
        pageSize:1,
        limite:10
      },
      total:0,
      selRow: []
    };
  },
  props:['type'],
  computed: {
    ...mapState({
      baseInfo: 'activityBaseInfo'
    }),
    path(){
      return `${judgePath()}/data/targetUsers/fileUpload`
    },
    getId(){
     if(this.type==='edit'){
     	return this.$route.query.id;
     }
     if(this.type==='add'){
       return this.$store.state.daiyan.activityId
     }
    }
  },
  created() {
    this.getPrizeList('init');
    bus.$on('dyPrizeCb',params=>{
      console.log('dyPrizeCb',params)
      this.addVisiable = params.show;
      this.selRow = [];
      this.selInd = '';
      if(params.reqFlag){
        this.getPrizeList('req');
      }
    });
    bus.$on('closeDyDel',params=>{
      console.log(params)
      this.delVisiable = params.show;
      this.linkVisiable = params.show || params;
      this.selRow = [];
      this.selInd = '';
      if(params.reqFlag){
        this.getPrizeList();
      }
    });
  },
  beforeDestroy() {
    bus.$off('dyPrizeCb');
    bus.$off('closeDyDel');
  },
  methods: {
    getPrizeList(p){
      getPrizeListReq({activityId:this.getId,...this.query}).then(res=>{
        if(res.flag){
        	// console.log('in---')
        	this.tableData = res.data.data
          this.total = res.data.total;
        }
      })
    },
    // 分页导航
    handlePageChange(val) {
      this.$set(this.query, 'pageSize', val);
      this.getPrizeList();
    },
    createLink() {
      this.linkVisiable = true;
      // bus.$emit('openLink', true);
    },
    prevForm() {
      bus.$emit('daiYanOp', 'minus');
    },
    addPrize() {
      this.addVisiable = true;
    },
    editPrizeRow(row,ind){
      this.addVisiable = true;
      this.selRow = [row];
      this.selInd = ind;
    },
    delPrizeRow(row,ind){
      this.selRow = [row];
      console.log(this.selRow)
      this.selInd = ind;
      this.delVisiable = true
    },
    handleSelectionChange(val) {
      console.log(val)
      let arr = val;
      if (arr.length > 1) {
        this.$refs.prizeTable.toggleRowSelection(val[0]);
        this.selRow = [val[0]]
        this.extendData.activityId = this.getId;
        this.extendData.prizeId = val[0].id;
      } else {
        this.selRow = [val[0]]
        this.extendData.activityId = this.getId;
        this.extendData.prizeId = val[0].id;
      }
    }
  }
};
</script>

<style scoped="scoped" lang="less">
.base-wrapper {
  .line {
    text-align: center;
  }
  .base-title {
    font-size: 20px;
    margin: 15px 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eeeeee;
  }
  .prize-table {
    margin: 20px auto;
  }
  .footer {
    text-align: center;
  }
  .handle-box {
    width: 80%;
    text-align: right;
    margin: 0 auto;
  }
  .upload-file {
    display: inline-block;
    margin-right: 20px;
  }
  .table-td-thumb {
    display: block;
    margin: auto;
    width: 40px;
    height: 40px;
  }
}
::v-deep {
  .el-table__header th .el-checkbox {
    display: none;
  }
}
</style>
