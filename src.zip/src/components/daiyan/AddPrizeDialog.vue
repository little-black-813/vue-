<template>
  <el-dialog :title="title" center :visible.sync="showDia" :show-close="false"  :close-on-click-modal="false" :close-on-press-escape="false" :destroy-on-close="true">

    <el-form ref="prizeForm" :model="prizeForm" :rules="rules" label-width="120px">
      <el-form-item label="奖品等级:" prop="scope">
        <el-select v-model="prizeForm.scope" size="small" placeholder="奖品等级"  @change="changePrizeType">
          <el-option v-for="item in prizeTypeList" :key="item.scope"  :label="item.label" :value="item.scope"></el-option>
        </el-select>
      </el-form-item>

      <el-form-item label="奖品名称:" prop="prizeName"><el-input v-model.trim="prizeForm.prizeName" autocomplete="off" placeholder="奖品名称"></el-input></el-form-item>


      <el-form-item label="奖品数量:" prop="prizeNumber"><el-input-number v-model.trim="prizeForm.prizeNumber" placeholder="奖品数量" controls-position="right" :min="0" ></el-input-number></el-form-item>

       <!-- <el-form-item label="奖品图片:" prop="prizeUrl"><el-input type="hidden" v-model="prizeForm.prizeUrl" autocomplete="off"></el-input>
       <v-uploadimg labelKey="prizeUrl" :id="$store.state.activityId" c="prizeImgUrl" :imgUrl="prizeForm.prizeImage"></v-uploadimg>
       </el-form-item> -->
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="resetForm('prizeForm')">取 消</el-button>
      <el-button type="primary" @click="submitForm('prizeForm')">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
import bus from 'components/common/bus';
import {mapState} from 'vuex';
import { addPrizeReq } from 'api/daiyan/dyActivity.js'
import {isEmptyValue} from '@/utils/utils';
export default {
  props: ['formInit','show','selInd','type'],
  data() {
    return {
      showDia: this.show,
      ind:'',
      title:"增加奖品",
      showLink:false,
      showOfferId:false,
      prizeTypeList:[
        {
          label: '一等奖',
          scope: '1',
        },
        {
          label: '二等奖',
          scope: '2'
        },
        {
          label: '三等奖',
          scope: '3'
        }
      ],
      prizeInitForm: {
        prizeName: '',
        prizeNumber:'',
        scope:'',
      },
      rules:{
      	scope: [{ required: true, message: '请选择奖品类型', trigger: 'change' }],
        prizeName: [{ required: true, message: '请输入奖品名称', trigger: 'blur' }],
        prizeNumber: [{ required: true, message: '请填写奖品数量', trigger: 'change' }],
      }
    };
  },
  computed:{
    ...mapState({baseInfo:'activityBaseInfo'}),
    prizeForm(){
      if(this.formInit){
         this.title = "编辑奖品";
         return this.formInit
      }
      return this.prizeInitForm;
    },
    getActivityId(){
      let id=this.$store.state.activityId;
       if(this.type==='edit'){
       	id = this.$route.query.id;
       }
        return id;
    }
  },
  created() {
  },
  methods: {
    changePrizeType(e) {
      this.$set(this.prizeForm, 'scope', e);
    },
    submitForm(formName) {
      console.log(formName, 'formName')
      // return false
      let {prizeList} = this.baseInfo;
      console.log({...this.prizeForm,activityId:this.getActivityId})
      this.$refs[formName].validate(valid => {
        if (valid) {
          let reqUrl = '/dy/api/data/dyPrize/addPrize'
          if(this.formInit){
            reqUrl = '/dy/api/data/dyPrize/updatePrize'
          }
          this.addPrize({reqUrl,prizeForm:{...this.prizeForm,activityId:this.getActivityId}});
          //存储vuex，上一步时，可以会显
        } else {
          return false;
        }
      });
    },
    addPrize(params){///data/prize/updatePrize
      addPrizeReq(params).then(res=>{
        this.showDia = false
        if(res.resultStat==='SUCCESS'){
        	this.$refs.prizeForm.resetFields();
          bus.$emit('dyPrizeCb',{show:false,selInd:this.selInd,reqFlag:true});
          if(isEmptyValue(this.selInd)){
            this.$message({
              message: '恭喜你，新增奖品成功',
              type: 'success'
            });
          }else{
            this.$message({
              message: '恭喜你，修改奖品成功',
              type: 'success'
            });
          }
        }
      })
    },

    resetForm(name){
    	this.showDia = false;
    	this.$refs[name].resetFields();
    	bus.$emit('dyPrizeCb',{show:false});
    },
  }
};
</script>

<style></style>
