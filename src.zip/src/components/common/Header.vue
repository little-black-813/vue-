<template>
  <div class="header">
    <div class="logo">
      <img src="../../assets/logo.png" alt="logo" />
      <span>活动配置管理系统</span>
    </div>
    <div class="header-right">
      <div class="header-con">
        <!-- 用户头像 -->
        <div class="user-avator"><img :src="avatar" /></div>
        <!-- 用户名下拉菜单 -->
        <el-dropdown class="user-name" trigger="click" @command="handleCommand">
          <span class="el-dropdown-link">
            {{ userInfo.adminName }}
            <i class="el-icon-caret-bottom"></i>
          </span>
          <el-dropdown-menu slot="dropdown"><el-dropdown-item divided command="loginout">退出登录</el-dropdown-item></el-dropdown-menu>
        </el-dropdown>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex';
import { signout } from '@/api/user';
import {baseImgPath} from '@/config'
import avatar from "@assets/img/img.jpg"
export default {
  data() {
    return {
      baseImgPath,
      avatar
    };
  },
  computed:{
    ...mapState(['userInfo'])
  },
  methods: {
    // 用户名下拉菜单选择事件
    handleCommand(command) {
      if (command == 'loginout') {
        signout().then(res=>{
          if(res.flag){
            this.$store.dispatch('setUserInfo',{})
            this.$router.push('/login');
          }else{
            this.$message({
                type: 'error',
                message: '退出失败'
              });
          }
        })

      }
    }
  }
};
</script>

<style lang="less" scoped="scoped">
.header {
  position: relative;
  box-sizing: border-box;
  padding: 10px 30px;
  width: 100%;
  font-size: 22px;
  color: #f1eded;
  clear: both;
  overflow: hidden;

}
.logo {
  display: inline-block;
  vertical-align: middle;
  font-size: 0;
  img {
    width: 30px;
    margin-right: 10px;
    vertical-align: middle;
  }
  span {
    display: inline-block;
    font-size: 18px;
    vertical-align: middle;
  }
}
.header-right {
    float: right;
    padding-right: 50px;
  }
.header-con{
  display: inline-block;
  vertical-align: middle;
}
.user-name {
    margin-left: 10px;
}
.user-avator {
    display: inline-block;
    vertical-align: middle;
}
.user-avator img {
    display: block;
    width: 40px;
    height: 40px;
    border-radius: 50%;
}
.el-dropdown-link {
    color: #fff;
    cursor: pointer;
}
.el-dropdown-menu__item{
  min-width: 60px;
}
</style>
