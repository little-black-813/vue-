<template>
  <el-dialog
    title="提示"
    :visible.sync="showVisible"
    width="30%"
    center
     :close-on-click-modal="false" :close-on-press-escape="false"
    >
    <span>确定要删除：【{{name}}】吗？</span>
    <span slot="footer" class="dialog-footer">
      <el-button @click="closeDialog">取 消</el-button>
      <el-button type="primary"  :loading="loading" @click="sureDialog">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import bus from 'components/common/bus';
import { postReq } from 'api/commonApi'
export default{
  props:['show','param','selInd','name','url', 'callback'],
  data(){
    return {
      showVisible:this.show,
      loading:false
    }
  },
  methods:{
    sureDialog(){
      this.loading = true;
      postReq({reqUrl:this.url,form:this.param}).then(res=>{
        this.showVisible = false;
        console.log(this.callback ||'closeDel')
        bus.$emit( (this.callback ||'closeDel'),{show:false,reqFlag:true,});
      }).catch(err=>{
        this.showVisible = false;
        bus.$emit((this.callback ||'closeDel'),{show:false,reqFlag:false});
      })
    },
    closeDialog(){
      this.showVisible = false;
      bus.$emit((this.callback ||'closeDel'),{show:false,reqFlag:false});
    }
  },
}
</script>

<style>
</style>
