<template>
    <el-dialog :title="title" center :visible.sync="showDia" :show-close="false"  :close-on-click-modal="false" :close-on-press-escape="false" :destroy-on-close="true">
      <el-form ref="turntableForm" :model="turntableForm" :rules="rules" label-width="100px">
        <el-form-item label="奖项名称：" prop="imgName">
          <el-input
            type="text"
            v-model.trim="turntableForm.imgName"
            placeholder="请输入奖项名称"
          ></el-input>
        </el-form-item>
        <!-- <el-form-item label="奖项类型：" prop="imgType">
          <el-select v-model="turntableForm.imgType" size="small" placeholder="奖项类型"  @change="changePrizeType">
            <el-option v-for="item in prizeTypeList" :key="item.imgType"  :label="item.label" :value="item.imgType"></el-option>
          </el-select>
        </el-form-item> -->
        <template v-if="showLink">
          <el-form-item label="奖项链接：" prop="imgLink"><el-input v-model.trim="turntableForm.imgLink" autocomplete="off" placeholder="请输入奖项业务链接"></el-input></el-form-item>
        </template>
        <!-- <template v-if="showOfferId">
          <el-form-item label="业务类OfferId：" prop="offerId"><el-input v-model.trim="turntableForm.offerId" autocomplete="off" placeholder="请输入业务类OfferId"></el-input></el-form-item>
        </template> -->
        <el-form-item label="奖项图片:" prop="imgId"><el-input type="hidden" v-model="turntableForm.imgId" autocomplete="off"></el-input>
        <v-uploadimg labelKey="imgId" upImagSize='158px x 176px' :id="getActivityId" c="prizeImgUrl" :imgUrl="imgForm.imgId"></v-uploadimg>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="resetForm('turntableForm')">取 消</el-button>
        <el-button type="primary" @click="submitForm('turntableForm')">确 定</el-button>
      </div>
    </el-dialog>
</template>

<script>
import bus from 'components/common/bus';
import {mapState} from 'vuex';
import vUploadimg from 'components/common/uploadImg'
import { setPrizeReq } from 'api/setTurntable'
import { isEmptyValue } from '@/utils/utils';
export default{
  components:{
    vUploadimg
  },
  props: ['formInit','show','selInd','type'],
  data(){
    return {
      showDia: this.show,
      title:"增加奖项",
      showLink:true,
      showOfferId:false,
      turntableInitForm:{
        imgType:'3',
        offerId:'',
        imgLink:'',
        imgName:'',
        imgId:'',//编辑为图片路径
      },
      imgForm:{
        imgId:''
      },
      prizeTypeList:[
        {
          label: '话费',
          imgType: '1',
        },
        {
          label: '业务类',
          imgType: '2'
        },
        {
          label: '第三方H5',
          imgType: '3'
        }
      ],
      rules:{
        imgName:[{ required: true, message: '请输入奖项名称', trigger: 'blur' }],
        imgLink:[{ required: false, message: '请输入奖项业务链接', trigger: 'blur' }],
        imgId:[{ required: true, message: '请上传奖项图片', trigger: 'blur' }],
      }
    }
  },
  computed:{
    turntableForm(){
      let _that = this;
      if(_that.formInit){
        _that.title = "编辑奖项";
        if(_that.formInit.imgType==='3') {
          _that.showLink = true;
         }
        if(_that.formInit.imgType==='2'){
          _that.showOfferId = true;
         }
        _that.turntableInitForm = {..._that.formInit};
        _that.imgForm.imgId = _that.formInit.imgId;
         // return this.formInit;
      }
      return _that.turntableInitForm;
    },
    getActivityId(){
      let id=this.$store.state.activityId;
       if(this.type==='edit'){
       	id = this.$route.query.id;
       }
        return id;
    }
  },
  created() {
  	bus.$on('prizeImgUrl',params=>{
      this.turntableForm[params.labelKey]  =params.id;
      this.imgForm.imgId = params.url;
      console.log(this.turntableForm)
    })
  },
  beforeDestroy() {
    bus.$off('prizeImgUrl');
  },
  methods:{
    changePrizeType(e){
      this.$set(this.turntableForm, 'imgType', e);
      if(e==='3'){
        this.showLink = true;
        this.showOfferId = false;
        this.rules.imgLink = [{ required: true, message: '请输入第三方H5链接地址', trigger: 'change' }];
        this.rules.offerId = [{ required: false, message: '请输入业务类OfferId', trigger: 'change' }];
      }else if(e==='2'){
        this.showLink = false;
        this.showOfferId = true;
        this.rules.offerId = [{ required: true, message: '请输入业务类OfferId', trigger: 'change' }];
        this.rules.imgLink = [{ required: false, message: '请输入第三方H5链接地址', trigger: 'change' }];
      }
      else{
        this.showLink = false;
        this.showOfferId = false;
        this.rules.offerId = [{ required: false, message: '请输入业务类OfferId', trigger: 'change' }];
        this.rules.imgLink = [{ required: false, message: '请输入第三方H5链接地址', trigger: 'change' }];
      }
    },
    submitForm(formName) {
      console.log({...this.turntableForm,activityId:this.getActivityId})
      this.$refs[formName].validate(valid => {
        if (valid) {
          let reqUrl = '/data/plate/addPlate'
          if(this.formInit){
            reqUrl = '/data/plate/setPlate'
          }
          this.setTurntable({reqUrl,turntableForm:{...this.turntableForm,activityId:this.getActivityId}});
          //存储vuex，上一步时，可以会显
        } else {
          return false;
        }
      });
    },
    setTurntable(params){///data/prize/updatePrize
      setPrizeReq(params).then(res=>{
        this.showDia = false
        if(res.flag){
        	this.$refs.turntableForm.resetFields();
          bus.$emit('turnCb',{show:false,selInd:this.selInd,reqFlag:true});
          if(isEmptyValue(this.selInd)){
            this.$message({
              message: '恭喜你，设置转盘奖项成功',
              type: 'success'
            });
          }else{
            this.$message({
              message: '恭喜你，修改转盘奖项成功',
              type: 'success'
            });
          }
        }
      })
    },
    resetForm(name){
    	this.showDia = false;
    	this.$refs[name].resetFields();
    	bus.$emit('turnCb',{show:false});
    }
  }
}
</script>

<style>
</style>
