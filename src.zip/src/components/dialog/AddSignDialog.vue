<template>
  <el-dialog :title="title" center :visible.sync="showDia" :show-close="false"  :close-on-click-modal="false" :close-on-press-escape="false" :destroy-on-close="true" :before-close="beforeHide">
    <el-form class="form" ref="prizeForm" :model="prizeForm" :rules="rules" label-width="170px">
      <el-form-item label="奖品名称:" prop="prizeName"><el-input v-model.trim="prizeForm.prizeName" autocomplete="off" placeholder="奖品名称"></el-input></el-form-item>
      <el-form-item label="奖品类型:" prop="prizeType">
        <el-select  v-model="prizeForm.prizeType" size="small" placeholder="奖品类型"  @change="changePrizeType">
          <el-option v-for="item in signPrizeList" :key="item.prizeType"  :label="item.label" :value="item.prizeType"></el-option>
        </el-select>
      </el-form-item>

    
      <el-form-item label="奖品数量:" prop="prizeNumber"><el-input-number v-model.trim="prizeForm.prizeNumber" placeholder="奖品数量" controls-position="right" :min="0" ></el-input-number></el-form-item>
      <el-form-item v-show="showType == 'change'" label="签到币数量:" prop="goodsPrice"><el-input-number v-model.trim="prizeForm.goodsPrice" placeholder="签到币数量" controls-position="right" :min="0" ></el-input-number></el-form-item>
      <el-form-item v-show="showType == 'plate'" label="中奖概率:" prop="prizeOdds"><el-input-number v-model.trim="prizeForm.prizeOdds" placeholder="中奖概率" controls-position="right" :min="0" :max="100"></el-input-number></el-form-item>
  
       <el-form-item  label="转盘图片:" prop="prizeImg"><el-input type="hidden" v-model="prizeForm.prizeImg" autocomplete="off"></el-input>
       <!-- upImagSize='158px x 176px' -->
        <v-uploadimg labelKey="prizeImg" :id="getActivityId" c="prizeImgUrl" :imgUrl="prizeForm.prizeImg"></v-uploadimg>
       </el-form-item>

    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="resetForm('prizeForm')">取 消</el-button>
      <el-button type="primary" @click="submitForm('prizeForm')">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
import bus from 'components/common/bus';
import {mapState} from 'vuex';
import vUploadimg from 'components/common/uploadImg'
import { addPrizeReq } from 'api/prize'
import { getTurnListReq} from 'api/setTurntable'
import {isEmptyValue,formatDate} from '@/utils/utils';
export default {
  components:{vUploadimg},
  props: ['formInit','show','selInd','type','t', 'childList'],
  data() {
    return {
      showDia: false,
      showImg: true,
      ind:'',
      title:"增加奖品",
      showType:'',//1，话费2，offerId,3:link,4:卡券
      // sign 签到数据
      signPrizeList:[
        {
          label: '转盘类',
          prizeType: 'plate',
        },
        {
          label: '兑换类',
          prizeType: 'change'
        }
      ],
       palteList:[
       {

        }
      ],
      // 签到活动
      sigeFrom: {
        prizeName: '',
        prizeType:'',
        goodsPrice: '', //签到币数量
        prizeOdds:'',
        prizeNumber:'',
        prizeImg:''
      },
      rules:{
        prizeImg:[{ required: true, message: '请上传盘图片', trigger: 'blur' }],
        goodsPrice:[{ required: true, message: '请输入签到币数量', trigger: 'blur' }],
        prizeType: [{ required: true, message: '请选择奖品类型', trigger: 'change' }],
        prizeName: [{ required: true, message: '请输入奖品名称', trigger: 'blur' }],
        prizeNumber: [{ required: true, message: '请填写奖品数量', trigger: 'change' }],
        prizeOdds: [{ required: true, message: '请填写中奖概率', trigger: 'change' }]
      },
      childDate: this.childList,
      isadd:true
    };
  },
  computed:{
    ...mapState({baseInfo:'activityBaseInfo'}),
    prizeForm(){
      let that = this;
      if(that.formInit){
         that.title = "编辑奖品";
         that.showType= that.formInit.prizeType;
         return that.formInit
      }
      return  this.sigeFrom
    },
    getActivityId(){
      let id=this.$store.state.activityId;
       if(this.type==='edit'){
       	id = this.$route.query.id;
       }
        return id;
    },
  },
  created() {
  	this.getTurntable();
  	bus.$on('prizeImgUrl',params=>{
      this.prizeForm[params.labelKey]  =params.id;
      this.prizeForm.prizeUrlId = params.url;
    })
  },
  beforeDestroy() {
    bus.$off('prizeImgUrl');
  },
  methods: {
    changePrizeType(e) {
      this.$set(this.prizeForm, 'prizeType', e);
      this.showType = e;
      // console.log(e, 'e')
      if (e =='change') {
        this.prizeForm.prizeOdds = ''
      }
      let newPrizeType =[];
      // if (e == 'plate') {
        this.childDate.forEach(ele => {
          if (e == 'plate' && ele.prizeType == "转盘类") {
            newPrizeType.push(...[ele.prizeType])
            // console.log(newPrizeType.length)
            if (newPrizeType.length === 8) {
              this.$message({
                message: `奖品类型经满足8个，请勿添加1。`,
                type: 'error'
              });
              this.isadd = true
              // alert( this.isadd ,'1')
              // return ;
            }else {
              this.isadd = false
              // alert( this.isadd , '2')
            }
          }else {
            this.isadd = false
          }
        })
      // }
      // else {
      //   this.isadd = false
      // }
    },
    submitForm(formName) {
      
      let {prizeList} = this.baseInfo;
      // console.log({...this.prizeForm,activityId:this.getActivityId})
      this.$refs[formName].validate(valid => {
        if (valid) {
          // console.log(this.isadd,this.formInit)
          // if(this.formInit===undefined){
          //   if (this.isadd) {
          //     this.$message({
          //       message: `奖品类型经满足8个，请勿添加。`,
          //       type: 'error'
          //     });
          //     return false;
          //   }
          // }
          let reqUrl = '/data/prize/addPrize'

          if(this.formInit){
            reqUrl = '/data/prize/updatePrize'
          }
          if (this.$route.query.t == 's') {
            this.$set(this.prizeForm,'activityType', 'signActivityPrize')
          }else {
            this.$set(this.prizeForm,'activityType', 'plateActivityPrize')
          }
          this.addPrize({reqUrl,prizeForm:{...this.prizeForm,activityId:this.getActivityId}});
          //存储vuex，上一步时，可以会显
        } else {
          return false;
        }
      });
    },
    addPrize(params){///data/prize/updatePrize
      addPrizeReq(params).then(res=>{
        this.showDia = false;
        this.$refs.prizeForm.resetFields();
          // console.log(res, 'res')
        if(res.flag){
          bus.$emit('prizeCb',{show:false,selInd:this.selInd,reqFlag:true});
          // let	{activityBaseInfo:{prizeList}} = this.$store.state;
          if(isEmptyValue(this.selInd)){
            this.$message({
              message: '恭喜你，新增奖品成功',
              type: 'success'
            });
            // prizeList.push(this.prizeForm);
            // this.$store.dispatch('setActivityBaseInfo',{prizeList:prizeList});
          }else{
            this.$message({
              message: '恭喜你，修改奖品成功',
              type: 'success'
            });
            // prizeList.splice(this.selInd,1,this.prizeForm)
            // this.$store.dispatch('setActivityBaseInfo',{prizeList})
          }
        }
      })
    },
    resetForm(name){
    	this.showDia = false;
    	this.$refs[name].resetFields();
    	bus.$emit('prizeCb',{show:false});
    },
     getTurntable(){
       getTurnListReq({activityId:this.getActivityId}).then(res=>{
         if(res.flag){
           this.palteList = res.data.map((item,ind)=>({plateId:item.id.toString(),imgName:item.imgName}));
          //  console.log(this.palteList)
         }
         this.showDia = true;
       })
     },
     changeTime1(val){
         this.$set(this.prizeForm,'createTime',formatDate(val,'yyyy-MM-dd HH:mm:ss'));
     },
     changeTime2(val){
         this.$set(this.prizeForm,'updateTime',formatDate(val,'yyyy-MM-dd HH:mm:ss'));
     },
 
    //  弹窗关闭回调
    beforeHide() {
      this.$emit('beforeHide', false)
    },
 
  }
};
</script>

<style lang="less" scoped="scoped">
  .line {
    text-align: center;
  }
  ::v-deep {
    .el-dialog{
      min-width: 650px;
    }
    .el-dialog__body{
      max-height: 500px;
      overflow-y: auto;
      overflow-x: hidden;
    }
    .el-dialog__footer{
      border-top: 1px solid #EEEEEE;
    }
  }
</style>
