<template>
  <el-dialog title="活动链接" center :visible.sync="showDia" :before-close="handleClose" :close-on-click-modal="false" :close-on-press-escape="false">
    <div class="url-echo"><el-input v-model="url" readonly id="prizeActUrl"></el-input></div>
    <div slot="footer" class="dialog-footer">
      <el-button type="primary" v-clipboard:copy="url" v-clipboard:success="onCopy" v-clipboard:error="onError">复制链接</el-button>
    </div>
  </el-dialog>
</template>

<script>
/**
 * creatUrl 生成url
 * show 是否展示
 * action 动作类型，finish是在新增和边界。列表为空
 * editType edit or add
 * asyncUrl 请求地址
 */
import bus from 'components/common/bus';
import { getLinkReq } from 'api/activity.js';
import {isEmptyValue} from '@/utils/utils.js'
export default {
  props: ['creatUrl', 'show','activityId','action','editType','activityType','asyncUrl'],//生成链接，是否显示，活动id，动作，动作类型
  data() {
    return {
      showDia: false,
      id:this.activityId,
      url:this.creatUrl,
      type:this.activityType
    };
  },
  created() {
    // console.log(this.creatUrl, this.activityType, this.url)
    if(isEmptyValue(this.creatUrl)){
      this.getLink();
    }

  },
  methods: {
    getLink(){
      let ediTactivityType = ''
      // 判断是否是 签到
      if (this.$route.query.t=='s'){
        ediTactivityType = 'signActivity'
        // 是否点击了 签到编辑
      }else if(this.type) {
        ediTactivityType = this.type
        // 否则就是转盘活动
      }else {
        ediTactivityType = 'plateActivity'
      }
      let url = this.asyncUrl || '/data/activityManager/getLink';
      // console.log(this.$route.query, this.type,ediTactivityType,'opopo')
      getLinkReq({url: url,data:{activityId:this.id, activityType:ediTactivityType}}).then(res=>{
        if(res.flag&&res.data){
          this.showDia = true;
          this.url = res.data.link;

        }else{
          bus.$emit('closeDel', false);
          this.$message({
            message: '生成活动链接失败，请稍后再试',
            type: 'error'
          });
        }
      }).catch(err=>{
        bus.$emit('closeDel', false);
      })
    },
    handleClose(done){
      this.showDia = false;
      // 不支持复制
      bus.$emit('closeDel', false);
      done();
    },
    onCopy: function(e) {
      this.$message({
        message: '恭喜你，复制成功',
        type: 'success'
      });
      if(this.action==='finsh'){
        bus.$emit('close_current_tags')
        if(this.editType==='edit'){
          this.$store.dispatch('setEditbaseInfo', { activityInfo: {} });
        }else{
          this.$store.dispatch('setActivityBaseInfo', { activityInfo: {} });
          this.$store.dispatch('setActivityBaseInfo', { setInfo: {} });
          this.$store.dispatch('setActivityBaseInfo', { ruleInfo: {} });
          this.$store.dispatch('setActivityBaseInfo', { shareInfo: {} });
          this.$store.dispatch('setActivityBaseInfo', { prizeList: [] });
          this.$store.dispatch('setActivityId', '');
        }
      }
      this.showDia = false;
      bus.$emit('closeDel', false);
    },
    onError: function(e) {
      this.showDia = false;
      // 不支持复制
      this.$message.error('错了哦，请稍后再试');
      bus.$emit('closeDel', false);
    },
  }
};
</script>

<style></style>
