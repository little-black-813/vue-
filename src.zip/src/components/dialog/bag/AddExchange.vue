<template>
    <el-dialog :title="title" center :visible.sync="showDia" :show-close="false"  :close-on-click-modal="false" :close-on-press-escape="false" :destroy-on-close="true">
      <el-form ref="exchageForm" :model="exchageForm" :rules="rules" label-width="100px">
        <el-form-item label="奖品名称：" prop="exchangeName">
          <el-input
            type="text"
            v-model.trim="exchageForm.exchangeName"
            placeholder="请输入奖品名称"
          ></el-input>
        </el-form-item>
        <el-form-item label="奖品金额：" prop="exchangeAmount"><el-input v-model.trim="exchageForm.exchangeAmount" autocomplete="off" placeholder="请输入奖品金额"></el-input></el-form-item>
        <el-form-item label="奖品数量：" prop="exchangeCount"><el-input v-model.trim="exchageForm.exchangeCount" autocomplete="off" placeholder="请输入奖品数量"></el-input></el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="resetForm('exchageForm')">取 消</el-button>
        <el-button type="primary" @click="submitForm('exchageForm')">确 定</el-button>
      </div>
    </el-dialog>
</template>

<script>
import bus from 'components/common/bus';
import {mapState} from 'vuex';
import vUploadimg from 'components/common/uploadImg'
import { postReq } from 'api/commonApi'
import { isEmptyValue } from '@/utils/utils';

export default{
  components:{
    vUploadimg
  },
  props: ['formInit','show','selInd','type'],
  data(){
    return {
      showDia: this.show,
      title:"增加奖品",
      showLink:true,
      showOfferId:false,
      turntableInitForm:{
        exchangeAmount: '',
        exchangeCount:'',
        exchangeName:'',
        activityType: 'luckyBag'
      },
      rules:{
        exchangeName:[{ required: true, message: '请输入奖品名称', trigger: 'blur' }],
        exchangeAmount:[{ required: true, message: '请输入奖品金额', trigger: 'blur' },
        { pattern: /^([1-9][0-9]*)$/, message: '请重新输入奖品金额，且为正整数', trigger: 'change' }],
        exchangeCount:[{ required: true, message: '请输入奖品数量', trigger: 'blur' },
        { pattern: /^(0|[1-9][0-9]*)$/, message: '请重新输入奖品数量，且为正整数', trigger: 'change' }],
      }
    }
  },
  computed:{
    ...mapState('bag', ['activityId']),
    exchageForm(){
      let _that = this;
      if(_that.formInit){
        _that.title = "编辑奖品";
        _that.turntableInitForm = {..._that.formInit};
         // return this.formInit;
      }
      return _that.turntableInitForm;
    },
    getActivityId(){
      let id=this.activityId;
       if(this.type==='edit'){
       	id = this.$route.query.id;
       }
        return id;
    }
  },
  methods:{
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          let reqUrl = '/bagActivityExchange/addExchange'
          if(this.formInit){
            reqUrl = '/bagActivityExchange/updateExchange'
          }
          this.setTurntable({reqUrl,form:{...this.exchageForm,activityId:this.getActivityId}});
          //存储vuex，上一步时，可以会显
        } else {
          return false;
        }
      });
    },
    setTurntable(params){///data/prize/updatePrize
      postReq(params).then(res=>{
        this.showDia = false
        this.$refs.exchageForm.resetFields();
        if(isEmptyValue(this.selInd)){
          this.$message({
            message: '恭喜你，设置奖品成功',
            type: 'success'
          });
        }else{
          this.$message({
            message: '恭喜你，修改奖品成功',
            type: 'success'
          });
        }
        bus.$emit('exchangeCallback',{show:false,selInd:this.selInd,reqFlag:true});
      })
    },
    resetForm(name){
    	this.showDia = false;
    	this.$refs[name].resetFields();
    	bus.$emit('exchangeCallback',{show:false});
    }
  }
}
</script>

<style>
</style>
