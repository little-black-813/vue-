<template>
  <el-dialog :title="title" center :visible.sync="showDia" :show-close="false"  :close-on-click-modal="false" :close-on-press-escape="false" :destroy-on-close="true" >
    <el-form class="form" ref="bagForm" :model="bagForm" :rules="rules" label-width="170px">
      <el-form-item label="福袋名称:" prop="prizeName"><el-input v-model.trim="bagForm.prizeName" autocomplete="off" placeholder="福袋名称"></el-input></el-form-item>
      <el-form-item label="福袋类型:" prop="prizeType">
        <el-select  v-model="bagForm.prizeType" size="small" placeholder="福袋类型"  >
         <el-option v-for="item in typeList" :key="item.prizeType"  :label="item.label" :value="item.prizeType"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item v-if="bagForm.prizeType === 1" label="福袋金额:" prop="prizeAmount"><el-input v-model.trim="bagForm.prizeAmount" placeholder="福袋金额" ></el-input></el-form-item>
      <el-form-item label="福袋数量:" prop="prizeCount"><el-input-number v-model.trim="bagForm.prizeCount" placeholder="福袋数量" controls-position="right" :min="0" ></el-input-number></el-form-item>
      <el-form-item label="中奖概率:" prop="prizePercent"><el-input-number v-model.trim="bagForm.prizePercent" placeholder="中奖概率" controls-position="right" :min="0" :max="100"></el-input-number></el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="resetForm('bagForm')">取 消</el-button>
      <el-button type="primary" @click="submitForm('bagForm')">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
import bus from 'components/common/bus';
import {mapState} from 'vuex';
import vUploadimg from 'components/common/uploadImg'
import { postReq } from 'api/commonApi'
import {isEmptyValue} from '@/utils/utils';
export default {
  components:{vUploadimg},
  props: ['formInit','show','selInd','type','callback', 'childList'],
  data() {
    return {
      showDia: this.show,
      showImg: true,
      ind:'',
      title:"增加福袋",
      typeList:[
        {
          label: '福袋券',
          prizeType: 1,
        },
        {
          label: '谢谢参与',
          prizeType: 2
        }
      ],
      // 转盘活动
      prizeInitForm: {
        activityType: 'luckyBag',
        prizeType: 1,
        prizeName: '',
        prizeCount:'',
        prizePercent:'',
        prizeAmount:''
      },
      rules:{
        prizeType: [{ required: true, message: '请选择福袋类型', trigger: 'change' }],
        prizeName: [{ required: true, message: '请输入福袋名称', trigger: 'blur' }],
        prizeAmount: [{ required: true, message: '请输入福袋金额', trigger: 'blur' }],
        prizeCount: [{ required: true, message: '请填写福袋数量', trigger: 'change' },
        { pattern: /^(0|[1-9][0-9]*)$/, message: '请重新输入福袋数量，且为正整数', trigger: 'change' }],
        prizePercent: [{ required: true, message: '请填写中奖概率', trigger: 'change' }],
      },
      isadd:true
    };
  },
  watch: {
    'bagForm.prizeType' (newV, oldV){
     let required = false;
     if(newV === 1) {
       required=true;
     }else {
       this.$set( this.bagForm , 'prizeAmount' ,'')
     }
     this.$set(this.rules,'prizeAmount', [{ required, message: '请输入福袋金额', trigger: 'blur' }])
    },
  },
  computed:{
    ...mapState('bag', ['activityId']),
    bagForm(){
      let that = this;
      if(that.formInit){
         that.title = "编辑";
         that.showType= that.formInit.prizeType;
         return that.formInit
      }
      return this.prizeInitForm
    },
    getActivityId(){
      let id=this.activityId;
       if(this.type==='edit'){
       	id = this.$route.query.id;
       }
        return id;
    },
  },
  methods: {
    submitForm(formName) {
      // console.log({...this.bagForm,activityId:this.getActivityId})
      this.$refs[formName].validate(valid => {
        if (valid) {
          let reqUrl = '/bagActivityPrize/addPrize'
          if(this.formInit){
            reqUrl = '/bagActivityPrize/updatePrize'
          }

          this.addBag({reqUrl,form:{...this.bagForm,activityId:this.getActivityId}});
          //存储vuex，上一步时，可以会显
        } else {
          return false;
        }
      });
    },
    addBag(params){///data/prize/updatePrize
      postReq(params).then(res=>{
        this.showDia = false;
        this.$refs.bagForm.resetFields();
        bus.$emit(this.callback,{show:false,selInd:this.selInd,reqFlag:true});
        if(isEmptyValue(this.selInd)){
          this.$message({
            message: '恭喜你，新增福袋成功',
            type: 'success'
          });
        }else{
          this.$message({
            message: '恭喜你，修改福袋成功',
            type: 'success'
          });
        }
      }).catch(err=>{
         bus.$emit(this.callback,{show:false,selInd:this.selInd,reqFlag:true});
      })
    },
    resetForm(name){
    	this.showDia = false;
    	this.$refs[name].resetFields();
      console.log(this.callback)
    	bus.$emit(this.callback,{show:false});
    },
  }
};
</script>

<style lang="less" scoped="scoped">
  .line {
    text-align: center;
  }
  ::v-deep {
    .el-dialog{
      min-width: 650px;
    }
    .el-dialog__body{
      max-height: 500px;
      overflow-y: auto;
      overflow-x: hidden;
    }
    .el-dialog__footer{
      border-top: 1px solid #EEEEEE;
    }
  }
</style>
