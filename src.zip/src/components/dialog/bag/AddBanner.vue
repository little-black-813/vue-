<template>
    <el-dialog :title="title" center :visible.sync="showDia" :show-close="false"  :close-on-click-modal="false" :close-on-press-escape="false" :destroy-on-close="true">
      <el-form ref="bannerForm" :model="bannerForm" :rules="rules" label-width="130px">
        <el-form-item label="名字:" prop="bannerName">
          <el-input
            type="text"
            v-model.trim="bannerForm.bannerName"
            placeholder="请输入banner名称"
          ></el-input>
        </el-form-item>
        <el-form-item label="banner图片:" prop="bannerImage"><el-input type="hidden" v-model="bannerForm.bannerId" autocomplete="off"></el-input>
        <v-uploadimg labelKey="bannerImage" imgType="16" :upUrl="path" upImagSize='678px x 330px' :id="getActivityId" :extendData="imgExtendData" c="bannerUrlCallback" :imgUrl="getFullPath()"></v-uploadimg>
        </el-form-item>
        <el-form-item label="权重:" prop="bannerWeight">
          <el-input
            type="number"
            v-model.trim="bannerForm.bannerWeight"
            placeholder="请输入权重"
          ></el-input>
        </el-form-item>
        <el-form-item label="业务链接:" prop="bannerJumpUrl">
          <el-input
            type="text"
            v-model.trim="bannerForm.bannerJumpUrl"
            placeholder="请输入业务链接"
          ></el-input>
        </el-form-item>
        <el-form-item label="是否为目标客户:" prop="isTarget">
            <el-radio-group v-model="bannerForm.isTarget">
              <el-radio label="1">是</el-radio>
              <el-radio label="0">否</el-radio>
            </el-radio-group>
          </el-form-item>
          <!-- <el-form-item label="目标客户：" v-if="showFile" prop="file">
            <upload-file path=""></upload-file>
          </el-form-item> -->

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="resetForm('bannerForm')">取 消</el-button>
        <el-button type="primary" @click="submitForm('bannerForm')">确 定</el-button>
      </div>
    </el-dialog>
</template>

<script>
import bus from 'components/common/bus';
import {mapState} from 'vuex';
import vUploadimg from 'components/common/uploadImg'
import UploadFile from 'components/common/UploadFile'
import { postReq } from 'api/commonApi.js'
import { isEmptyValue } from '@/utils/utils';
import { baseUploadUrl } from '@/config'
export default{
  components:{
    vUploadimg,
    UploadFile
  },
  props: ['formInit','show','selInd','type'],
  data(){
    return {
      showDia: this.show,
      title:"增加banner",
      initForm:{
        bannerId:'',
        bannerWeight:'',
        bannerJumpUrl:'',
        bannerImage:'',//编辑为图片路径
        isTarget: ''
      },
      showFile: false,
      rules:{
        bannerName: [{ required: true, message: '请输入banner名字', trigger: 'blur' }],
        bannerImage:[{ required: true, message: '请上传banner图片', trigger: 'blur' }],
        bannerWeight:[{ required: true, message: '请输入权重', trigger: 'change' },
              { pattern: /^(([1-9])|([1-9][0-9]){0,2})$/, message: '请重新输入权重，且最大为99', trigger: 'change' }
        ],
        isTarget:[{ required: true, message: '请选择是否为目标客户', trigger: 'blur' }],
        file:[{ required: false, message: '请上传目标客户', trigger: 'blur' }],
      }
    }
  },
  computed:{
    ...mapState('bag', ['activityId' , 'httpDomain']),
    imgExtendData(){
      let bannerId = '';
      if(this.formInit){
        bannerId = this.formInit.bannerId;
      }
      return {imageType:'16' , activityId:this.activityId, oldId:bannerId}
    },
    path () {
      return  `${baseUploadUrl}/fileManege/imageUpload`
    },
    bannerForm(){
      let _that = this;
      if(_that.formInit){
         _that.title = "编辑banner";
         _that.initForm = {...this.formInit,isTarget: this.formInit.isTarget+''};
      }
      return this.initForm;
    },
    getActivityId(){
      let id=this.activityId;
       if(this.type==='edit'){
       	id = this.$route.query.id;
       }
        return id;
    }
  },
  // watch:{
  //   'bannerForm.isTarget' (newV,oldV){
  //     let required = false,showFile = false;
  //     if(newV === '1') {
  //       showFile  = true
  //       required = true
  //     }
  //     this.$set(this.$data, 'showFile', showFile)
  //     this.$set(this.rules, 'file', [{ required, message: '请上传目标客户', trigger: 'blur' }])
  //   }
  // },
  created() {
  	bus.$on('bannerUrlCallback',params=>{
      this.bannerForm['bannerId']  =params.id;
      this.imgExtendData['oldId'] = params.id
      this.bannerForm.bannerImage = params.url;
    })
    bus.$on('upFileActon',params=>{
      this.bannerForm.file =params.fileId;
    })
  },
  beforeDestroy() {
    bus.$off('bannerUrlCallback');
    bus.$off('upFileActon');
  },
  methods:{
    getFullPath () {
      return (this.bannerForm['bannerImage'] && (this.httpDomain+this.bannerForm['bannerImage'])) || ''
    },
    submitForm(formName) {
      console.log({...this.bannerForm,activityId:this.getActivityId})
      this.$refs[formName].validate(valid => {
        console.log(this.bannerForm)
        if (valid) {
          this.setTurntable({reqUrl:'/bagActivityBanner/updateBanner',form:{...this.bannerForm,activityId:this.getActivityId}});
          //存储vuex，上一步时，可以会显
        } else {
          return false;
        }
      });
    },
    setTurntable(params){///data/prize/updatePrize
      postReq(params).then(res=>{
        this.showDia = false
        	this.$refs.bannerForm.resetFields();
          bus.$emit('bannerCallback',{show:false,selInd:this.selInd,reqFlag:true});
          if(isEmptyValue(this.selInd)){
            this.$message({
              message: '恭喜你，设置banner成功',
              type: 'success'
            });
          }else{
            this.$message({
              message: '恭喜你，修改banner成功',
              type: 'success'
            });
          }
      }).catch(error=>{
        bus.$emit('bannerCallback',{show:false,selInd:this.selInd,reqFlag:false});
      })
    },
    resetForm(name){
    	this.showDia = false;
    	this.$refs[name].resetFields();
    	bus.$emit('bannerCallback',{show:false});
    }
  }
}
</script>

<style>
</style>
