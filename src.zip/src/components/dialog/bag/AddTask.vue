<template>
    <el-dialog :title="title" center :visible.sync="showDia" :show-close="false"  :close-on-click-modal="false" :close-on-press-escape="false" :destroy-on-close="true">
      <el-form ref="taskForm" :model="taskForm" :rules="rules" label-width="100px">
        <el-form-item label="任务名称：" prop="taskName">
          <el-input
            type="text"
            v-model.trim="taskForm.taskName"
            placeholder="请输入任务名称"
          ></el-input>
        </el-form-item>
        <el-form-item label="任务类型：" prop="taskType">
          <el-select v-model="taskForm.taskType" size="small" placeholder="任务类型" >
            <el-option v-for="item in typeList" :key="item.type"  :label="item.label" :value="item.type"></el-option>
          </el-select>
        </el-form-item>
        <template v-if="showLink">
          <el-form-item label="任务链接：" prop="jumpUrl"><el-input v-model.trim="taskForm.jumpUrl" autocomplete="off" placeholder="请输入任务链接"></el-input></el-form-item>
        </template>
        <el-form-item label="任务图片:" prop="taskIcon"><el-input type="hidden" v-model="taskForm.taskIcon" autocomplete="off"></el-input>
        <v-uploadimg labelKey="taskIcon" imgType="13" :upUrl="path" upImagSize='64px x 64px' :id="getActivityId" :extendData="imgExtendData" c="taskUrlCallback" :imgUrl="getFullPath()"></v-uploadimg>
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="resetForm('taskForm')">取 消</el-button>
        <el-button type="primary" @click="submitForm('taskForm')">确 定</el-button>
      </div>
    </el-dialog>
</template>

<script>
import bus from 'components/common/bus';
import {mapState} from 'vuex';
import vUploadimg from 'components/common/uploadImg'
import { postReq } from 'api/commonApi.js'
import { isEmptyValue } from '@/utils/utils';
import { baseUploadUrl } from '@/config'
export default{
  components:{
    vUploadimg
  },
  props: ['formInit','show','selInd','type'],
  data(){
    return {
      showDia: this.show,
      title:"增加任务",
      showLink:false,
      initForm:{
        activityType: 'lunckyBag',
        taskType: 1,
        taskName:'',
        jumpUrl:'',
        taskIcon:'',
        taskId:''
      },
      typeList:[
        {
          label: '登录任务',
          type: 1,
        },
        {
          label: '跳转任务',
          type: 2
        }
      ],
      rules:{
        taskName:[{ required: true, message: '请输入任务名称', trigger: 'blur' }],
        jumpUrl:[{ required: false, message: '请输入任务链接', trigger: 'blur' }],
        taskIcon:[{ required: true, message: '请输入上传任务icon', trigger: 'blur' }],
      }
    }
  },
  computed:{
    ...mapState('bag', ['activityId', 'httpDomain']),
    imgExtendData(){
      let taskId = '';
      if(this.formInit){
        taskId = this.formInit.taskId;
      }
      return {imageType:'13' , activityId:this.activityId, oldId:taskId, activityType:'luckyBag'}
    },
    path () {
      return  `${baseUploadUrl}/fileManege/imageUpload`
    },
    taskForm(){
      let _that = this;
      if(_that.formInit){
         _that.title = "编辑任务";
         if(_that.formInit.taskType === 2) {
           _that.showLink = true;
         }

         _that.initForm = {..._that.formInit,taskType: _that.formInit.taskType};
         // this.imgForm.imgId = this.formInit.imgId;
         // return this.formInit;
      }
      return _that.initForm;
    },
    getActivityId(){
      let id=this.activityId;
       if(this.type==='edit'){
       	id = this.$route.query.id;
       }
        return id;
    }
  },
  watch:{
    'taskForm.taskType' (newV,oldV){
      console.log(newV,oldV)
      let required = false,showLink = false;
      if(newV === 2) {
        showLink  = true
        required = true
      }else{
        this.$set(this.taskForm, 'jumpUrl' , "")
      }
      this.$set(this.$data, 'showLink', showLink)
      this.$set(this.rules, 'jumpUrl', [{ required, message: '请输入任务链接地址', trigger: 'blur' }])
    }
  },
  created() {
  	bus.$on('taskUrlCallback',params=>{
      this.taskForm['taskId']  = params.id;
      this.imgExtendData['oldId'] = params.id
      this.taskForm.taskIcon  = params.url;
    })
  },
  beforeDestroy() {
    bus.$off('taskUrlCallback');
  },
  methods:{
    getFullPath () {
      return (this.taskForm['taskIcon'] && (this.httpDomain+this.taskForm['taskIcon'])) || ''
    },
    submitForm(formName) {
      console.log({...this.taskForm,activityId:this.getActivityId})
      this.$refs[formName].validate(valid => {
        if (valid) {
          let reqUrl = '/bagActivityTask/updateActivityTask'
          // let reqUrl = '/bagActivityTask/addActivityTask'
          // if(this.formInit){
          //   reqUrl = '/bagActivityTask/updateActivityTask'
          // }
          this.setTurntable({reqUrl,form:{...this.taskForm,activityId:this.getActivityId}});
          //存储vuex，上一步时，可以会显
        } else {
          return false;
        }
      });
    },
    setTurntable(params){///data/prize/updatePrize
      postReq(params).then(res=>{
        this.showDia = false
        this.$refs.taskForm.resetFields();

        if(isEmptyValue(this.selInd)){
          this.$message({
            message: '恭喜你，设置成功',
            type: 'success'
          });
        }else{
          this.$message({
            message: '恭喜你，修改成功',
            type: 'success'
          });
        }
        bus.$emit('taskCb',{show:false,selInd:this.selInd,reqFlag:true});
      }).catch(err=>{
        console.log('error--',err)
        this.$refs.taskForm.resetFields();
        bus.$emit('taskCb',{show:false,selInd:this.selInd,reqFlag:false});
      })
    },
    resetForm(name){
    	this.showDia = false;
    	this.$refs[name].resetFields();
    	bus.$emit('taskCb',{show:false});
    }
  }
}
</script>

<style>
</style>
