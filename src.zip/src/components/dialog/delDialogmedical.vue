<template>
  <el-dialog
    title="提示"
    :visible.sync="showVisible"
    width="30%"
    center
     :close-on-click-modal="false" :close-on-press-escape="false"
    >
    <span>确定要删除：【{{name}}】吗？</span>
    <span slot="footer" class="dialog-footer">
      <el-button @click="closeDialog">取 消</el-button>
      <el-button type="primary"  :loading="loading" @click="sureDialog">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import bus from 'components/common/bus';
import {mapState} from 'vuex';
import { delPrizeReqmedical } from 'api/prize'
export default{
  props:['show','id','name','url'],
  data(){
    return {
      showVisible:this.show,
      loading:false
    }
  },
  methods:{
    sureDialog(){
      this.loading = true;
      delPrizeReqmedical({reqUrl:this.url,prizeForm:{activityId:this.id}}).then(res=>{
        if(res.flag){
          this.showVisible = false;
           this.$message({
            message: '删除成功',
            type: 'success'
          });
          bus.$emit('closeDel',{show:false,reqFlag:true,});
        }
      }).catch(err=>{
        this.showVisible = false;
        bus.$emit('closeDel',{show:false,reqFlag:false,});
      })
    },
    closeDialog(){
      this.showVisible = false;
      bus.$emit('closeDel',{show:false,reqFlag:false,});
    }
  },
}
</script>

<style>
</style>
