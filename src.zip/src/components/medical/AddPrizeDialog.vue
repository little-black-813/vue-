<template>
  <el-dialog
    :title="title"
    center
    :visible.sync="showDia"
    :show-close="false"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    :destroy-on-close="true"
  >
    <el-form
      ref="prizeForm"
      :model="prizeForm"
      :rules="rules"
      label-width="120px"
    >
      <el-form-item label="业务名称:" prop="businessName"
        ><el-input
          v-model.trim="prizeForm.businessName"
          autocomplete="off"
          placeholder="业务名称"
        ></el-input
      ></el-form-item>

      <el-form-item label="图片:" prop="businessPhoto">
        <el-input
          type="hidden"
          v-model="prizeForm.businessPhoto"
          autocomplete="off"
        ></el-input>
        <v-uploadimg
          labelKey="businessPhoto"
          :id="$store.state.medical.activityId"
          c="medPrizeCb"
          :imgUrl="prizeForm.businessPhotofont"
        ></v-uploadimg>
      </el-form-item>
      <el-form-item label="业务链接:" prop="businessLink"
        ><el-input
          v-model.trim="prizeForm.businessLink"
          autocomplete="off"
          placeholder="业务链接"
        ></el-input
      ></el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="resetForm('prizeForm')">取 消</el-button>
      <el-button type="primary" @click="submitForm('prizeForm')"
        >确 定</el-button
      >
    </div>
  </el-dialog>
</template>

<script>
import bus from "components/common/bus";
import { mapState } from "vuex";
import { addPrizeReq } from "api/daiyan/dyActivity.js";
import { isEmptyValue } from "@/utils/utils";
import vUploadimg from "components/common/uploadImg";
export default {
  props: ["formInit", "show", "selInd", "type"],
  components: {
    vUploadimg
  },
  data() {
    return {
      showDia: this.show,
      ind: "",
      title: "添加热销业务",
      showLink: false,
      showOfferId: false,
      prizeTypeList: [
        {
          label: "一等奖",
          scope: "1"
        },
        {
          label: "二等奖",
          scope: "2"
        },
        {
          label: "三等奖",
          scope: "3"
        }
      ],
      prizeInitForm: {
        businessLink: "",
        businessName: "",
        businessPhoto: "",
        businessPhotofont: ""
      },
      rules: {
        businessPhoto: [
          { required: true, message: "请上传业务图标", trigger: "change" }
        ],
        businessLink: [
          { required: true, message: "请输入业务链接", trigger: "blur" }
        ],
        businessName: [
          { required: true, message: "请填写业务名称", trigger: "change" }
        ]
      }
    };
  },
  computed: {
    ...mapState({ baseInfo: "activityBaseInfo" }),
    prizeForm() {
      if (this.formInit) {
        this.title = "编辑热销业务";
        console.log(this.formInit);
        this.formInit.businessPhotofont =  this.formInit.businessPhoto
        return this.formInit;
      }
      return this.prizeInitForm;
    },
    getActivityId() {
      let id = this.$store.state.medical.activityId;
      if (this.type === "edit") {
        id = this.$route.query.id;
      }
      return id;
    }
  },
  created() {
    bus.$on('medPrizeCb',params=>{
      this.prizeForm.businessPhoto = params.id;
      this.prizeForm.businessPhotofont  = params.url;
    })
  },
  beforeDestroy() {
  	bus.$off('medPrizeCb');
  },
  methods: {
    changePrizeType(e) {
      this.$set(this.prizeForm, "scope", e);
    },
    submitForm(formName) {
      console.log(formName, "formName");
      // return false
      let { prizeList } = this.baseInfo;
      console.log({ ...this.prizeForm, activityId: this.getActivityId });
      this.$refs[formName].validate(valid => {
        if (valid) {
          let reqUrl = "/data/business/setBusiness";
          if (this.formInit) {
            reqUrl = "/data/business/modifyBusiness";
          }
          delete this.prizeForm.isDelete;
          delete this.prizeForm.businessPhotofont;
          this.addPrize({
            reqUrl,
            prizeForm: {
              ...this.prizeForm,
              activityType: "physicalActivity",
              activityId: this.getActivityId
            }
          });
          //存储vuex，上一步时，可以会显
        } else {
          return false;
        }
      });
    },
    addPrize(params) {
      ///data/prize/updatePrize
      addPrizeReq(params).then(res => {
        this.showDia = false;
        if (res.flag === true) {
          this.$refs.prizeForm.resetFields();
          bus.$emit("medicalPrizeCb", {
            show: false,
            selInd: this.selInd,
            reqFlag: true
          });
          if (isEmptyValue(this.selInd)) {
            this.$message({
              message: "恭喜你，新增业务成功",
              type: "success"
            });
          } else {
            this.$message({
              message: "恭喜你，修改业务成功",
              type: "success"
            });
          }
        }
      });
    },

    resetForm(name) {
      this.showDia = false;
      this.$refs[name].resetFields();
      bus.$emit("medicalPrizeCb", { show: false });
    }
  }
};
</script>

<style></style>
