<template>
  <div class="base-wrapper">
    <p class="base-title">基础信息</p>
    <el-form
      ref="creatForm"
      :model="creatForm"
      :rules="rules"
      class="creat-act-form"
      label-width="190px"
    >
      <!-- <el-form-item label="活动类型：" prop="activityType">
        <el-select v-model="creatForm.activityType" placeholder="请选择活动类型"><el-option label="抽奖活动" value="1"></el-option></el-select>
      </el-form-item> -->
      <el-form-item label="活动名称：" prop="activityName"
        ><el-input v-model.trim="creatForm.activityName"></el-input
      ></el-form-item>
      <el-form-item label="活动时间：" required>
        <el-col :span="11">
          <el-form-item prop="activityStartTime">
            <el-date-picker
              type="datetime"
              placeholder="选择开始日期"
              @change="changeTime1"
              v-model="creatForm.activityStartTime"
              style="width: 100%;"
            ></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col class="line" :span="2">-</el-col>
        <el-col :span="11">
          <el-form-item prop="activityEndTime">
            <el-date-picker
              type="datetime"
              placeholder="选择截至日期"
              @change="changeTime2"
              v-model="creatForm.activityEndTime"
              style="width: 100%;"
            ></el-date-picker>
          </el-form-item>
        </el-col>
      </el-form-item>
      <el-form-item label="其他信息活动链接：" prop="otherActivityUrl"
        ><el-input v-model.trim="creatForm.otherActivityUrl"></el-input
      ></el-form-item>
      <el-form-item label="选择其他套餐链接：" prop="chooseOtherUrl"
        ><el-input v-model.trim="creatForm.chooseOtherUrl"></el-input
      ></el-form-item>
      <el-form-item label="流量包：" prop="flowMealName"
        ><el-input v-model.trim="creatForm.flowMealName"></el-input
      ></el-form-item>
      <el-form-item label="流量包链接：" prop="flowMealAddr"
        ><el-input v-model.trim="creatForm.flowMealAddr"></el-input
      ></el-form-item>
      <el-form-item label="其他信息活动链接：" prop="otherActivityUrl"
        ><el-input v-model.trim="creatForm.otherActivityUrl"></el-input
      ></el-form-item>
      <el-form-item label="联系客服：" prop="contactService"
        ><el-input
          v-model.trim="creatForm.contactService"
          placeholder="配置链接"
        ></el-input
      ></el-form-item>
      <el-form-item label="活动规则：" prop="activityRule"
        ><el-input
          type="textarea"
          v-model.trim="creatForm.activityRule"
        ></el-input
      ></el-form-item>

      <el-form-item>
        <el-button type="primary" @click="submitForm('creatForm')"
          >立即创建</el-button
        >
        <!--<el-button @click="resetForm('creatForm')">{{creatForm.activityType}}重置</el-button>-->
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import bus from "components/common/bus";
import { mapState } from "vuex";
import { createOrEditBaseActivityReq } from "api/medical/dyActivity.js";
import { isEmptyObject, formatDate, isEmptyValue } from "@/utils/utils";
export default {
  data() {
    return {
      isShowCenter: false,
      creatForm: {
        activityName: "",
        otherActivityUrl: "",
        activityInfo: "",
        activityStartTime: "",
        activityEndTime: "",
        activityType:"physicalActivity"
      },

      rules: {
        activityStartTime: [
          {
            type: "string",
            required: true,
            message: "请选择活动开始时间",
            trigger: "change"
          }
        ],
        activityEndTime: [
          {
            type: "string",
            required: true,
            message: "请选择活动结束时间",
            trigger: "change"
          }
        ],
        activityName: [
          { required: true, message: "请输入活动名称", trigger: "blur" }
        ],
        otherActivityUrl: [
          { required: true, message: "请输入其他信息活动", trigger: "blur" }
        ],
        contactService: [
          { required: true, message: "请输入配置链接", trigger: "blur" }
        ],
        chooseOtherUrl: [
          { required: true, message: "请输入其他套餐链接", trigger: "blur" }
        ],
        activityRule: [
          { required: true, message: "请输入活动规则", trigger: "blur" }
        ]
      }
    };
  },
  props: ["type"],
  created() {
    this.creatForm = this.initForm();
  },
  methods: {
    changeTime1(val) {
      this.$set(
        this.creatForm,
        "activityStartTime",
        formatDate(val, "yyyy-MM-dd HH:mm:ss")
      );
    },
    changeTime2(val) {
      this.$set(
        this.creatForm,
        "activityEndTime",
        formatDate(val, "yyyy-MM-dd HH:mm:ss")
      );
    },
    initForm() {
      let activityInfo = this.$store.state.medical.activityBaseInfo.activityInfo;
      if (this.type === "edit") {
        //编辑
        // debugger
        activityInfo = this.$store.state.medical.editBaseInfo.activityInfo;
      }
      if (isEmptyObject(activityInfo)) {
        return this.creatForm;
      } else {
        let p_info = activityInfo;
        return { ...p_info };
      }
    },
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        this.$set(this.creatForm,'activityType', 'physicalActivity')
        if (valid) {
          //存储vuex，上一步时，可以会显
          // this.$store.dispatch('setActivityBaseInfo', { activityInfo: this.creatForm })
          let s_id = this.$store.state.medical.activityId;
          let reqUrl = "/data/activity/addActivity";
          if (!isEmptyValue(s_id) && this.type === "add") {
            reqUrl = "/data/activity/updateActivityInfo";
          }
          console.log(this.type);
          if (this.type === "edit") {
            reqUrl = "/data/activity/updateActivityInfo";
            s_id = this.$route.query.id;
          }
          // console.log({...this.creatForm,activityId:s_id})
         this.createActivity({reqUrl,creatForm:{...this.creatForm,activityId:s_id}});
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    //创建活动基础信息
    createActivity(params) {
      createOrEditBaseActivityReq(params).then(res => {
        if (res.flag === true) {
          this.$message({
            message: "恭喜你，创建基础信息成功",
            type: "success"
          });
          if (this.type === "edit") {
            this.$store.dispatch("medical/setEditbaseInfo", {
              activityInfo: { ...params.creatForm }
            });
          } else {
            this.$store.dispatch("medical/setActivityBaseInfo", {
              activityInfo: { ...params.creatForm }
            });
            if (isEmptyValue(params.creatForm.activityId)) {
              this.$store.dispatch("medical/setActivityId", res.data);
            }
          }
          bus.$emit("medicalOp", "add");
        }
      });
    }
  }
};
</script>

<style scoped="scoped" lang="less">
.base-wrapper {
  .line {
    text-align: center;
  }
  .base-title {
    font-size: 20px;
    margin: 15px 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eeeeee;
  }
  .creat-act-form {
    width: 60%;
  }
}
</style>
