<template>
  <el-dialog :title="title" center :visible.sync="showDia" :show-close="false" :close-on-click-modal="false" :close-on-press-escape="false" :destroy-on-close="true">
    <el-form ref="prizeForm" :model="prizeForm" :rules="rules" label-width="190px">
      <el-form-item label="套餐名称:">
        <el-input v-model.trim="prizeForm.setMealName" autocomplete="off" placeholder="套餐名称"></el-input>
      </el-form-item>
      <el-form-item label="推荐套餐:" prop="setMealCode">
        <el-input v-model.trim="prizeForm.setMealCode" autocomplete="off" placeholder="资费代码"></el-input>
      </el-form-item>
      <el-form-item label="套餐类型:" prop="isIop">
         <el-select v-model="prizeForm.isIop" autocomplete="off" class="marginR" placeholder="请选择" @change="codeChange">
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value">
        </el-option>
        </el-select>
      </el-form-item>
        <el-form-item label="商品code:" prop="productCode" v-if="productCodeStatus">
        <el-input v-model.trim="prizeForm.productCode" autocomplete="off" placeholder="资费代码"></el-input>
      </el-form-item>
      <!-- <el-form-item label="资费档位:" required>
         <el-col :span="11">
          <el-form-item prop="tariffGearBig">
          <el-input class="medium-input" v-model.trim="prizeForm.tariffGearBig" autocomplete="off" placeholder="流量档位大于等于"></el-input>
           </el-form-item>
        </el-col>
        <el-col class="line" :span="2">-</el-col>
        <el-col :span="11">
           <el-form-item prop="tariffGearSmall">
          <el-input class="medium-input" v-model.trim="prizeForm.tariffGearSmall" autocomplete="off" placeholder="流量档位小于等于"></el-input>
            </el-form-item>
        </el-col>
      </el-form-item> -->
      <el-form-item label="流量档位:" :required="requierdRange">
        <el-col :span="11">
          <el-form-item prop="flowGearBig">
            <el-input class="medium-input" type="number" v-model.trim="prizeForm.flowGearBig" autocomplete="off" placeholder="流量档位大于等于"></el-input>
          </el-form-item>
        </el-col>
        <el-col class="line" :span="2">-</el-col>
        <el-col :span="11">
          <el-form-item prop="flowGearSmall">
            <el-input class="medium-input" type="number" v-model.trim="prizeForm.flowGearSmall" autocomplete="off" placeholder="流量档位小于等于"></el-input>
          </el-form-item>
        </el-col>
      </el-form-item>
      <el-form-item label="语音档位:" :required="requierdRange">
        <el-col :span="11">
          <el-form-item prop="voiceGearBig">
            <el-input class="medium-input" type="number" v-model.trim="prizeForm.voiceGearBig" autocomplete="off" placeholder="流量档位大于等于"></el-input>
          </el-form-item>
        </el-col>
        <el-col class="line" :span="2">-</el-col>
        <el-col :span="11">
          <el-form-item prop="voiceGearSmall">
            <el-input class="medium-input" type="number" v-model.trim="prizeForm.voiceGearSmall" autocomplete="off" placeholder="流量档位小于等于"></el-input>
          </el-form-item>
        </el-col>
      </el-form-item>
      <el-form-item label="套餐资费:" prop="setMealTariff">
        <el-input v-model.trim="prizeForm.setMealTariff" autocomplete="off" placeholder="套餐资费"></el-input>
      </el-form-item>
      <el-form-item label="套内流量:" prop="setMealFlow">
        <el-input v-model.trim="prizeForm.setMealFlow" autocomplete="off" placeholder="套内流量"></el-input>
      </el-form-item>
      <el-form-item label="套内语音:" prop="setMealVoice">
        <el-input v-model.trim="prizeForm.setMealVoice" autocomplete="off" placeholder="套内语音"></el-input>
      </el-form-item>
      <el-form-item label="套餐变更链接:" prop="handleLink">
        <el-input v-model.trim="prizeForm.handleLink" autocomplete="off" placeholder="套餐变更链接"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="resetForm('prizeForm')">取 消</el-button>
      <el-button type="primary" :loading="btnLoading" @click="submitForm('prizeForm')">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
import bus from 'components/common/bus'
import { mapState } from 'vuex'
import { addPrizeReq } from 'api/daiyan/dyActivity.js'
import { isEmptyValue } from '@/utils/utils'
import vUploadimg from 'components/common/uploadImg'
export default {
  props: ['formInit', 'show', 'selInd', 'type'],
  components: {
    vUploadimg
  },
  data() {
    return {
      btnLoading: false,
      showDia: this.show,
      ind: '',
      title: '添加套餐',
      requierdRange : true,
      showLink: false,
      showOfferId: false,
      prizeInitForm: {
        setMealName: '',
        // tariffGearBig: '',
        // tariffGearSmall: '',
        flowGearBig: '',
        flowGearSmall: '',
        voiceGearBig: '',
        voiceGearSmall: '',
        setMealFlow: '',
        setMealTariff: '',
        setMealVoice: '',
        handleLink: '',
        activityType: 'physicalActivity',
        setMealCode: '',
        isIop:"0",
        productCode:""
      },
      rules: {
        setMealCode: [
          { required: true, message: '请填写推荐套餐', trigger: 'change' }
        ],
        // tariffGearBig: [
        //   { required: true, message: '请输入套餐资费档位', trigger: 'blur'}
        // ],
        // tariffGearSmall: [
        //   { required: true, message: '请输入套餐资费档位', trigger: 'change' }
        // ],
        flowGearBig: [
          { required: true, message: '请输入流量档位', trigger: 'change' }
        ],
        flowGearSmall: [
          { required: true, message: '请输入流量档位', trigger: 'change' }
        ],
        voiceGearBig: [
          { required: true, message: '请输入语音档位', trigger: 'change' }
        ],
        voiceGearSmall: [
          { required: true, message: '请输入语音档位', trigger: 'change' }
        ],
        handleLink: [
          { required: true, message: '请输入套餐变更链接', trigger: 'blur' }
        ],
        setMealTariff: [
          { required: true, message: '请输入套餐资费', trigger: 'blur' }
        ],
        setMealFlow: [
          { required: true, message: '请输入套餐流量', trigger: 'blur' }
        ],
        setMealVoice: [
          { required: true, message: '请输入套餐语音', trigger: 'blur' }
        ],
        isIop: [
          { required: true, message: '请选择套餐类型', trigger: 'change' }
        ],
        productCode: [
          { required: true, message: '请输入商品code', trigger: 'blur' }
        ],
      },
       options: [{
          value: '0',
          label: '非IOP'
        },{
          value: '1',
          label: 'IOP'
        }],
      productCodeStatus:false
    }
  },
  computed: {
    ...mapState({ baseInfo: 'activityBaseInfo' }),
    prizeForm() {
      let _that = this;
      if (_that.formInit) {
        _that.title = '编辑套餐'
        if(_that.formInit.isIop == 0){ //非iop
          _that.productCodeStatus = false
        }else{
           _that.productCodeStatus = true
        }
        _that.codeChange(_that.formInit.isIop)
        return _that.formInit
      }
      return _that.prizeInitForm
    },
    getActivityId() {
      let id = this.$store.state.medical.activityId
      if (this.type === 'edit') {
        id = this.$route.query.id
      }
      return id
    }
  },
  created() {},
  methods: {
    codeChange(v){
      let ruleFlag = false;
      if(v == 0){ //非iop
        ruleFlag = true
        this.productCodeStatus = false
      }else{
        this.productCodeStatus = true
      }
      this.$set(this.$data,'requierdRange',ruleFlag)
      let ruleList = {
        flowGearBig: [
          { required: ruleFlag, message: '请输入流量档位', trigger: 'change' }
        ],
        flowGearSmall: [
          { required: ruleFlag, message: '请输入流量档位', trigger: 'change' }
        ],
        voiceGearBig: [
          { required: ruleFlag, message: '请输入语音档位', trigger: 'change' }
        ],
        voiceGearSmall: [
          { required: ruleFlag, message: '请输入语音档位', trigger: 'change' }
        ],
      }
      this.rules = {...this.rules,...ruleList}
    },
    submitForm(formName) {
      this.btnLoading = true;
      this.$refs[formName].validate(valid => {
        if (valid) {
          let reqUrl = '/data/setMeal/setSetMeal'
          if(this.prizeForm.isIop == 0){
             this.prizeForm.productCode = ""
          }
          if (this.formInit) {
            reqUrl = '/data/setMeal/modifySetMeal'
          }

          this.addPrize({
            reqUrl,
            prizeForm: {
              ...this.prizeForm,
              activityType: 'physicalActivity',
              activityId: this.getActivityId
            }
          })
          //存储vuex，上一步时，可以会显
        } else {
          this.btnLoading = false;
          return false
        }
      })
    },
    addPrize(params) {
      ///data/prize/updatePrize
      addPrizeReq(params).then(res => {
        this.showDia = false
        this.btnLoading = false;
        if (res.flag === true) {
          this.$refs.prizeForm.resetFields()
          bus.$emit('mdicalCB', {
            show: false,
            selInd: this.selInd,
            reqFlag: true
          })
          if (isEmptyValue(this.selInd)) {
            this.$message({
              message: '恭喜你，新增套餐成功',
              type: 'success'
            })
          } else {
            this.$message({
              message: '恭喜你，修改套餐成功',
              type: 'success'
            })
          }
        }
      })
    },

    resetForm(name) {
      this.showDia = false
      this.$refs[name].resetFields()
      bus.$emit('mdicalCB', { show: false })
    }
  }
}
</script>

<style scoped lang="less">
.line {
  text-align: center;
}

/deep/ input::-webkit-outer-spin-button,
/deep/ input::-webkit-inner-spin-button {
  -webkit-appearance: none !important;
}
/deep/ input[type="number"] {
  -moz-appearance: textfield !important;
}
.marginR{
  width: 100%;
}
</style>
