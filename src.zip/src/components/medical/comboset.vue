<template>
  <div class="base-wrapper">
    <p class="base-title">套餐设置</p>
    <div class="handle-box">
      <div>
      <el-input class="input0617 " v-model="query.setMealName" size="small" placeholder="请输入套餐名称" clearable=""></el-input>
      <el-select v-model="query.isIop" size="small" class="marginR" placeholder="请选择" @change="changePackage">
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value">
        </el-option>
      </el-select>
      <el-button class="marginR" size="small" type="primary" @click="search">查询</el-button>
       </div>
      <el-button plain type="primary" size="medium" @click="addPrize()">增加套餐</el-button>
    </div>
    <el-table v-loading="loading" :data="tableData" ref="prizeTable" :select-on-indeterminate="false" class="prize-table" @selection-change="handleSelectionChange" style="width: 80%">
      <!-- <el-table-column type="selection" align="center" width="55"></el-table-column> -->
      <el-table-column label="序列号" type="index" align="center" :index="table_index" width="90px"></el-table-column>
      <el-table-column v-for="(items, indexs) in prizeList.lableList" :key="indexs" :prop="items.prop" :label="items.lable" align="center" :formatter="items.formatter">
          <template slot-scope="scope">
            <!-- <span v-if="indexs == 1">
                {{scope.row.tariffGearBig}}~{{scope.row.tariffGearSmall}}
            </span> -->
             <span v-if="indexs == 2">
                {{scope.row.voiceGearBig}}~{{scope.row.voiceGearSmall}}
            </span>
             <span v-if="indexs == 3">
                {{scope.row.flowGearBig}}~{{scope.row.flowGearSmall}}
            </span>
            <span v-if="indexs != 2 && indexs != 3">
              {{scope.row[items.prop]}}
            </span>
          </template>
      </el-table-column>

      <el-table-column label="操作" align="center">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="editPrizeRow(scope.row, scope.$index)">编辑</el-button>
          <el-button type="text" size="small" @click="delPrizeRow(scope.row, scope.$index)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination">
      <el-pagination background :hide-on-single-page="true" layout="total, prev, pager, next" :current-page="query.pageSize" :page-size="query.limite" :total="total" @current-change="handlePageChange"></el-pagination>
    </div>

    <div class="footer">
      <el-button @click="prevForm()">上一步</el-button>
      <el-button plain type="primary" @click="submitForm('shareForm')">完成</el-button>
      <!-- <el-button type="danger" @click="createLink()">生成链接</el-button> -->
    </div>
    <!-- <v-linkdialog v-if="linkVisiable" :editType="editType"  action="finsh" :show="linkVisiable"  :activityId="getId"></v-linkdialog> -->
    <v-prizedialog v-if="addVisiable" c="prizeCb" :show="addVisiable" :formInit="selRow[0]" :type="editType" :selInd="selInd"></v-prizedialog>
    <v-deldialog v-if="delVisiable" url="/data/setMeal/removeSetMeal" :show="delVisiable" :name="selRow[0].setMealName" :id="selRow[0].id" :selInd="selInd"></v-deldialog>
  </div>
</template>

<script>
import bus from 'components/common/bus'
import { mapState } from 'vuex'
import vLinkdialog from 'components/dialog/LinkDialog'
import vPrizedialog from 'components/medical/AddComborDialog'
import vDeldialog from 'components/medical/delDialog'
import { getPackageListReq } from 'api/medical/dyActivity.js'
import { isEmptyObject, judgePath, isEmptyValue } from '@/utils/utils'
export default {
  components: {
    vLinkdialog,
    vPrizedialog,
    vDeldialog
  },
  data() {
    return {
      creatUrl: '',
      editType: this.type,
      linkVisiable: false,
      addVisiable: false,
      delVisiable: false,
      selInd: '', //选择table的下标
      extendData: {
        activityId: this.$store.state.medical.activityId,
        prizeId: ''
      },
      prizeList: {
        lableList: [
           {
            lable: '套餐名称',
            type: 'normal',
            prop: 'setMealName'
          },
          {
            lable: '推荐套餐(资费代码)',
            type: 'normal',
            prop: 'setMealCode'
          },
          // {
          //   lable: '资费档位(元)',
          //   type: 'normal',
          //   prop: 'tariffGearBig'
          // },
          {
            lable: '流量档位',
            type: 'normal',
            prop: 'flowGearBig'
          },
          {
            lable: '语音档位',
            type: 'normal',
            prop: 'voiceGearBig'
          },
          {
            lable: '推荐套餐资费(元)',
            type: 'normal',
            prop: 'setMealTariff'
          },
          {
            lable: '套内流量',
            type: 'normal',
            prop: 'setMealFlow'
          },
          {
            lable: '套内语音',
            type: 'normal',
            prop: 'setMealVoice'
          },
          {
            lable: '套餐变更链接',
            type: 'normal',
            prop: 'handleLink'
          }
        ]
      },
      tableData: [],
      query: {
        pageSize: 1,
        limite: 10,
        isIop : "",
        setMealName : ""
      },
      total: 0,
      selRow: [],
         options:  [
           {
             value: '',
             label: '全部'
           },{
          value: '0',
          label: '非IOP'
        },{
          value: '1',
          label: 'IOP'
        }],
      loading:false
    }
  },
  props: ['type'],
  computed: {
    ...mapState({
      baseInfo: 'activityBaseInfo'
    }),
    path() {
      return `${judgePath()}/data/targetUsers/fileUpload`
    },
    getId() {
      if (this.type === 'edit') {
        return this.$route.query.id
      }
      if (this.type === 'add') {
        return this.$store.state.medical.activityId
      }
    }
  },
  created() {
    this.getPrizeList('init')
    bus.$on('mdicalCB', params => {
      console.log('mdicalCB', params)
      this.addVisiable = params.show
      this.selRow = []
      this.selInd = ''
      if (params.reqFlag) {
        this.getPrizeList('req')
      }
    })
    bus.$on('closeDyDel', params => {
      console.log(params)
      this.delVisiable = params.show
      this.linkVisiable = params.show || params
      this.selRow = []
      this.selInd = ''
      if (params.reqFlag) {
        this.$set(this.query,'pageSize', 1);
        this.getPrizeList()
      }
    })
  },
  beforeDestroy() {
    bus.$off('mdicalCB')
    bus.$off('closeDyDel')
  },
  methods: {
    table_index(index){
        return (this.query.pageSize-1) * this.query.limite + index + 1
    },
    changePackage(n){
     this.query.isIop = n
     this.$set(this.query,'pageSize', 1);
     this.getPrizeList();
    },
    search(){
      this.$set(this.query, 'pageSize', 1);
      this.getPrizeList();
    },
    getPrizeList(p) {
      this.loading = true
      console.log(this.query)
      getPackageListReq({ activityId: this.getId, ...this.query }).then(res => {
        if (res.flag) {
           this.loading = false
          // console.log('in---')
          this.tableData = res.data.data
          this.total = res.data.total
        }
      })
    },
    // 分页导航
    handlePageChange(val) {
      this.$set(this.query, 'pageSize', val)
      this.getPrizeList()
    },
    createLink() {
      this.linkVisiable = true
      // bus.$emit('openLink', true);
    },
    prevForm() {
      bus.$emit('medicalOp', 'minus')
    },
    addPrize() {
      this.addVisiable = true
    },
    editPrizeRow(row, ind) {
      this.addVisiable = true
      this.selRow = [row]
      this.selInd = ind
    },
    delPrizeRow(row, ind) {
      this.selRow = [row]
      console.log(this.selRow)
      this.selInd = ind
      this.delVisiable = true
    },
    handleSelectionChange(val) {
      console.log(val)
      let arr = val
      if (arr.length > 1) {
        this.$refs.prizeTable.toggleRowSelection(val[0])
        this.selRow = [val[0]]
        this.extendData.activityId = this.getId
        this.extendData.prizeId = val[0].id
      } else {
        this.selRow = [val[0]]
        this.extendData.activityId = this.getId
        this.extendData.prizeId = val[0].id
      }
    },
    submitForm(){
      window.location.reload()
    }
  }
}
</script>

<style scoped="scoped" lang="less">
.base-wrapper {
  .line {
    text-align: center;
  }
  .base-title {
    font-size: 20px;
    margin: 15px 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eeeeee;
  }
  .prize-table {
    margin: 20px auto;
  }
  .footer {
    text-align: center;
  }
  .handle-box {
    width: 80%;
    display: flex;
    justify-content: space-between;
    margin: 0 auto;
  }
  .upload-file {
    display: inline-block;
    margin-right: 20px;
  }
  .table-td-thumb {
    display: block;
    margin: auto;
    width: 40px;
    height: 40px;
  }
}
::v-deep {
  .el-table__header th .el-checkbox {
    display: none;
  }
}
.input0617 {
    width: 225px;
}
.marginR{
  margin-left: 15px;
}
</style>
