<template>
  <div class="base-wrapper">
    <p class="base-title">活动图片设置</p>
    <el-form ref="setForm" :model="setForm" :rules="rules" label-width="180px" class="creat-act-form">
     <template v-for="item in formList">
        <el-form-item :key="item.prop" :label="item.label+'：'" :prop="item.prop">
          <el-input
            type="hidden"
            :value="setForm[item.prop]"
          ></el-input>
           <v-uploadimg :labelKey="item.prop" :imgType="item.type" :upUrl="path" :id="getId" :upImagSize="item.upImagSize" :extendData="{imageType:item.type,activityId:getId}" :imgUrl="getFullPath(item.prop)"/>
         </el-form-item>
     </template>
      <el-form-item>
        <el-button  @click="prevForm()">上一步</el-button>
        <el-button type="primary" @click="submitForm('setForm')">下一步</el-button>
        <!--<el-button type="danger" @click="resetForm('setForm')">重置</el-button>-->
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import bus from 'components/common/bus';
import { mapState, mapMutations} from 'vuex';
import { postReq } from "api/commonApi.js";
import {isEmptyObject,isEmptyValue} from '@/utils/utils'
import vUploadimg from 'components/common/uploadImg'
import { baseUploadUrl } from '@/config'
export default {
  components:{
    vUploadimg
  },
  data() {
    return {
      formList:[
        {
          label:"活动标题",
          prop:"bagLogo",
          upImagSize:'305px x 56px',
          type: 1
        },
        {
          label:"规则按钮图",
          prop:"ruleBtn",
          upImagSize:'78px x 30px',
          type: 2
        },
        {
          label:"活动背景图",
          prop:"activityBg",
          upImagSize:'750px x 1334px',
          type:3
        },
        {
          label:"兑换按钮图",
          prop:"exchangeBtn",
          upImagSize:'78px x 30px',
          type: 4
        },
        {
          label:"兑换框背景图",
          prop:"exchangeBagBg",
          upImagSize:'750px x 800px',
          type: 5
        },
        {
          label:"奖品背景图",
          prop:"exchangePrizeBg",
          upImagSize:'312px x 252px',
          type: 6
        },
        {
          label:"拆福袋未开启",
          prop:"bagUnopen",
          upImagSize:'70px x 72px',
          type: 7
        },

        {
          label:"拆福袋开启",
          prop:"bagOpen",
          upImagSize:'87px x 97px',
          type: 8
        },
        {
          label:"福袋记录按钮",
          prop:"recordBtn",
          upImagSize:'78px x 30px',
          type: 9
        },
        {
          label:"福袋框背景图",
          prop:"bagBg",
          upImagSize:'750px x 584px',
          type: 10
        },
        {
          label:"任务框背景",
          prop:"taskBg",
          upImagSize:'684px x 100px',
          type: 11
        }

      ],
      creatForm: {
        bagLogo: '',
        ruleBtn: '',
        activityBg: '',
        exchangeBtn: '',
        exchangeBagBg:'',
        exchangePrizeBg: '',
        bagUnopen: '',
        bagOpen: '',
        recordBtn: '',
        bagBg: '',
        taskBg: ''
      },
      rules: {
        bagLogo: [{ required: true, message: '请上传福袋logo图', trigger: 'change' }],
        ruleBtn: [{ required: true, message: '请上传活动规则按钮图', trigger: 'change' }],
        activityBg: [{ required: true, message: '请上传活动背景图', trigger: 'change' }],
        exchangeBtn: [{ required: true, message: '请上传兑换按钮图', trigger: 'change' }],
        exchangeBagBg: [{ required: true, message: '请上传兑换框背景图', trigger: 'change' }],
        exchangePrizeBg: [{ required: true, message: '请上传兑换奖品背景图', trigger: 'change' }],
        bagUnopen: [{ required: true, message: '请上传福袋未开启图片', trigger: 'change' }],
        bagOpen: [{ required: true, message: '请上传福袋开启图片', trigger: 'change' }],
        recordBtn: [{ required: true, message: '请上传福袋记录按钮图', trigger: 'change' }],
        bagBg: [{ required: true, message: '请上传福袋框背景图', trigger: 'change' }],
        taskBg: [{ required: true, message: '请上传任务背景图', trigger: 'change' }],
      }
    };
  },
  props:['type'],
  computed:{
   ...mapState('bag',['activityId', 'activityBaseInfo', 'editBaseInfo' ,'httpDomain']),
   path () {
     return  `${baseUploadUrl}/fileManege/imageUpload`
   },
    setForm(){//初始化表格
      let setInfo = {};
      if(this.type==='edit'){
        setInfo = this.editBaseInfo;
      }else{
		  setInfo = this.activityBaseInfo
      }
      if(isEmptyObject(setInfo)){
        return this.creatForm;
      }
      return setInfo;
    },
    getId(){
    	let id=this.activityId;
    	if(this.type==='edit'){
    		id = this.$route.query.id;
    	}
      return id;
    }
  },
  created() {
    bus.$on('imgUrlCallback',params=>{
      console.log(params.labelKey)
      this.$set(this.setForm , params.labelKey ,params.url)
      // this.setForm[params.labelKey] = params.url;
      console.log(this.setForm)
      if(this.type === 'add') {
        this.setActivityBaseInfo(this.setForm)
        return;
      }
      this.setEditBaseInfo(this.setForm);
    })
  },
  beforeDestroy() {
    bus.$off('imgUrlCallback')
  },
  methods: {
    ...mapMutations('bag', ['setActivityBaseInfo', 'setEditBaseInfo']),
    getFullPath (prop) {
      return (this.setForm[prop] && (this.httpDomain+this.setForm[prop])) || ''
    },
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        console.log(this.setForm)
        if (valid) {
          this.$set(this.setForm, 'activityType', 'luckyBag')
          //存储vuex，上一步时，可以会显
          if(this.type==='edit'){
            this.setEditBaseInfo({...this.setForm})
          }else{
            this.setActivityBaseInfo(this.setForm)
          }
          bus.$emit('bagAction','add');
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
      // console.log(this.$refs[formName].resetFields())
    },
    prevForm(){
      bus.$emit('bagAction','minus');
    }
  }
};
</script>

<style scoped="scoped" lang="less">
.base-wrapper {
  .line{
    text-align: center;
  }
  .base-title{
    font-size: 20px;
    margin: 15px 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid #EEEEEE;
  }
  .creat-act-form{
    width: 60%;
  }
}
</style>
