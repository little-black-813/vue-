<template>
  <div class="card-style-border">
    <h2 class="font16">体检纪录</h2>
    <div class="handle-box">
      <div v-show="true">
        <label for="selectDay">开始日期：</label>
        <el-date-picker id="selectDay" class="marginR" size="small" v-model="exportData.beginTime" type="date" placeholder="选择开始日期" value-format="yyyy-MM-dd"></el-date-picker>
        <label for="selectEnd">结束日期：</label>
        <el-date-picker id="selectEnd" class="marginR" size="small" v-model="exportData.endTime" type="date" placeholder="选择结束日期" value-format="yyyy-MM-dd"></el-date-picker>
        <el-button size="small" class="marginR" type="primary" @click="queryData()">查询</el-button>
        <el-button size="small" class="marginR" type="primary" @click="excleLottery()">导出</el-button>
      </div>
    </div>
    <el-table :data="recordData.list" style="width: 100%">
      <el-table-column label="序号" type="index" width="90px"></el-table-column>
      <el-table-column align="center" v-for="(items, indexs) in recordLabel" :key="indexs" :prop="items.prop" :label="items.lable" :formatter="items.formatter"></el-table-column>
    </el-table>
    <div class="page-wrapper">
      <el-pagination class="current-page" layout="prev, pager, next, total,jumper" :total="recordData.total" @current-change="recordPageChange" :current-page.sync="queryRecore.pageSize" :page-size="queryRecore.limite" background>
      </el-pagination>
    </div>

  </div>
</template>

<script>
import qs from 'qs'
import { judgePath, formatDate } from '@/utils/utils'
import { getMainInfoReq } from 'api/commonApi'
import {exportExcel} from  '@/utils/utils.js'
export default {
  data() {
    return {
      loading: false,
      cascaderProps: {
        expandTrigger: 'click',
        multiple: true
      },
      prizeList: [],
      recordLabel: [
        { lable: '用户手机号', type: 'normal', prop: 'userPhone' },
        { lable: '兑换礼品名称', type: 'normal', prop: 'exchangeName' },
        { lable: '兑换金额', type: 'normal', prop: 'exchangeAmount' },
        { lable: '兑换时间', type: 'normal', prop: 'exchangeTime' }
      ],
      // formatter:function(row,column,cellvalue){
      // 		return prizeTypeList[cellvalue*1];
      // 	}
      recordData: {
        list: [],
        total: 0
      },
      exportData: { beginTime: '', endTime: '' },
      queryRecore: {
        pageSize: 1,
        limite: 10,
        // startTime:'',
        // endTime:''
      }
    }
  },
  created() {
    const { id } = this.$route.query
    this.getRecord(id)
  },
  methods: {
    queryData(){
      const { ids } = this.$route.query
      this.getRecord(ids)
    },
    excleLottery() {
      const { id } = this.$route.query
      getMainInfoReq({url: '/bagExchangeLog/exportExchangeLog', data:this.exportData}).then(res => {
        const content = res
        // 导出文件
        exportExcel(res,'兑换记录.xls')
      })
    },
    recordPageChange(val) {
      const { id } = this.$route.query
      this.$set(this.queryRecore, 'pageSize', val)
      this.getRecord(id)
    },
    getRecord(id) {
      getMainInfoReq({url: '/bagExchangeLog/listExchangeLog' ,data:{ activityId: id, ...this.queryRecore,...this.exportData }})
        .then(res => {
          this.recordData = {
            list: res.data.data,
            total: res.data.total
          }
        })
        .catch(err => {
          console.log(err)
        })
    },
    handleChange(value) {
      this.exportData.prizeMap = value
      const { id } = this.$route.query
      this.getRecord(id)
    }
  }
}
</script>

<style lang="less" scoped="scoped">
.card-style-border {
  border: 1px dashed #666;
  padding: 20px 30px;
  background-color: #ffffff;
  margin-bottom: 15px;
  .font16 {
    font-size: 16px;
    color: #333;
    font-weight: normal;
  }
  .fr {
    float: right;
  }
  .page-wrapper {
    margin: 20px auto;
    padding: 10px 0;
    text-align: center;
  }
  .handle-box {
    margin: 20px 0;
    label {
      font-size: 12px;
      color: #464545;
    }
  }
  .marginR {
    margin-right: 10px;
  }
}
::v-deep {
  .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 140px;
  }
  .el-select {
    width: 240px;
  }
  .el-cascader {
    width: 260px;
    // width: 88%;
  }
}
</style>
