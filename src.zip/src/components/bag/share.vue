<template>
  <div class="base-wrapper">
    <p class="base-title">分享设置</p>
    <el-form ref="shareForm" :model="shareForm" :rules="getRules" label-width="180px" class="creat-act-form">
      <!-- <el-form-item>
        <el-checkbox v-model="shareForm.shareGames" true-label="1" false-label="0" @change="changeShare" style="margin-left:-140px">
          可通过分享游戏增加抽奖次数
        </el-checkbox>
      </el-form-item> -->
     <!-- <el-form-item label="每日可增加次数：" prop="increTimes">
        <el-input-number v-model="shareForm.increTimes" controls-position="right" :min="0"></el-input-number>
      </el-form-item> -->
      <el-form-item label="分享标题：" prop="shareTitle">
        <el-input
          type="text"
          v-model.trim="shareForm.shareTitle"
        ></el-input>
      </el-form-item>
      <el-form-item label="分享摘要：" prop="shareSummary">
        <el-input
          type="textarea"
          v-model.trim="shareForm.shareSummary"
        ></el-input>
      </el-form-item>
      <!-- {{shareForm.shareImage}} -->
     <el-form-item label="分享图：" prop="shareImage">
       <el-input
         type="hidden"
         v-model="shareForm.shareImage"
       ></el-input>
        <v-uploadimg :id="getId" labelKey="shareImage" imgType="12" :upUrl="path" :imgUrl="getFullPath()" c="shareImgCb" upImagSize="200px x 200px"/>
      </el-form-item>
      <el-form-item>
        <el-button  @click="prevForm()">上一步</el-button>
        <el-button type="primary" @click="submitForm('shareForm')">立即创建</el-button>
        <!--<el-button type="danger" @click="resetForm('shareForm')">重置</el-button>-->
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import bus from 'components/common/bus';
import { mapState, mapMutations } from 'vuex';
import { postReq } from 'api/commonApi.js';
import { isEmptyObject } from '@/utils/utils'
import vUploadimg from 'components/common/uploadImg'
import { baseUploadUrl } from '@/config'
export default {
  components:{
    vUploadimg
  },
  data() {
    return {
      creatForm: {
        activityType: 'luckyBag',
        shareSummary: '',
        shareImage:'',
      },
      rules: {
        shareTitle: [{ required: true, message: '请输入分享标题', trigger: 'blur'  }],
        shareSummary: [{ required: true, message: '请输入分享摘要', trigger: 'blur'  }],
        shareImage: [{ required: true, message: '请上传分享图片', trigger: 'change'  }]
      }
    };
  },
  props:['type'],
  computed:{
    ...mapState('bag',['activityId', 'activityBaseInfo', 'editBaseInfo', 'httpDomain']),
    path () {
      return  `${baseUploadUrl}/fileManege/imageUpload`
    },
    shareForm(){
      let shareInfo = {};
      if(this.type==='edit'){
        shareInfo = this.editBaseInfo;
        // shareInfo.shareImageUrlFront = shareInfo.shareImageUrlFront || shareInfo.shareImage;
      }else{
        shareInfo = this.activityBaseInfo;
      }
      if(isEmptyObject(shareInfo)){
        return this.creatForm;
      }
      return shareInfo;
    },
    getRules(){
      let _that = this;
      if(_that.type==='edit'){
       _that.rules.shareImage = [{ required: false, message: '请上传分享图片', trigger: 'change'  }]
      }
      return _that.rules;
    },
    getId(){
     let id=this.activityId;
    	if(this.type==='edit'){
    		id = this.$route.query.id;
    	}
      return id;
    }
  },
  created() {
    bus.$on('shareImgCb',params=>{
            console.log(params, 'par')
      // this.shareForm.shareImage = params.id;
      // console.log(this.shareForm,'this.shareForm')
      this.shareForm.shareImage = params.url;
      // this.shareForm.shareImageUrlFront  = params.url;
    })
  },
  beforeDestroy() {
  	bus.$off('shareImgCb');
  },
  methods: {
    ...mapMutations('bag', ['setActivityBaseInfo', 'setEditBaseInfo']),
    getFullPath () {
      return (this.shareForm['shareImage'] && (this.httpDomain+this.shareForm['shareImage'])) || ''
    },
    submitForm(formName) {
          console.log(this.shareForm, 'pp')
      this.$refs[formName].validate(valid => {
        if (valid) {
          //存储vuex，上一步时，可以会显
          //判断编辑还是新增
          console.log(this.shareForm, 'shareForm')
          let reqUrl ='/bagActivity/updateShare';
          postReq({form:{...this.shareForm,activityId:this.getId},reqUrl}).then(res=>{
            this.$message({
                message: '恭喜你，设置分享信息成功。',
                type: 'success'
              });
              //存储vuex，上一步时，可以会显
              console.log(this.type, 'typehcsh')
              if(this.type==='edit'){
                this.setEditBaseInfo(this.shareForm)
                // alert('编辑')
              }else{
                // alert('创建cd')
                this.setActivityBaseInfo(this.shareForm)
              }
            bus.$emit('bagAction','add');
          })

        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    prevForm(){
      bus.$emit('bagAction','minus');
    },
    changeShare(val){
        this.rules = {
        // shareGames: [{ required: true, message: '请选择活动类型', trigger: 'change' }],
        // increTimes: [{ required: val, message: '请输入每日可增加次数', trigger: 'change' }],
        shareTitle: [{ required: val, message: '请输入分享标题', trigger: 'blur'  }],
        shareSummary: [{ required: val, message: '请输入分享摘要', trigger: 'blur'  }],
        shareImage: [{ required: val, message: '请上传分享图片', trigger: 'change'  }]
      }
    }
  }
};
</script>

<style scoped="scoped" lang="less">
.base-wrapper {
  .line{
    text-align: center;
  }
  .base-title{
    font-size: 20px;
    margin: 15px 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid #EEEEEE;
  }
  .creat-act-form{
    width: 60%;
  }
}
</style>
