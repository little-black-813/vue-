<template>
  <div class="base-wrapper">
    <p class="base-title">转盘</p>
    <div class="handle-box">
      <el-button plain type="primary" size="medium" @click="addPrize()">增加兑换奖品</el-button>
    </div>
    <el-table :data="tableData" ref="prizeTable" :select-on-indeterminate="false" class="prize-table" style="width: 80%">
      <el-table-column type="selection" align="center" width="55"></el-table-column>
      <el-table-column label="序列号" type="index" align="center" width="90px"></el-table-column>
      <el-table-column v-for="(items, indexs) in lableList" :key="indexs" :prop="items.prop" :label="items.lable" align="center" :formatter="formatter"></el-table-column>
      <el-table-column label="操作" align="center">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="editPrizeRow(scope.row, scope.$index)">编辑</el-button>
          <el-button type="text" size="small" @click="delPrizeRow(scope.row, scope.$index)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="footer">
      <el-button @click="prevForm()">上一步</el-button>
      <el-button type="danger" @click="createLink()">生成链接</el-button>
    </div>
    <v-linkdialog v-if="linkVisiable" :editType="editType" activityType="luckyBag"  action="finsh" :show="linkVisiable" :activityId="getId"></v-linkdialog>
    <v-exchangedialog v-if="addVisiable" c="prizeCb" :show="addVisiable" :formInit="selRow[0]" :type="editType" :selInd="selInd"></v-exchangedialog>
    <v-deldialog v-if="delVisiable" url="/bagActivityExchange/deleteExchangeById" :show="delVisiable" :name="selRow[0].exchangeName" :param="{exchangeId:selRow[0].exchangeId,activityType:'luckbag'}" :selInd="selInd" callback="closeExDel"></v-deldialog>
  </div>
</template>

<script>
import bus from 'components/common/bus';
import { mapState } from 'vuex';
import vExchangedialog from 'components/dialog/bag/AddExchange';
import vDeldialog from 'components/dialog/delCommonDialog';
import vLinkdialog from 'components/dialog/LinkDialog';
import { getMainInfoReq } from 'api/commonApi'
export default {
  components: {
    vExchangedialog,
    vLinkdialog,
    vDeldialog
  },
  data() {
    return {
      total: 0,
      creatUrl: '',
      editType:this.type,
      linkVisiable:false,
      addVisiable:false,
      delVisiable:false,
      selInd:'',//选择table的下标
      lableList: [
        {
          lable: '奖品名称',
          type: 'normal',
          prop: 'exchangeName'
        },
        {
          lable: '奖品金额',
          type: 'normal',
          prop: 'exchangeAmount'
        },
        {
          lable: '奖品份数',
          type: 'normal',
          prop: 'exchangeCount'
        }
      ],
      tableData: [],
      selRow: []
    };
  },
  props:['type'],
  computed: {
    ...mapState('bag', ['activityId']),
    getId(){
     if(this.type==='edit'){
     	return this.$route.query.id;
     }
     if(this.type==='add'){
       return this.activityId
     }
    }
  },
  created() {
    this.getList();
    bus.$on('exchangeCallback',params=>{
      this.addVisiable = params.show;
      this.selRow = [];
      this.selInd = '';
      if(params.reqFlag){
        this.getList();
      }
    });
    bus.$on('closeExDel',params=>{
      // debugger
      this.linkVisiable = params.show;
      this.delVisiable = params.show;
      this.selRow = [];
      this.selInd = '';
      params.reqFlag && this.getList();
    })
  },
  beforeDestroy() {
    bus.$off('exchangeCallback');
    bus.$off('closeExDel');
  },
  methods: {
    formatter (row, column, cellValue, index){
      // if(column.property === 'prizeType') { return this.prizeType[cellValue] }
      return cellValue
    },
    // 分页导航
    getList(p){
      getMainInfoReq({url:'/bagActivityExchange/listExchange',data:{activityId:this.getId}}).then(res=>{
        this.tableData = res.data.list
        this.total = res.data.total
      })
    },
    prevForm() {
      bus.$emit('bagAction', 'minus');
    },
    createLink() {
      this.linkVisiable = true;
    },
    addPrize() {
      if(this.tableData.length===8){
        this.$message({
          message: `奖项设置已经满足8个，请勿添加。`,
          type: 'error'
        });
        return;
      }
      this.addVisiable = true;
    },
    editPrizeRow(row,ind){
      this.addVisiable = true;
      this.selRow = [row];
      this.selInd = ind;
    },
    delPrizeRow(row,ind){
      this.selRow = [row];
      this.selInd = ind;
      this.delVisiable = true
    },
  }
};
</script>

<style scoped="scoped" lang="less">
.base-wrapper {
  .line {
    text-align: center;
  }
  .base-title {
    font-size: 20px;
    margin: 15px 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eeeeee;
  }
  .prize-table {
    margin: 20px auto;
  }
  .footer {
    text-align: center;
  }
  .handle-box {
    width: 80%;
    text-align: right;
    margin: 0 auto;
  }
  .upload-file {
    display: inline-block;
    margin-right: 20px;
  }
  .table-td-thumb {
    display: block;
    margin: auto;
    width: 40px;
    height: 40px;
  }
}
::v-deep {
  .el-table__header th .el-checkbox {
    display: none;
  }
}
</style>
