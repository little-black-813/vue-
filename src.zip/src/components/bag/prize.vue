<template>
  <div class="base-wrapper">
    <p class="base-title">福袋奖品设置</p>
    <div class="handle-box">
      <el-button plain type="primary" size="medium"  @click="addPrize()">增加福袋奖品</el-button>
    </div>

    <el-table :data="tableData" ref="prizeTable" :select-on-indeterminate="false" class="prize-table" style="width: 80%">
      <el-table-column type="selection" align="center" width="55"></el-table-column>
      <el-table-column label="序列号" type="index" align="center" width="90px"></el-table-column>
      <el-table-column v-for="(items, indexs) in prizeList.lableList" :key="indexs" :prop="items.prop" :label="items.lable" align="center" :formatter="formatter"></el-table-column>
      <el-table-column label="操作" align="center">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="editPrizeRow(scope.row, scope.$index)">编辑</el-button>
          <el-button type="text" size="small" @click="delPrizeRow(scope.row, scope.$index)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination">
      <el-pagination
        background
        :hide-on-single-page="true"
        layout="total, prev, pager, next"
        :current-page="query.pageSize"
        :page-size="query.limit"
        :total="total"
        @current-change="handlePageChange"
      ></el-pagination>
    </div>

    <div class="footer">
      <el-button @click="prevForm()">上一步</el-button>
      <el-button type="danger" @click="nextForm()">下一步</el-button>
    </div>
    <v-prizedialog v-if="addVisiable" callback="bagCb" :show="addVisiable" :formInit="selRow[0]" :type="editType" :selInd="selInd" ></v-prizedialog>
    <v-deldialog v-if="delVisiable" url="/bagActivityPrize/deletePrize" :show="delVisiable" :name="selRow[0].prizeName" callback="delPrize" :param="{prizeId:selRow[0].prizeId,activityType:'luckbag'}" :selInd="selInd"></v-deldialog>

  </div>
</template>

<script>
import bus from 'components/common/bus';
import { mapState, mapMutations } from 'vuex';
import vPrizedialog from 'components/dialog/bag/AddPrizeDialog';
import vDeldialog from 'components/dialog/delCommonDialog';
import { getMainInfoReq } from 'api/commonApi'
export default {
  components: {
    vPrizedialog,
    vDeldialog,
  },
  data() {
    return {
      query:{
        pageSize: 1,
        limit: 10
      },
      tableData: [],
      total:0,
      creatUrl: '',
      editType:this.type,
      addVisiable:false,
      delVisiable:false,
      selInd:'',//选择table的下标
      prizeList: {
        lableList: [
          {
            lable: '奖品名称',
            type: 'normal',
            prop: 'prizeName'
          },
          {
              lable: '奖品类型',
              type: 'normal',
              prop: 'prizeType'

          },
           {
            lable: "奖品金额",
            type: "normal",
            prop: "prizeAmount"
          },
          {
            lable: '数量',
            type: 'normal',
            prop: 'prizeCount'
          },
          {
            lable: '中奖率（%）',
            type: 'normal',
            prop: 'prizePercent'
          }
        ],
      },
      selRow: [],
      prizeType: {
        1: '福袋券',
        2: '谢谢参与'
      }
    };
  },
  props:['type'],
  computed: {
    ...mapState('bag', ['activityId']),
    getId(){
     if(this.type==='edit'){
     	return this.$route.query.id;
     }
     if(this.type==='activityId'){
       return this.activityId;//this.$store.state.activityId
     }
    }
  },
  created() {
    this.getPrizeList();
    bus.$on('bagCb',params=>{
      console.log('params.show,',params)
      this.addVisiable = params.show;
      this.selRow = [];
      this.selInd = '';
      if(params.reqFlag){
        this.getPrizeList('req');
      }
    });
    bus.$on('delPrize',params=>{
      this.delVisiable = params.show;
      this.selRow = [];
      this.selInd = '';
      if(params.reqFlag){
        this.getPrizeList();
      }
    });
  },
  beforeDestroy() {
    bus.$off('bagCb');
    bus.$off('delPrize');
  },
  methods: {
    ...mapMutations('bag', ['setActivityBaseInfo', 'setEditBaseInfo']),
    formatter (row, column, cellValue, index){
      if(column.property === 'prizeType') { return this.prizeType[cellValue] }
      return cellValue
    },
    // 分页导航
    handlePageChange(val) {
      this.$set(this.query, 'pageSize', val);
      this.getPrizeList();
    },
    getPrizeList(){
      getMainInfoReq({url:'/bagActivityPrize/listPrize',data:{activityType:'luckyBag',activityId:this.getId,...this.query}}).then(res=>{
        this.tableData = res.data.list;
        this.total = res.data.total;
      }).catch(err=>{
        this.tableData = [];
        this.total = 0;
      })
    },
    nextForm(){
      bus.$emit('bagAction', 'add');
    },
    prevForm() {
      bus.$emit('bagAction', 'minus');
    },
    addPrize() {
      this.addVisiable = true;
    },
    editPrizeRow(row,ind){
      this.addVisiable = true;
      this.selRow = [row];
      this.selInd = ind;
      // console.log( this.selRow, '0')
      // this.$router.replace('/add_prize')
    },
    delPrizeRow(row,ind){
      this.selRow = [row];
      this.selInd = ind;
      this.delVisiable = true
    },
  },
};
</script>

<style scoped="scoped" lang="less">
.base-wrapper {
  .line {
    text-align: center;
  }
  .base-title {
    font-size: 20px;
    margin: 15px 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eeeeee;
  }
  .prize-table {
    margin: 20px auto;
  }
  .footer {
    text-align: center;
  }
  .handle-box {
    width: 80%;
    text-align: right;
    margin: 0 auto;
  }
  .upload-file {
    display: inline-block;
    margin-right: 20px;
  }
  .table-td-thumb {
    display: block;
    margin: auto;
    width: 40px;
    height: 40px;
  }
}
.pagination{
  margin: 20px 0;
  text-align: center;
}
::v-deep {
  .el-table__header th .el-checkbox {
    display: none;
  }
}
</style>
