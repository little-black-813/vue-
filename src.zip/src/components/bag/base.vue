<template>
  <div class="base-wrapper">
    <p class="base-title">基础信息</p>
    <el-form
      ref="creatForm"
      :model="creatForm"
      :rules="rules"
      class="creat-act-form"
      label-width="190px"
    >
      <!-- <el-form-item label="活动类型：" prop="activityType">
        <el-select v-model="creatForm.activityType" placeholder="请选择活动类型"><el-option label="抽奖活动" value="1"></el-option></el-select>
      </el-form-item> -->
      <el-form-item label="活动名称：" prop="activityName"
        ><el-input v-model.trim="creatForm.activityName"></el-input
      ></el-form-item>
      <el-form-item label="活动时间：" required>
        <el-col :span="11">
          <el-form-item prop="activityStartTime">
            <el-date-picker
              type="datetime"
              placeholder="选择开始日期"
              @change="changeTime1"
              v-model="creatForm.activityStartTime"
              style="width: 100%;"
            ></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col class="line" :span="2">-</el-col>
        <el-col :span="11">
          <el-form-item prop="activityEndTime">
            <el-date-picker
              type="datetime"
              placeholder="选择截至日期"
              @change="changeTime2"
              v-model="creatForm.activityEndTime"
              style="width: 100%;"
            ></el-date-picker>
          </el-form-item>
        </el-col>
      </el-form-item>
      <el-form-item label="活动规则：" prop="activityRule"
        ><el-input
          type="textarea"
          v-model.trim="creatForm.activityRule"
          :autosize="{ minRows: 6, maxRows: 12}"
        ></el-input
      ></el-form-item>

      <el-form-item>
        <el-button type="primary" @click="submitForm('creatForm')"
          >立即创建</el-button
        >
        <!--<el-button @click="resetForm('creatForm')">{{creatForm.activityType}}重置</el-button>-->
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import bus from "components/common/bus";
import { mapState, mapMutations } from "vuex";
import { postReq } from "api/commonApi.js";
import { isEmptyObject, formatDate, isEmptyValue } from "@/utils/utils";
export default {
  data() {
    return {
      isShowCenter: false,
      createdForm: {
        activityName: "",
        activityInfo: "",
        activityStartTime: "",
        activityEndTime: "",
        activityType:"physicalActivity"
      },

      rules: {
        activityStartTime: [
          {
            type: "string",
            required: true,
            message: "请选择活动开始时间",
            trigger: "change"
          }
        ],
        activityEndTime: [
          {
            type: "string",
            required: true,
            message: "请选择活动结束时间",
            trigger: "change"
          }
        ],
        activityName: [
          { required: true, message: "请输入活动名称", trigger: "blur" }
        ],
        activityRule: [
          { required: true, message: "请输入活动规则", trigger: "blur" }
        ]
      }
    };
  },
  props: ["type"],
  computed:{
    ...mapState('bag',['activityId', 'activityBaseInfo', 'editBaseInfo']),
    creatForm () {
      if (this.type === "edit") {
        //编辑
        // debugger
        return this.editBaseInfo;
      }
      if(isEmptyObject(this.activityBaseInfo)){
        return this.createdForm;
      }
      return this.activityBaseInfo;
    }
  },
  created() {
    // this.creatForm = this.initForm();
    console.log(this.activityId)
  },
  methods: {
    ...mapMutations('bag', [ 'setActivityId','setActivityBaseInfo', 'setEditBaseInfo']),
    changeTime1(val) {
      this.$set(
        this.creatForm,
        "activityStartTime",
        formatDate(val, "yyyy-MM-dd HH:mm:ss")
      );
    },
    changeTime2(val) {
      this.$set(
        this.creatForm,
        "activityEndTime",
        formatDate(val, "yyyy-MM-dd HH:mm:ss")
      );
    },
    initForm() {
      // let activityInfo = this.activityBaseInfo;
      if (this.type === "edit") {
        //编辑
        // debugger
        return this.editBaseInfo;
      }
      return this.creatForm;
      // if (isEmptyObject(activityInfo)) {
      //   return this.creatForm;
      // } else {
      //   let p_info = activityInfo;
      //   return { ...p_info };
      // }
    },
    submitForm(formName) {
      let _that = this;
      _that.$refs[formName].validate(valid => {
        _that.$set(_that.creatForm,'activityType', 'luckyBag')
        if (valid) {
          //存储vuex，上一步时，可以会显
          let reqUrl = "/bagActivity/addActivity",activityId =  _that.activityId;
          if (!isEmptyValue(activityId) && this.type === "add") {
            reqUrl = "/bagActivity/updateActivity";
          }
          if (this.type === "edit") {
            reqUrl = "/bagActivity/updateActivity";
            activityId = this.$route.query.id;
          }
         this.createActivity({reqUrl,form:{...this.creatForm,activityId:activityId}});
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    //创建活动基础信息
    createActivity(params) {
      postReq(params).then(res => {
          this.$message({
            message: `恭喜您，基础信息编辑成功！`,
            type: "success"
          });
          if (this.type === "edit") {
            this.setEditBaseInfo({ ...params.form })
          } else {
            this.setActivityBaseInfo({ ...params.form })

            if (isEmptyValue(params.form.activityId)) {
              this.setActivityId(res.data.bagActivityId)
            }
          }
          bus.$emit("bagAction", "add");
      });
    }
  }
};
</script>

<style scoped="scoped" lang="less">
.base-wrapper {
  .line {
    text-align: center;
  }
  .base-title {
    font-size: 20px;
    margin: 15px 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eeeeee;
  }
  .creat-act-form {
    width: 70%;
  }
}
</style>
