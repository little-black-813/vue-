<template>
  <div class="base-wrapper">
    <p class="base-title">奖品设置</p>
    <div class="handle-box">
      <el-upload
        class="upload-file"
        name="upPopfile" 
        :action="path"
        :show-file-list="false"
        :on-error="handleFileError"
        :on-success="handleFileSuccess"
        :before-upload="beforeFileUpload"
        :data="extendData"
      >
      <!-- @click="uploadFileJudge()" -->
        <el-button size="medium" v-if="t=='p'" plain type="warning" >上传弹窗目标</el-button>
      </el-upload>
      <el-upload
        class="upload-file"
        name="upfile"
        :action="path"
        :show-file-list="false"
        :on-error="handleFileError"
        :on-success="handleFileSuccess"
        :before-upload="beforeFileUpload"
        :data="extendData"
      >
      <!-- @click="uploadFileJudge()" -->
        <el-button size="medium" v-if="t=='p'" plain type="warning" >上传中奖目标</el-button>
      </el-upload>
      <el-button plain type="primary" size="medium"  @click="addPrize(tableData)">增加奖品</el-button>
    </div>

    <el-table :data="tableData" ref="prizeTable" :select-on-indeterminate="false" class="prize-table" @selection-change="handleSelectionChange" style="width: 80%">
      <el-table-column type="selection" align="center" width="55"></el-table-column>
      <el-table-column label="序列号" type="index" align="center" width="90px"></el-table-column>
      <el-table-column v-for="(items, indexs) in prizeList.lableList" :key="indexs" :prop="items.prop" :label="items.lable" align="center" >
        <template  slot-scope="scope">
          <template v-if="items.prop==='prizeType'">
            {{ scope.row[items.prop]  ==='change' ? '兑换类' : '转盘类' }}
          </template>
          <template v-else-if="items.prop==='prizeOdds'">
            {{ scope.row[items.prop]  === 0 ? '暂无' : scope.row[items.prop] }}
          </template>
          <!-- <template v-else-if="items.prop==='prizeImg'" slot-scope="scope">
            <el-image class="table-td-thumb" :src="scope.row.prizeImg" :preview-src-list="[scope.row.imgId]"></el-image>
          </template> -->
          <template v-else >
            {{ scope.row[items.prop] || '暂无' }}
          </template>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="editPrizeRow(scope.row, scope.$index)">编辑</el-button>
          <el-button type="text" size="small" @click="delPrizeRow(scope.row, scope.$index)">删除</el-button>
          <el-button v-if="t=='p'"  type="text" size="small" @click="lookPrizeRow(scope.row, scope.$index)">查看中奖目标</el-button>
          <el-button v-if="t=='p'"  type="text" size="small" @click="upPrizeRow(scope.row, scope.$index)">查看上传弹窗目标</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination">
      <el-pagination
        background
        :hide-on-single-page="true"
        layout="total, prev, pager, next"
        :current-page="query.pageSize"
        :page-size="query.limite"
        :total="total"
        @current-change="handlePageChange"
      ></el-pagination>
    </div>

    <div class="footer">
      <el-button @click="prevForm()">上一步</el-button>
      <el-button type="danger" @click="createLink()">生成链接</el-button>
    </div>
    <v-linkdialog v-if="linkVisiable" :editType="editType"  action="finsh" :show="linkVisiable" :activityId="getId"></v-linkdialog>
    <!-- <v-prizedialog v-if="addVisiable" :childList="childList" :t="t" c="prizeCb" :show="addVisiable" :formInit="selRow[0]" :type="editType" :selInd="selInd" :beforeHide="beforeHide"></v-prizedialog> -->
    <v-signdialog v-if="addVisiable" :childList="childList" :t="t" c="prizeCb" :show="addVisiable" :formInit="selRow[0]" :type="editType" :selInd="selInd" :beforeHide="beforeHide"></v-signdialog>
    <v-deldialog v-if="delVisiable" url="/data/prize/deletePrize?activityType=signActivityPrize" :show="delVisiable" :name="selRow[0].prizeName" :id="selRow[0].id" :selInd="selInd"></v-deldialog>
  </div>
</template>

<script>
import bus from 'components/common/bus';
import { mapState } from 'vuex';
import vLinkdialog from 'components/dialog/LinkDialog';
// import vPrizedialog from 'components/dialog/AddPrizeDialog';
import vSigndialog from 'components/dialog/AddSignDialog';
import vDeldialog from 'components/dialog/delDialog';
import { getPrizeListReq } from 'api/prize'
import { isEmptyObject,judgePath,isEmptyValue } from '@/utils/utils';
export default {
  components: {
    vLinkdialog,
    // vPrizedialog,
    vDeldialog,
    vSigndialog
  },
  data() {
    return {
      childList : [],
      query:{
        pageSize: 1,
        limite: 10
      },
      // isUrl:'', // 动态写入删除路径
      total:0,
      creatUrl: '',
      editType:this.type,
      linkVisiable:false,
      addVisiable:false,
      delVisiable:false,
      selInd:'',//选择table的下标
      extendData:{
        activityId:this.$store.state.activityId,
        prizeId:''
      },
      prizeList: {
        lableList: [
          {lable: '奖品名称', type: 'normal',prop: 'prizeName'},
          {lable: '数量',type: 'normal',prop: 'prizeNumber'},
          {lable: '奖品类型',type: 'normal',prop: 'prizeType'},
          {lable: '中奖率（%）',type: 'normal',prop: 'prizeOdds'},
          // {lable: '奖品图片',type: 'normal',prop: 'prizeImg'},
        ],
        data: []
      },
      selRow: [],
      t: ''
    };
  },
  props:['type'],
  computed: {
    ...mapState({
      baseInfo: 'activityBaseInfo'
    }),
    path(){//本地调休修改路径
      return `${judgePath()}/manager/api/data/targetUsers/fileUpload`  // 生产
      // return `http://localhost:7106/data/targetUsers/fileUpload`
    },
    tableData:{
    	get:function(){
    		return this.baseInfo.prizeList;
    	},
    	set:function(newVal){
    		this.$store.dispatch('setActivityBaseInfo',{prizeList:newVal})
    	}
    },
    getId(){
     if(this.type==='edit'){
     	return this.$route.query.id;
     }
     if(this.type==='add'){
       return this.$store.state.activityId
     }
    }
  },
  created() {
    this.getPrizeList('init',this.$route.query);
    bus.$on('prizeCb',params=>{
      // console.log('prizeCb--',params)
      this.addVisiable = params.show;
      this.selRow = [];
      this.selInd = '';
      if(params.reqFlag){
        this.getPrizeList('req');
      }
    });
    bus.$on('closeDel',params=>{
      this.delVisiable = params.show;
      this.linkVisiable = params.show || params;
      this.selRow = [];
      this.selInd = '';
      if(params.reqFlag){
        this.getPrizeList();
      }
    });
    // console.log(this.$route.query,'this.$route.query')
    this.t = this.$route.query.t //签到编辑奖品进入

    // this.isUrl = this.$route.query.t == 's'? '/data/prize/deletePrize?activityType=signActivityPrize' : '/data/prize/deletePrize?activityType=plateActivityPrize'
   
   // console.log
  },
  beforeDestroy() {
    bus.$off('prizeCb');
    bus.$off('closeDel');
  },
  methods: {
    // 分页导航
    handlePageChange(val) {
      this.$set(this.query, 'pageSize', val);
      this.getPrizeList('init',this.$route.query);
    },
    getPrizeList(p,t){
      // console.log(t, 'tttt')
      if(t===undefined ) {
        return false
      }
      // if (t.t&&t.t == 's') {
        this.$set(this.query, 'activityType', 'signActivityPrize');
      // } else if (t.t == 'p') {
      //   this.$set(this.query, 'activityType', 'plateActivityPrize');
      // }
      // console.log(this.query, 'this.query')

      getPrizeListReq({activityId:this.getId,...this.query}).then(res=>{
        if(res.flag){
        	this.tableData = res.data.data;
          this.total = res.data.total;
        }
      }).catch(err=>{
        this.tableData = [];
        this.total = 0;
      })
    },
    createLink() {
      this.linkVisiable = true;
      // bus.$emit('openLink', true);
    },
    prevForm() {
      bus.$emit('activityOp', 'minus');
    },
    addPrize(val) {
      this.addVisiable = true;
      this.paramsQuery = this.t
      this.childList = val
    },
    editPrizeRow(row,ind){
      this.addVisiable = true;
      this.selRow = [row];
      this.selInd = ind;
      // console.log( this.selRow, '0')
      // this.$router.replace('/add_prize')
    },
    lookPrizeRow(row,ind){
      this.$router.push({path:"record",query:{pd:row.id,ad:this.getId}});
    },
    upPrizeRow(row,ind) {
      // console.log(row, ind, '查看上传弹窗目标')
      this.$router.push({path:"uprecord",query:{pd:row.id,ad:this.getId}});
    },
    delPrizeRow(row,ind){
      // console.log(row, ind, 'row')
      // if (this.t == 's') {
      //   this.$set(row, 'activityType', 'signActivityPrize')
      // }else if (this.t == 'p') {
      //   this.$set(row, 'activityType', 'plateActivityPrize')
      // }
      this.selRow = [row];
      // console.log(this.t,this.selRow[0], 'this.isUrl')
      this.selInd = ind;
      this.delVisiable = true
    },
    handleFileError(err, file, fileList){
      // console.log(err)
      this.$message({
        message: `${err.message}`,
        type: 'error'
      });
    },
    uploadFileJudge(){
      // if(!this.selRow.length){
      //   this.$message({
      //     message: '请先选择对应奖品',
      //     type: 'warning'
      //   });
      //   return false;
      // }
    },
    beforeFileUpload(file) {
      // console.log(file.name)
      let name = file.name;
      let suffix = name.substr(name.lastIndexOf("."));
      // console.log(this.selRow)
      if(!this.selRow.length){
        this.$message({
          message: '请先选择对应奖品',
          type: 'warning'
        });
      }
      if(".xls" != suffix && ".xlsx" != suffix ){
        //校验不通过
        this.$message({
          message: '请选择excle表格上传',
          type: 'warning'
        });
        return false;
      }  
      if(!this.selRow.length){
        this.$message({
          message: '请先选择对应奖品',
          type: 'warning'
        });
        return false;
      }
    },
    handleFileSuccess(res,file) {
      if(res.code==='9999'){
        this.$message({
          message: `${res.mess}`,
          type: 'error'
        });
      }else{
        this.$message({
          message: `${res.mess}`,
          type: 'success'
        });
      }

    },
    handleSelectionChange(val) {
      // console.log(val)
      let arr = val;
      if (arr.length > 1) {
        this.$refs.prizeTable.toggleRowSelection(val[0]);
        this.selRow = [val[0]]
        this.extendData.activityId = this.getId;
        this.extendData.prizeId = val[0].id;
      } else {
        this.selRow = [val[0]]
        this.extendData.activityId = this.getId;
        this.extendData.prizeId = val[0].id;
      }
    },
    // 弹窗关闭回调
    beforeHide(val){
      // console.log(val, '关闭弹窗回调')
    }
  },
  watch: {
    // 监听是否是签到 页面传值  s 标识签到页面
    // t (e) {
    //   if (e=='s'){
    //     var newlableList = [
    //       {lable: '奖品名称', type: 'normal',prop: 'prizeName'},
    //       {lable: '数量',type: 'normal',prop: 'prizeNumber'},
    //       {lable: '奖品类型',type: 'normal',prop: 'prizeType'},
    //       {lable: '中奖率（%）',type: 'normal',prop: 'prizeOdds'},
    //     ]

    //     this.prizeList.lableList = newlableList
    //   }
    // },
    addVisiable (val) {
      // alert(val, 'sdadscasd')
      if (val == false) {
        // console.log(this.$route.query, 'ppppthis.$route.query')
        this.getPrizeList('init',this.$route.query);
      }
    }
  },
};
</script>

<style scoped="scoped" lang="less">
.base-wrapper {
  .line {
    text-align: center;
  }
  .base-title {
    font-size: 20px;
    margin: 15px 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eeeeee;
  }
  .prize-table {
    margin: 20px auto;
  }
  .footer {
    text-align: center;
  }
  .handle-box {
    width: 80%;
    text-align: right;
    margin: 0 auto;
  }
  .upload-file {
    display: inline-block;
    margin-right: 20px;
  }
  .table-td-thumb {
    display: block;
    margin: auto;
    width: 40px;
    height: 40px;
  }
}
.pagination{
  margin: 20px 0;
  text-align: center;
}
::v-deep {
  .el-table__header th .el-checkbox {
    display: none;
  }
}
</style>
