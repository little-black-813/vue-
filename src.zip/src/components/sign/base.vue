<template>
  <div class="base-wrapper">
    <p class="base-title">基础信息</p>
    <el-form ref="creatForm" :model="creatForm" :rules="rules" label-width="140px" class="creat-act-form">
    <!--  <el-form-item label="活动类型：" prop="activityType">
        <el-select v-model="creatForm.activityType" placeholder="请选择活动类型"><el-option label="抽奖活动" value="2"></el-option></el-select>
      </el-form-item> -->
      <el-form-item label="活动名称：" prop="activityName"><el-input v-model.trim="creatForm.activityName"></el-input></el-form-item>
      <el-form-item label="活动时间" required>
        <el-col :span="11">
          <el-form-item prop="activityStartTime">
            <el-date-picker type="datetime" placeholder="选择开始日期" @change="changeTime1" v-model="creatForm.activityStartTime" style="width: 100%;"></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col class="line" :span="2">-</el-col>
        <el-col :span="11">
          <el-form-item prop="activityEndTime">
            <el-date-picker type="datetime" placeholder="选择截至日期" @change="changeTime2" v-model="creatForm.activityEndTime" style="width: 100%;"></el-date-picker>
          </el-form-item>
        </el-col>
      </el-form-item>
      <el-form-item label="抽奖所需金币:" prop="modifier">
          <el-input-number v-model.trim="creatForm.modifier" placeholder="抽奖所需金币" controls-position="right" :min="0" ></el-input-number>
      </el-form-item>
      
      <el-form-item label="活动规则：" prop="activityRule">
        <el-input type="textarea" v-model.trim="creatForm.activityRule" :autosize="{ minRows: 4, maxRows: 8}"></el-input>
        </el-form-item>
      <!-- <el-form-item label="是否展示个人中心:">
          <el-switch v-model="isShowCenter"  @change="selCenter"></el-switch>
        </el-form-item>
        <el-form-item v-if="isShowCenter" label="个人中心地址：" prop="homePageUrl"><el-input v-model.trim="creatForm.homePageUrl"></el-input></el-form-item> -->
      <el-form-item label="备注：" prop="activityNote"><el-input type="textarea" v-model.trim="creatForm.activityNote"></el-input></el-form-item>
      <el-form-item>
        <el-button type="primary" @click="submitForm('creatForm')">立即创建</el-button>
        <!--<el-button @click="resetForm('creatForm')">{{creatForm.activityType}}重置</el-button>-->
      </el-form-item>

    </el-form>
  </div>
</template>

<script>
import bus from 'components/common/bus';
import { mapState } from 'vuex';
import { createOrEditBaseActivityReq } from 'api/activity.js';
import { isEmptyObject,formatDate,isEmptyValue } from '@/utils/utils';
export default {
  data() {
    return {
      isShowCenter:false,
      creatForm: {
        activityType: '',
        activityName: '',
        activityNote: '',
        activityStartTime: '',
        activityEndTime: '',
        homePageUrl:'',
        modifier: ''
      },
      rules: {
        // activityType: [{ required: false, message: '请选择活动类型', trigger: 'change' }],
        activityName: [{ required: true, message: '请输入活动名称', trigger: 'blur' }],
        activityStartTime: [{ type: 'string', required: true, message: '请选择活动开始时间', trigger: 'change' }],
        activityEndTime: [{ type: 'string', required: true, message: '请选择活动结束时间', trigger: 'change' }],
        activityRule: [{ required: true, message: '请输入活动规则', trigger: 'blur' }],
        homePageUrl: [{ required: false, message: '请输入活动规则', trigger: 'blur' }],
        modifier: [{ required: true, message: '抽奖所需金币', trigger: 'blur' }],
      }
    };
  },
  props:['type'],
  created() {
   this.creatForm = this.initForm();
   this.getShowCenter();
  },
  methods: {
    getShowCenter(){
      let homePageUrl = '';
      if(this.type==='edit'){
        homePageUrl = this.$store.state.editBaseInfo.activityInfo.homePageUrl;
      }else{
        homePageUrl = this.$store.state.activityBaseInfo.activityInfo.homePageUrl;
      }
      this.isShowCenter = !isEmptyValue(homePageUrl);
      this.rules.homePageUrl = [{ required: !isEmptyValue(homePageUrl), message: '请输入活动规则', trigger: 'blur' }];
    },
    changeTime1(val){
        this.$set(this.creatForm,'activityStartTime',formatDate(val,'yyyy-MM-dd HH:mm:ss'));
    },
    changeTime2(val){
        this.$set(this.creatForm,'activityEndTime',formatDate(val,'yyyy-MM-dd HH:mm:ss'));
    },
    selCenter(callback){
      if(callback){
        this.rules.homePageUrl = [{ required: true, message: '请输入活动规则', trigger: 'blur' }];
      }else{
        this.rules.homePageUrl = [{ required: false, message: '请输入活动规则', trigger: 'blur' }];
        this.$set(this.creatForm,'homePageUrl','');
      }
    },
    initForm(){
      // console.log(this.type)
      let activityInfo = this.$store.state.activityBaseInfo.activityInfo;
      if(this.type==='edit'){//编辑
        activityInfo = this.$store.state.editBaseInfo.activityInfo;
      };
      if (isEmptyObject(activityInfo)) {
        return this.creatForm;
      } else {
        let p_info = activityInfo;
        return { ...p_info };
      }
    },
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        // 将 请选择活动类型 默认值传递 2  修改为 signActivity 为了区别 转盘和签到活动
        this.$set(this.creatForm,'activityType', 'signActivity')
        // console.log( this.creatForm, '改变值')
        if (valid) {
          // bus.$emit('activityOp', 'add');
          // return;
          //存储vuex，上一步时，可以会显
          // this.$store.dispatch('setActivityBaseInfo', { activityInfo: this.creatForm })
          let s_id = this.$store.state.activityId;

          let reqUrl ='/data/activity/addActivity';
          if(!isEmptyValue(s_id)&&this.type==='add'){
            reqUrl = '/data/activity/updateActivityInfo';
          }
          // console.log(this.type)
          if(this.type==='edit'){
            reqUrl = '/data/activity/updateActivityInfo';
            s_id = this.$route.query.id;
          }
          this.createActivity({reqUrl,creatForm:{...this.creatForm,activityId:s_id}});
        } else {
          console.log('error submit!!');
          return false;
        } 
      }); 
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    //创建活动基础信息
    createActivity(params) {
      createOrEditBaseActivityReq(params).then(res => {
        if (res.flag) {
          this.$message({
            message: '恭喜你，创建基础信息成功',
            type: 'success'
          });
          // console.log(this.type, 'this.type')
          // console.log(params, 'params')
          // return false
          if(this.type==='edit'){
            this.$store.dispatch('setEditbaseInfo', { activityInfo: {...params.creatForm} });
          }else{
            this.$store.dispatch('setActivityBaseInfo', { activityInfo: {...params.creatForm} });
            if(isEmptyValue(params.creatForm.activityId)){
              this.$store.dispatch('setActivityId', res.data);
            }
          }
          bus.$emit('activityOp', 'add');
        }
      });
    }
  }
};
</script>

<style scoped="scoped" lang="less">
.base-wrapper {
  .line {
    text-align: center;
  }
  .base-title {
    font-size: 20px;
    margin: 15px 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eeeeee;
  }
  .creat-act-form {
    width: 60%;
  }
}
</style>
