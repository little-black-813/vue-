<template>
  <div class="add-activity-wrapper">
    <el-breadcrumb separator="/">
      <el-breadcrumb-item :to="{ path: '/daiyan/index' }">带盐活动管理</el-breadcrumb-item>
      <el-breadcrumb-item>编辑活动</el-breadcrumb-item>
    </el-breadcrumb>
    <section class="step-warpper">
      <el-steps :active="active" align-center>
        <el-step><i class="icon-txt" slot="icon">编辑活动</i></el-step>
        <el-step><i class="icon-txt" slot="icon">奖品设置</i></el-step>
      </el-steps>
      <div class="step-con">
        <v-baseform v-if="active === 1" type="edit"></v-baseform>
        <v-prize v-if="active === 2" type="edit"></v-prize>
      </div>
    </section>
  </div>
</template>

<script>
import bus from 'components/common/bus';
import vBaseform from 'components/daiyan/base';
import vPrize from 'components/daiyan/prize';
import {searchDYDetail} from 'api/daiyan/dyActivity.js'
export default {
  components: {
    vBaseform,
    vPrize
  },
  data() {
    return {
      active: 0
    };
  },
  created() {
    this.getDetail();
    bus.$on('daiYanOp', flag => {
      console.log('daiYanOp', flag);
      if (flag === 'add') {
        //下一步，上一步
        this.next();
      } else {
        this.prev();
      }
    });
  },
  beforeDestroy() {
    bus.$off('daiYanOp');
  },
  methods: {
    getDetail(){
      const {id} = this.$route.query;
      let that = this;
       searchDYDetail({activityId:id}).then (res=>{
         this.active = 1;
        that.$store.dispatch('daiyan/setEditbaseInfo', { activityInfo: {...res.data} });
      })
    },
    next() {
      if (this.active++ > 2) this.active = 0;
    },
    prev() {
      if (this.active-- <= 0) this.active = 0;
    }
  }
};
</script>

<style scoped="scoped" lang="less">
.el-breadcrumb {
  font-size: 16px;
  margin: 10px 0;
}
.step-warpper {
  background-color: #ffffff;
  padding: 20px 0;
  .step-con {
    margin-top: 30px;
  }
}
.icon-txt {
  font-style: normal;
}
::v-deep {
  .el-step__icon {
    width: 70px;
    height: 70px;
    cursor: pointer;
  }
  .el-step.is-center .el-step__line {
    top: 50%;
    transform: translateY(-50%);
  }
}
</style>
