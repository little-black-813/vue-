<template>
  <div class="activity-wrapper">
    <div class="crumbs"><span>数据管理</span></div>
    <div class="container">
      <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="访客数" name="first">
            <template v-if="activeName==='first'">
              <div class="handle-box">
                <el-date-picker
                  class="marginR"
                  size="small"
                  v-model="query.startTime"
                  type="date"
                  value-format="yyyy-MM-dd"
                  placeholder="选择开始日期"
                ></el-date-picker>
                <el-date-picker
                  class="marginR"
                  size="small"
                  v-model="query.endTime"
                  type="date"
                  value-format="yyyy-MM-dd"
                  placeholder="选择截至日期"
                ></el-date-picker>
                <el-button class="marginR" size="small" type="primary" @click="search">查询</el-button>
                <!-- <el-button class="create-btn"  type="primary" size="small" @click="downloadSelection" >导出</el-button> -->
              </div>
              <el-table  :data="tableData" class-name="table" ref="multipleTable" header-cell-class-name="table-header">
                <!-- <el-table-column prop="activityId" label="ID" width="55" align="center"></el-table-column> -->
                <!-- <el-table-column prop="creatTime" align="center" label="创建日期"></el-table-column> -->
                <el-table-column prop="visitors" align="center" label="访客数"></el-table-column>
                <el-table-column prop="oldUser" align="center" label="老用户"></el-table-column>
                <el-table-column prop="newUser" align="center" label="新用户"></el-table-column>

                <el-table-column prop="period" align="center" label="日期"></el-table-column>
                <!-- <el-table-column label="操作" width="200" align="center">
                  <template slot-scope="scope">
                    <el-button type="text" icon="el-icon-view" @click="lookDetail(scope.row)">查看中奖记录</el-button>
                  </template>
                </el-table-column> -->
              </el-table>
              <div class="pagination">
                <el-pagination
                  background
                  :hide-on-single-page="true"
                  layout="total, prev, pager, next"
                  :current-page="query.pageSize"
                  :page-size="query.limite"
                  :total="total"
                  @current-change="handlePageChange"
                ></el-pagination>
              </div>
            </template>
          </el-tab-pane>
          <el-tab-pane label="问卷详情" name="third">
            <template  v-if="activeName==='third'">
              <div class="handle-box">
                <!-- <el-date-picker
                  class="marginR"
                  size="small"
                  v-model="query.startTime"
                  type="date"
                  value-format="yyyy-MM-dd"
                  placeholder="选择开始日期"
                ></el-date-picker>
                <el-date-picker
                  class="marginR"
                  size="small"
                  v-model="query.endTime"
                  type="date"
                  value-format="yyyy-MM-dd"
                  placeholder="选择截至日期"
                ></el-date-picker>
                <el-button class="marginR" size="small" type="primary" @click="search">查询</el-button> -->
                <!-- <el-button class="create-btn"  type="primary" size="small" @click="downloadSelection" >导出</el-button> -->
              </div>
              <el-table :data="questionDetailRecord" class-name="table" ref="multipleTable" header-cell-class-name="table-header">
                <!-- <el-table-column prop="activityId" label="ID" width="55" align="center"></el-table-column> -->
                <el-table-column prop="userPhone" align="center" label="用户手机号"></el-table-column>
                <el-table-column prop="content" width="600" align="center" label="问卷详情">
                  <template slot-scope="scope">
                    <div class="f-con" v-html="formatterAns(scope.row.content)"></div>
                  </template>
                </el-table-column>
                <!-- <el-table-column prop="creatTime" align="center" label="填写日期"></el-table-column> -->
                <!-- <el-table-column label="操作" width="200" align="center">
                  <template slot-scope="scope">
                    <el-button type="text" icon="el-icon-view" @click="lookDetail(scope.row)">查看中奖记录</el-button>
                  </template>
                </el-table-column> -->
              </el-table>
              <div class="pagination">
                <el-pagination
                  background
                  :hide-on-single-page="true"
                  layout="total, prev, pager, next"
                  :current-page="query.pageSize"
                  :page-size="query.limite"
                  :total="total"
                  @current-change="handlePageChange"
                ></el-pagination>
              </div>
            </template>
          </el-tab-pane>
          <el-tab-pane label="问卷与海报记录" name="second">
            <template  v-if="activeName==='second'">
              <div class="handle-box">
               <!-- <el-date-picker
                  class="marginR"
                  size="small"
                  v-model="query.startTime"
                  type="date"
                  value-format="yyyy-MM-dd"
                  placeholder="选择开始日期"
                ></el-date-picker>
                <el-date-picker
                  class="marginR"
                  size="small"
                  v-model="query.endTime"
                  type="date"
                  value-format="yyyy-MM-dd"
                  placeholder="选择截至日期"
                ></el-date-picker>
                <el-button class="marginR" size="small" type="primary" @click="search">查询</el-button> -->
                <!-- <el-button class="create-btn"  type="primary" size="small" @click="downloadSelection" >导出</el-button> -->
              </div>
              <el-table :data="questionAndHBRecord" class-name="table" ref="multipleTable" header-cell-class-name="table-header">
                <!-- <el-table-column prop="activityId" label="ID" width="55" align="center"></el-table-column> -->
                <!-- <el-table-column prop="activityName" align="center" label="活动名称"></el-table-column> -->
                <el-table-column prop="askTotal" align="center" label="问卷总数"></el-table-column>
                <el-table-column prop="posterTotal" align="center" label="海报总数"></el-table-column>

              </el-table>
              <div class="pagination">
                <el-pagination
                  background
                  :hide-on-single-page="true"
                  layout="total, prev, pager, next"
                  :current-page="query.pageSize"
                  :page-size="query.limite"
                  :total="total"
                  @current-change="handlePageChange"
                ></el-pagination>
              </div>
            </template>
          </el-tab-pane>
        </el-tabs>

    </div>

  </div>

</template>

<script>
import qs from 'qs';
import {judgePath} from '@/utils/utils'
import { getData,getQuAndHBReq ,getQuestionDetailReq} from 'api/daiyan/dyActivity.js';
export default {
  components:{
  },
  data() {
    return {
      activeName: 'first',
      selList: [
        {
          label: '转盘抽奖',
          key: '1',
          activityType: '1',
          value: '转盘抽奖'
        },
        {
          label: '春节抽奖',
          key: '2',
          value: '2',
          activityType: '2'
        }
      ],
      query: {
        pageSize: 1,
        limite: 10,
        endTime:'',
        startTime:''
      },
      tableData: [],
      questionAndHBRecord:[],
      questionDetailRecord:[],
      total: 0,
    };
  },
  created() {
    this.getData();
  },
  mounted() {
    console.log(this.activeName)
  },
  methods: {
    formatterAns(cellValue){
      if(cellValue){
        let q_a_html = cellValue.split(';').map(item=>(`<p>${qs.parse(item).question.split('）')[1]}:${qs.parse(item).answer}</p>`));
        return q_a_html.join('')
      }
    },
    downloadSelection(){
      const {activityName,endTime,startTime} = this.query;
      let a = document.createElement("a");
      a.href =`${judgePath()}/data/excelExport/TypeOne?activityName=${activityName}&startTime=${startTime}&endTime=${endTime}`;
      document.body.appendChild(a);
      a.click();  //下载
      URL.revokeObjectURL(a.href);    // 释放URL 对象
      document.body.removeChild(a);   // 删除 a 标签
    },
    getData() {
      getData(this.query).then(res => {
        if(res.flag&&res.data){
          this.tableData = res.data.data;
          this.total = res.data.total || 0;
        }else{
          this.$message({
            type: 'error',
            message: `${res.message}`
          });
        }
      });
    },
    // changeActivityType(e) {
    //   this.$set(this.query, 'activityType', e.activityType);

    // },
    search(){
      this.$set(this.query, 'pageSize', 1);
      this.getDiffReq(this.activeName);
    },
    // 分页导航
    handlePageChange(val) {
      this.$set(this.query, 'pageSize', val);
      this.getDiffReq(this.activeName);
    },
    //查看详情
    lookDetail(row){
      this.$router.push({path:"record",query:{id:row.activityId}})
    },
    getQuAndHB(){
      this.questionAndHBRecord=[];
      getQuAndHBReq(this.query).then(res => {
        if(res.resultStat==='SUCCESS'&&res.data){
          if(this.activeName === 'second'){
            this.questionAndHBRecord.push(res.data);
          }
          this.total = res.data.total || 0;
        }else{
          this.$message({
            type: 'error',
            message: `${res.message}`
          });
        }
      });
    },
    getQuestionDetail(){
      this.questionDetailRecord = [];
      getQuestionDetailReq(this.query).then(res => {
        if(res.flag&&res.data){
          this.questionDetailRecord = res.data.data;
          this.total = res.data.total || 0;
        }else{
          this.$message({
            type: 'error',
            message: `${res.message}`
          });
        }
      });
    },
    getDiffReq(name){

      switch (name){
        case 'first':
            this.getData();
            break;
        case 'second':
            this.getQuAndHB();
            break;
        case 'third':
            this.getQuestionDetail();
            break;
        default:
          break;
      }
    },
    handleClick(tab, event) {
      this.$set(this.query, 'pageSize', 1);
      this.$set(this.query, 'startTime', '');
      this.$set(this.query, 'endTime', '');
      if(tab.name==='third'){
        this.$set(this.query, 'limite', 5);
      }else{
        this.$set(this.query, 'limite', 10);
      }
      this.getDiffReq(tab.name);
    }
  }
};
</script>

<style lang="less" scoped="scoped">
.crumbs {
  margin: 10px 0;
}
.container {
  padding: 30px;
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 5px;
  .handle-box {
    margin-bottom: 20px;
  }
  .create-btn {
    float: right;
    padding: 10px 15px;
    line-height: 1;
    font-size: 12px;
    border-radius: 3px;
    color: #FFF;
    background-color: #409EFF;
    border-color: #409EFF;
  }
  .marginR{
    margin-right: 15px;
  }
  .input0617 {
    width: 225px;
  }
}
.f-con {
  text-align: left;
}
.table {
      width: 100%;
      font-size: 14px;
      text-align: center;
  }
  .el-table th{
    text-align: center;
    background-color: #EBEEF5;
  }
.pagination{
  margin: 20px 0;
  text-align: center;
}
</style>
