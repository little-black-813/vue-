<template>
  <div class="activity-wrapper">
    <div class="crumbs"><span>公告管理</span></div>
    <div class="container">
      <div class="handle-box">
        <el-button class="create-btn"  type="primary" size="small" @click="createActivity" >创建活动</el-button>
      </div>
      <el-table :data="tableData" class-name="table" ref="multipleTable" header-cell-class-name="table-header" @selection-change="handleSelectionChange">

        <el-table-column prop="activityName" align="center" :formatter="formatterName" label="活动名称"></el-table-column>
        <el-table-column prop="noticeStatus" width="80" align="center" label="公告类型"  :formatter="formatterType"></el-table-column>
        <el-table-column prop="startTime" align="center" label="开始日期"></el-table-column>
        <el-table-column prop="endTime" align="center" label="结束日期"></el-table-column>
        <el-table-column prop="noticeContent" width="200" align="center" label="公告内容">

        </el-table-column>
        <el-table-column label="操作" width="60" align="center">
          <template slot-scope="scope">
            <el-button type="text" icon="el-icon-edit" @click="handleEdit(scope.row)">编辑</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination">
        <el-pagination
          background
          :hide-on-single-page="true"
          layout="total, prev, pager, next"
          :current-page="query.pageSize"
          :page-size="query.limite"
          :total="total"
          @current-change="handlePageChange"
        ></el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
  import bus from 'components/common/bus';
  import vDeldialog from 'components/dialog/delDialog';
  import { getData } from 'api/notice/index.js';
  import {activityList,noticeList} from '@/utils/constant'
  export default {
    components:{
      vDeldialog,
    },
    data() {
      return {
        query: {
          /* activityType: '',*/
          pageSize: 1,
          limite: 10
        },
        tableData: [],
        total: 0,
        multipleSelection: [],
        selInd:'',//选择table的下标,
      };
    },
    created() {
      this.getData();
    },
    methods: {
      formatterName(row, column, cellValue, index){
        return activityList.map(item=>{
          if(item.activityType===cellValue) return item.activityName;
        })
      },
      formatterType(row, column, cellValue, index){
        return noticeList.map(item=>{
          if(item.type===cellValue) return item.name;
        })
      },
      createActivity(){//创建活动
      // if(this.$store.state.notice.baseInfo){
      //   this.$store.dispatch('notice/setBaseInfo',{})
      // }

        this.$router.push({path:'/notice/add',query:{t:'a'}});
      },
      getData() {
        // this.$store.dispatch('setLoading',true);
        getData(this.query).then(res => {
          if(res.flag){
            this.tableData = res.data;
            this.total = res.data.total || 0;
          }

        });
      },
      // 多选操作
      handleSelectionChange(val) {
        this.multipleSelection = val;
      },
      // 分页导航
      handlePageChange(val) {
        this.$set(this.query, 'pageSize', val);
        this.getData();
      },
      handleEdit(row){
        this.$store.dispatch('notice/setBaseInfo',row);
        this.$router.push({path:"edit",query:{t:'e'}});
      },

    }
  };
</script>

<style lang="less" scoped="scoped">
  .crumbs {
    margin: 10px 0;
  }
  .container {
    padding: 30px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    .handle-box {
      margin-bottom: 20px;
    }
    .create-btn {
      float: right;
    }
  }
  .table {
    width: 100%;
    font-size: 14px;
    text-align: center;
  }
  .el-table th{
    text-align: center;
    background-color: #EBEEF5;
  }
  .pagination{
    margin: 20px 0;
    text-align: center;
  }
</style>
