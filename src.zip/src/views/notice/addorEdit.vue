<template>
  <div>
    <add v-if="type==='a'" :type="type"/>
      <add v-if="type==='e'" :type="type"/>
  </div>
</template>

<script>
import Add from './add.vue'
export default{
  components:{
    Add
  },
  computed:{
    type:function(){
      return this.$route.query.t
    }
  }
}
</script>

<style>
</style>
