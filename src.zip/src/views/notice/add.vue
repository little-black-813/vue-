<template>
  <div class="base-wrapper">
    <p class="base-title">基础信息</p>
    <el-form ref="creatForm" :model="creatForm" :rules="rules" label-width="140px" class="creat-act-form">

      <el-form-item label="活动名称：" prop="activityName">
        <el-select v-model="creatForm.activityName" size="small" placeholder="活动名称"  @change="changeActivity">
          <el-option v-for="item in activityList" :key="item.activityType"  :label="item.activityName" :value="item.activityType"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="公告类型：" prop="noticeStatus">
        <el-select v-model="creatForm.noticeStatus" size="small" placeholder="公告类型"  @change="changeNotice">
          <el-option v-for="item in noticeList" :key="item.type"  :label="item.name" :value="item.type"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="公告时间" required>
        <el-col :span="11">
          <el-form-item prop="startTime">
            <el-date-picker type="datetime" placeholder="选择开始日期" @change="changeTime1" v-model="creatForm.startTime" style="width: 100%;"></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col class="line" :span="2">-</el-col>
        <el-col :span="11">
          <el-form-item prop="endTime">
            <el-date-picker type="datetime" placeholder="选择截至日期" @change="changeTime2" v-model="creatForm.endTime" style="width: 100%;"></el-date-picker>
          </el-form-item>
        </el-col>
      </el-form-item>
      <el-form-item label="是否显示:">
          <el-switch v-model="creatForm.isShow" active-value="0" inactive-value="1"></el-switch>
      </el-form-item>
      <el-form-item label="公告内容：" prop="noticeContent"><el-input type="textarea" v-model.trim="creatForm.noticeContent" rows="5"></el-input></el-form-item>
      <el-form-item>
        <el-button type="primary" @click="submitForm('creatForm')">立即创建</el-button>
        <!--<el-button @click="resetForm('creatForm')">{{creatForm.activityType}}重置</el-button>-->
      </el-form-item>

    </el-form>
  </div>
</template>

<script>
import bus from 'components/common/bus';
import { mapState } from 'vuex';
import { createOrEditBaseActivityReq } from 'api/activity.js';
import { isEmptyObject,formatDate,isEmptyValue } from '@/utils/utils';
export default {
  props:['type'],
  data() {
    return {
      isShowCenter:false,
      creatForm: {
        id:0,
        activityName: '',
        noticeStatus:'',
        noticeContent: '',
        startTime: '',
        endTime: '',
        isShow:'0'
      },
      noticeList:[{
        type:'0',
        name:'活动下线'
      },
      {
        type:'1',
        name:'公告提示'
      }],
      activityList:[
        {
          activityType:'0',
          activityName:'家庭流量共享'
        },
        {
          activityType:'1',
          activityName:'抽奖活动'
        },
        {
          activityType:'2',
          activityName:'带盐活动'
        }
      ],
      rules: {
        activityName: [{ required: true, message: '请选择活动名称', trigger: 'change' }],
        noticeStatus:[{ required: true, message: '请选择公告类型', trigger: 'change' }],
        startTime: [{ type: 'string', required: true, message: '请选择活动开始时间', trigger: 'change' }],
        endTime: [{ type: 'string', required: true, message: '请选择活动结束时间', trigger: 'change' }],
        noticeContent: [{ required: true, message: '请输入公告内容', trigger: 'blur' }],
      }
    };
  },
  created() {
   this.creatForm = this.initForm();
  },
  mounted() {
  },
  methods: {
    changeActivity(e){
      this.$set(this.creatForm, 'activityName', e);
    },
    changeNotice(e){
      this.$set(this.creatForm, 'noticeStatus', e);
    },
    changeTime1(val){
        this.$set(this.creatForm,'startTime',formatDate(val,'yyyy-MM-dd HH:mm:ss'));
    },
    changeTime2(val){
        this.$set(this.creatForm,'endTime',formatDate(val,'yyyy-MM-dd HH:mm:ss'));
    },
    initForm(){
      console.log(this.type)
      if(this.type==='e'){//编辑
        return this.$store.state.notice.baseInfo;
      }else {
        return this.creatForm;
      }
    },
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          //存储vuex，上一步时，可以会显
          // this.$store.dispatch('setActivityBaseInfo', { activityInfo: this.creatForm })
          let reqUrl ='/notice/setNotice';

          this.createActivity({reqUrl,creatForm:{...this.creatForm}});
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    //创建活动基础信息
    createActivity(params) {
      createOrEditBaseActivityReq(params).then(res => {
        if (res.flag) {
          this.$message({
            message: '恭喜你，创建基础信息成功',
            type: 'success'
          });
          bus.$emit('close_current_tags');
          this.$router.push({path:'/notice/index'})
        }
      });
    }
  }
};
</script>

<style scoped="scoped" lang="less">
.base-wrapper {
  padding: 20px 10px;
  background-color: #FFFFFF;
  .line {
    text-align: center;
  }
  .base-title {
    font-size: 20px;
    margin: 15px 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eeeeee;
  }
  .creat-act-form {
    width: 60%;
  }
}
</style>
