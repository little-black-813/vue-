<template>
  <div class="activity-wrapper">
    <div class="crumbs"><span>拆福袋管理</span></div>
    <div class="container">
      <div class="handle-box">
        <el-button class="create-btn"  type="primary" size="small" @click="createActivity" >创建活动</el-button>
      </div>
      <el-table :data="tableData" class-name="table" ref="multipleTable" header-cell-class-name="table-header" @selection-change="handleSelectionChange">
        <el-table-column v-for="(item,ind) in columns" :key="ind" :prop="item.prop" align="center" :label="item.label"></el-table-column>
        <el-table-column label="操作" width="200" align="center">
          <template slot-scope="scope">
            <el-button type="text" icon="el-icon-edit" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button type="text" icon="el-icon-delete" class="red" @click="handleDelete(scope.row,scope.$index)">删除</el-button>
            <el-button type="text" icon="el-icon-paperclip" class="red" @click="getLink( scope.row)">获取链接</el-button>
            <el-button type="text" icon="el-icon-edit" @click="lookRecord(scope.row,'p')">兑换记录</el-button>

          </template>
        </el-table-column>
      </el-table>
      <div class="pagination">
        <el-pagination
          background
          :hide-on-single-page="true"
          layout="total, prev, pager, next"
          :current-page="query.pageSize"
          :page-size="query.limite"
          :total="total"
          @current-change="handlePageChange"
        ></el-pagination>
      </div>
    </div>
    <v-deldialog v-if="delVisiable" url="/bagActivity/deleteActivity" :show="delVisiable" :name="multipleSelection[0].activityName" :param="{activityId:multipleSelection[0].activityId,activityType:'luckbag'}" :selInd="selInd"></v-deldialog>

    <v-linkdialog v-if="linkVisiable" asyncUrl="" type="luckybag" :show="linkVisiable" :activityId="multipleSelection[0].activityId"></v-linkdialog>
  </div>
</template>

<script>
  import { mapMutations } from 'vuex'
  import bus from 'components/common/bus';
  import vLinkdialog from 'components/dialog/LinkDialog';
  import vDeldialog from 'components/dialog/delCommonDialog';
  import { getMainInfoReq } from 'api/commonApi.js';
  export default {
    components:{
      vDeldialog,
      vLinkdialog
    },
    data() {
      return {
        columns: [
                {
                  label: "活动名称",
                  prop: "activityName"
                },
                {
                  label: "开始日期",
                  prop: "activityStartTime"
                },
                {
                  label: "结束日期",
                  prop: "activityEndTime"
                },
                {
                  label: "创建日期",
                  prop: "createdTime"
                }
              ],
        query: {
          pageSize: 1,
          limit: 10,
          activityType:'luckyBag'//luckyBagActivity
        },
        tableData: [],
        total: 0,
        multipleSelection: [],
        delVisiable:false,
        selInd:'',//选择table的下标,
        linkVisiable:false
      };
    },
    created() {
      bus.$on('closeDel',params=>{
        // debugger
        this.linkVisiable = params.show;
        this.delVisiable = params.show;
        this.multipleSelection = [];
        this.selInd = '';
        params.reqFlag && this.getData();
      })
      this.getData();
    },
    beforeDestroy(){
      bus.$off('closeDel')
    },
    methods: {
      ...mapMutations( 'bag', ['setActivityBaseInfo', 'setActivityId', 'setEditBaseInfo']),
      lookRecord(row){
        this.$router.push({path:"ex-record",query:{id:row.activityId}});
      },
      createActivity(){//创建活动
        // sessionStorage.setItem('flagN','n');
        this.setActivityBaseInfo({})
        this.setEditBaseInfo({})
        this.setActivityId('')
        this.$router.push('/bag/add');
      },
      getData() {
        getMainInfoReq({url:'/bagActivity/listActivity',data:this.query}).then(res => {
          this.tableData = res.data.list;
          this.total = res.data.total || 0;

        });
      },
      changeActivityType(e) {
        this.$set(this.query, 'activityType', e.activityType);
        this.getData();
      },
      // 多选操作
      handleSelectionChange(val) {
        this.multipleSelection = val;
      },
      // 分页导航
      handlePageChange(val) {
        this.$set(this.query, 'pageSize', val);
        this.getData();
      },
      handleDelete(row,ind){
        // debugger
        this.delVisiable = true;
        this.multipleSelection = [row];
      },
      handleEdit(row){
        this.$router.push({path:"edit",query:{id:row.activityId}});
      },
      getLink(row){
        this.linkVisiable = true;
        this.multipleSelection = [row];
      },
      medicalRecord(row){
        this.$router.push({path:"detail",query:{id:row.activityId}});
      }
    }
  };
</script>

<style lang="less" scoped="scoped">
  .crumbs {
    margin: 10px 0;
  }
  .container {
    padding: 30px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    .handle-box {
      margin-bottom: 20px;
    }
    .create-btn {
      float: right;
    }
  }
  .table {
    width: 100%;
    font-size: 14px;
    text-align: center;
  }
  .el-table th{
    text-align: center;
    background-color: #EBEEF5;
  }
  .pagination{
    margin: 20px 0;
    text-align: center;
  }
</style>
