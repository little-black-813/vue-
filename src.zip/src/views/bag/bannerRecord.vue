<template>
  <div class="activity-wrapper">
    <el-breadcrumb separator="/">
      <el-breadcrumb-item >拆福袋banner目标客户</el-breadcrumb-item>
      <!-- <el-breadcrumb-item>目标中奖记录</el-breadcrumb-item> -->
    </el-breadcrumb>
    <div class="container">
      <div class="handle-box">
        <!-- <a class="create-btn" download type="primary" size="small" href="/data/excelExport/TypeOne">导出</a> -->
      </div>
      <el-table :data="tableData" class-name="table" ref="multipleTable" header-cell-class-name="table-header">
        <el-table-column prop="bannerName" align="center" label="banner名称"></el-table-column>
        <el-table-column prop="phone" align="center" label="目标客户手机号"></el-table-column>
      </el-table>
      <div class="pagination">
        <el-pagination
          background
          :hide-on-single-page="true"
          layout="total, prev, pager, next, jumper"
          :current-page="query.pageSize"
          :page-size="query.limit"
          :total="total"
          @current-change="handlePageChange"
        ></el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import { getMainInfoReq } from 'api/commonApi.js';
export default {
  components:{
  },
  data() {
    return {
      query: {
        pageSize: 1,
        limit: 10,
      },
      tableData: [],
      total: 0,
    };
  },
  created() {
    this.getData();
  },
  methods: {
    getData() {
      const {ad,pd} = this.$route.query;
      getMainInfoReq({url:'/bagActivityBanner/getTarget',data:{...this.query,bannerId:pd}}).then(res => {
        this.tableData = res.data.list;
        this.total = res.data.total;
      });
    },
    // 分页导航
    handlePageChange(val) {
      this.$set(this.query, 'pageSize', val);
      this.getData();
    },
  }
};
</script>

<style lang="less" scoped="scoped">
  .el-breadcrumb{
    font-size: 16px;
    margin: 10px 0;
  }
.container {
  padding: 30px;
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 5px;
  .handle-box {
    margin-bottom: 20px;
  }
  .create-btn {
    float: right;
    padding: 10px 15px;
    line-height: 1;
    font-size: 12px;
    border-radius: 3px;
    color: #FFF;
    background-color: #409EFF;
    border-color: #409EFF;
  }
  .marginR{
    margin-right: 15px;
  }

}
.table {
      width: 100%;
      font-size: 14px;
      text-align: center;
  }
  .el-table th{
    text-align: center;
    background-color: #EBEEF5;
  }
.pagination{
  margin: 20px 0;
  text-align: center;
}
</style>
