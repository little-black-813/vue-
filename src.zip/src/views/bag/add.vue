<template>
  <div class="add-activity-wrapper">
    <el-breadcrumb separator="/">
      <el-breadcrumb-item :to="{ path: '/bag/index' }"
        >拆福袋</el-breadcrumb-item
      >
      <el-breadcrumb-item>创建活动</el-breadcrumb-item>
    </el-breadcrumb>
    <section class="step-warpper">
      <el-steps :active="active" align-center>
        <el-step v-for="(item,ind) in tabList" :key="item.id">
          <i class="icon-txt" slot="icon">{{item.txt}}</i>
        </el-step>
      </el-steps>
      <div class="step-con">
        <v-baseform v-if="active === 1" type="add"></v-baseform>
         <v-setform v-else-if="active === 2" type="add"></v-setform>
         <v-bannerform v-else-if="active === 3" type="add"></v-bannerform>
         <v-task v-else-if="active === 4" type="add"></v-task>
        <v-shareform v-else-if="active === 5" type="add"></v-shareform>
        <v-prize v-else-if="active ===6" type="add"></v-prize>
        <v-exchange v-else type="add"></v-exchange>
      </div>
    </section>
  </div>
</template>

<script>
import { mapMutations } from 'vuex'
import bus from "components/common/bus";
import vBaseform from "components/bag/base";
import vSetform from "components/bag/set";
import vTask from "components/bag/task";
import vBannerform from "components/bag/banner";
import vPrize from "components/bag/prize";
import vExchange from "components/bag/exchange";
import vShareform from "components/bag/share";
export default {
  components: {
    vBaseform,
    vPrize,
    vSetform,
    vTask,
    vExchange,
    vBannerform,
    vShareform
  },
  data() {
    return {
      active: 1,
      tabList: [
        {
          txt: '基础信息',
          id: 1
        },
        {
          txt: '活动设置',
          id: 2
        },
        {
          txt: '广告设置',
          id: 3
        },
        {
          txt: '任务设置',
          id: 4
        },
        {
          txt: '分享设置',
          id: 5
        },
        {
          txt: '奖品设置',
          id: 6
        },
        {
          txt: '兑换设置',
          id: 7
        }
      ]
    };
  },
  created() {
    // this.setActivityId('');
    // this.setActivityBaseInfo('')
    // this.setEditBaseInfo('')
    bus.$on("bagAction", flag => {
      if (flag === "add") {
        //下一步，上一步
        this.next();
      } else {
        this.prev();
      }
    });
  },
  beforeDestroy() {
    bus.$off("bagAction");
  },
  methods: {
    ...mapMutations( 'bag', ['setActivityBaseInfo', 'setActivityId', 'setEditBaseInfo']),
    next() {
      if (this.active++ > 7) this.active = 0;
    },
    prev() {
      if (this.active-- <= 0) this.active = 0;
    }
  }
};
</script>

<style scoped="scoped" lang="less">
.el-breadcrumb {
  font-size: 16px;
  margin: 10px 0;
}
.step-warpper {
  background-color: #ffffff;
  padding: 20px 0;
  .step-con {
    margin-top: 30px;
  }
}
.icon-txt {
  font-style: normal;
  width: 80px;
  height: 80px;
  line-height: 80px;
  cursor: pointer;
}
::v-deep {
  .el-step__icon {
    width: 70px;
    height: 70px;
  }
  .el-step.is-center .el-step__line {
    top: 50%;
    transform: translateY(-50%);
  }
}
</style>
