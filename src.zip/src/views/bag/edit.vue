<template>
  <div class="add-activity-wrapper">
    <el-breadcrumb separator="/">
      <el-breadcrumb-item :to="{ path: '/bag/index' }"
        >拆福袋</el-breadcrumb-item
      >
      <el-breadcrumb-item>编辑活动</el-breadcrumb-item>
    </el-breadcrumb>
    <section class="step-warpper">
      <el-steps :active="active" align-center>
        <el-step v-for="(item,ind) in tabList"  :key="item.id">
          <i class="icon-txt" @click="checkStep(item.id)" slot="icon">{{item.txt}}</i>
        </el-step>
      </el-steps>
      <div class="step-con">
        <v-baseform v-if="active === 1" type="edit"></v-baseform>
         <v-setform v-else-if="active === 2" type="edit"></v-setform>
         <v-bannerform v-else-if="active === 3" type="edit"></v-bannerform>
         <v-task v-else-if="active === 4" type="edit"></v-task>
        <v-shareform v-else-if="active === 5" type="edit"></v-shareform>
        <v-prize v-else-if="active ===6" type="edit"></v-prize>
        <v-exchange v-else type="edit"></v-exchange>
      </div>
    </section>
  </div>
</template>

<script>
import { mapMutations } from 'vuex'
import bus from "components/common/bus";
import vBaseform from "components/bag/base";
import vSetform from "components/bag/set";
import vTask from "components/bag/task";
import vBannerform from "components/bag/banner";
import vPrize from "components/bag/prize";
import vExchange from "components/bag/exchange";
import vShareform from "components/bag/share";
import { postReq } from '@/api/commonApi'
export default {
  components: {
    vBaseform,
    vPrize,
    vSetform,
    vTask,
    vExchange,
    vBannerform,
    vShareform
  },
  data() {
    return {
      active: 0,
      tabList: [
        {
          txt: '基础信息',
          id: 1
        },
        {
          txt: '活动设置',
          id: 2
        },
        {
          txt: '广告设置',
          id: 3
        },
        {
          txt: '任务设置',
          id: 4
        },
        {
          txt: '分享设置',
          id: 5
        },
        {
          txt: '奖品设置',
          id: 6
        },
        {
          txt: '兑换设置',
          id: 7
        }
      ]
    };
  },
  created() {
    this.getDetail()
    bus.$on("bagAction", flag => {
      console.log('bag-add-flag-----',flag)
      if (flag === "add") {
        //下一步，上一步
        this.next();
      } else {
        this.prev();
      }
    });
  },
  beforeDestroy() {
    bus.$off("bagAction");
  },
  methods: {
    ...mapMutations('bag', ['setActivityId','setEditBaseInfo', 'setHttpDomain']),
    getDetail(){
      const {id} = this.$route.query;
      let that = this;
       postReq({reqUrl:'/bagActivity/selectActivityById',form:{activityId:id}}).then (res=>{
        that.setEditBaseInfo(res.data.bagActivity);
        this.active = 1;
        that.setHttpDomain(res.data.httpDomain)
        that.setActivityId(res.data.bagActivity.activityId)
      })
    },
    next() {
      if (this.active++ > 7) this.active = 0;
    },
    prev() {
      if (this.active-- <= 0) this.active = 0;
    },
    checkStep(step){
      console.log('step---',step)
      this.active = step;
    }
  }
};
</script>

<style scoped="scoped" lang="less">
.el-breadcrumb {
  font-size: 16px;
  margin: 10px 0;
}
.step-warpper {
  background-color: #ffffff;
  padding: 20px 0;
  .step-con {
    margin-top: 30px;
  }
}
.icon-txt {
  font-style: normal;
  width: 80px;
  height: 80px;
  line-height: 80px;
  cursor: pointer;
}
::v-deep {
  .el-step__icon {
    width: 70px;
    height: 70px;
  }
  .el-step.is-center .el-step__line {
    top: 50%;
    transform: translateY(-50%);
  }
}
</style>
