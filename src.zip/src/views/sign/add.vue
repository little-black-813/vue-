<template>
  <div class="add-activity-wrapper">
    <el-breadcrumb separator="/">
      <el-breadcrumb-item :to="{ path: '/sign/index' }">签到管理</el-breadcrumb-item>
      <el-breadcrumb-item>创建活动</el-breadcrumb-item>
    </el-breadcrumb>
	  <section class="step-warpper">
      <el-steps :active="active" align-center>
        <el-step v-for="step in stepList" :key="step.id">
          <i class="icon-txt" slot="icon">{{step.txt}}</i>
        </el-step>
      </el-steps>
      <div class="step-con">
        <v-baseform v-if="active===1" type="add"></v-baseform>
        <v-setform v-if="active===2" type="add"></v-setform>
        <!-- <v-turntable v-if="active===3" type="add"></v-turntable> -->
        <!-- <v-ruleform v-if="active===4" type="add"></v-ruleform> -->
        <v-shareform v-if="active===3" type="add"></v-shareform>
        <v-prize v-if="active===4" type="add"></v-prize>
      </div>
    </section>
  </div>
</template>

<script>
import bus from 'components/common/bus';
import vBaseform from 'components/sign/base'
import vSetform from 'components/activity/set'
// import vRuleform from 'components/activity/rule'
import vShareform from 'components/activity/share'
// import vTurntable from 'components/activity/setTurntable'
// import vPrize from 'components/activity/prize'
import vPrize from 'components/sign/prize'
export default{
  components:{
    vBaseform,
    vSetform,
    // vTurntable,
    // vRuleform,
    vShareform,
    vPrize
  },
	data(){
		return {stepList:[
        {
          id:1,
          txt:'创建活动'
        },
        {
          id:2,
          txt:'活动设置'
        },
        {
          id:3,
          txt:'分享设置'
        },
        {
          id:4,
          txt:'奖品设置'
        }
      ],
			active:0
		}
	},
  created() {
    this.active = 1;
     bus.$on('activityOp',flag=>{
       if(flag==='add'){//下一步，上一步
         this.next();
       }else if(flag==='sign'){
        this.next();
       }else{
         this.prev();
       }
     })
  },
  beforeDestroy() {
    bus.$off('activityOp');
  },
  methods:{
    next(){
      if (this.active++ > this.stepList.length) this.active = 0;
    },
    prev(){
      if(this.active--<=0) this.active = 0;
    }
  }
}
</script>

<style scoped="scoped" lang="less">
.el-breadcrumb{
  font-size: 16px;
  margin: 10px 0;
}
.step-warpper{
  background-color: #FFFFFF;
  padding: 20px 0;
  .step-con{
    margin-top: 30px;
  }
}
.icon-txt{
  font-style: normal;
}
::v-deep {
  .el-step__icon{
    width: 70px;
    height: 70px;

  }
  .el-step.is-center .el-step__line{
    top: 50%;
    transform: translateY(-50%);
  }
}

</style>
