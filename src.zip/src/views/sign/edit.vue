<template>
  <div class="add-activity-wrapper">
    <el-breadcrumb separator="/">
      <el-breadcrumb-item :to="{ path: '/sign/index' }">签到管理</el-breadcrumb-item>
      <el-breadcrumb-item>编辑活动</el-breadcrumb-item>
    </el-breadcrumb>
	  <section class="step-warpper">
      <el-steps :active="active" align-center>
        <el-step v-for="step in stepList" :key="step.id">
          <i class="icon-txt" @click="checkStep(step.id)" slot="icon">{{step.txt}}</i>
        </el-step>
      </el-steps>
      <div class="step-con">
        <v-baseform v-if="active===1" type="edit"></v-baseform>
        <v-setform v-if="active===2" type="edit"></v-setform>
        <!-- <v-turntable v-if="active===3" type="edit"></v-turntable>
        <v-ruleform v-if="active===4" type="edit"></v-ruleform> -->
        <v-shareform v-if="active===3" type="edit"></v-shareform>
        <v-prize v-if="active===4" type="edit"></v-prize>
      </div>
    </section>
  </div>
</template>

<script>
import bus from 'components/common/bus';
import vBaseform from 'components/sign/base'
import vSetform from 'components/activity/set'
import vTurntable from 'components/activity/setTurntable'
import vRuleform from 'components/activity/rule'
import vShareform from 'components/activity/share'
// import vPrize from 'components/activity/prize'
import vPrize from 'components/sign/prize'
import { getActivityData } from 'api/activity.js';
export default{
  components:{
    vBaseform,
    vSetform,
    vTurntable,
    vRuleform,
    vShareform,
    vPrize
  },
	data(){
		return {
      stepList:[
        {
          id:1,
          txt:'编辑活动'
        },
        {
          id:2,
          txt:'活动设置'
        },
        {
          id:3,
          txt:'分享设置'
        },
        {
          id:4,
          txt:'奖品设置'
        }
      ],
			active:0
		}
	},
  created() {
    this.getDetail()
     bus.$on('activityOp',flag=>{
       if(flag==='add'){//下一步，上一步
         this.next();
       }else if(flag==='sign'){
        this.next();
       }else{
         this.prev();
       }
     })
    this.$route.query.t = 's'
  },
  beforeDestroy() {
    bus.$off('activityOp');
  },
  methods:{
    getDetail(){
      const {id,t} = this.$route.query;
      // console.log(id, t)
      let that = this;
       getActivityData({activityId:id}).then (res=>{
         if(t){
           that.active = 4;
         }else{
           that.active = 1;
           
         }
        that.$store.dispatch('setEditbaseInfo', { activityInfo: {...res.data.data[0]} });
      })
    },
    next(){
      if (this.active++ > 4) this.active = 0;
    },
    prev(){
      if(this.active--<=0) this.active = 0;
    },
    checkStep(step){
      console.log(step)
      this.active = step;
    }
  }
}
</script>

<style scoped="scoped" lang="less">
.el-breadcrumb{
  font-size: 16px;
  margin: 10px 0;
}
.step-warpper{
  background-color: #FFFFFF;
  padding: 20px 0;
  .step-con{
    margin-top: 30px;
  }
}
.icon-txt{
  font-style: normal;
  width: 80px;
  height: 80px;
  line-height: 80px;
}
::v-deep {
  .el-step__icon{
    width: 80px;
    height: 80px;
    cursor: pointer;
  }
  .el-step.is-center .el-step__line{
    top: 50%;
    transform: translateY(-50%);
  }
}

</style>
