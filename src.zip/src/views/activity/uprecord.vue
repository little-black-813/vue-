<template>
  <div class="activity-wrapper">
    <el-breadcrumb separator="/">
      <el-breadcrumb-item :to="{ path: '/' }">抽奖活动管理</el-breadcrumb-item>
      <el-breadcrumb-item>弹窗目标用户</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="container">
      <div class="handle-box">
        <!-- <a class="create-btn" download type="primary" size="small" href="/data/excelExport/TypeOne">导出</a> -->
      </div>
      <el-table :data="tableData" class-name="table" ref="multipleTable" header-cell-class-name="table-header">
        <el-table-column width='150' prop="activityName" align="center" label="活动名称"></el-table-column>
        <el-table-column width='120' prop="prizeName" align="center" label="奖品名称"></el-table-column>
        <el-table-column width='140' prop="aimsPhone" align="center" label="目标客户手机号"></el-table-column>
        <el-table-column prop="targetLink" align="center" label="链接"></el-table-column>
      </el-table>
      <div class="pagination">
        <el-pagination
          background
          :hide-on-single-page="true"
          layout="total, prev, pager, next,jumper"
          :current-page="query.pageSize"
          :page-size="query.limite"
          :total="total"
          @current-change="handlePageChange"
        ></el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import { getTanCInfoReq } from 'api/activity.js';
export default {
  components:{
  },
  data() {
    return {
      selList: [
        {
          label: '转盘抽奖',
          key: '1',
          activityType: '1',
          value: '转盘抽奖'
        },
        {
          label: '春节抽奖',
          key: '2',
          value: '2',
          activityType: '2'
        }
      ],
      query: {
        pageSize: 1,
        limite: 10,
      },
      tableData: [],
      total: 0,
    };
  },
  created() {
    this.getData();
  },
  methods: {
    getData() {
      const {ad,pd} = this.$route.query;
      getTanCInfoReq({...this.query,activityId:ad,prizeId:pd}).then(res => {
        console.log(res);
        this.tableData = res.data.data;
        this.total = res.data.total;
      });
    },
    // 分页导航
    handlePageChange(val) {
      this.$set(this.query, 'pageSize', val);
      this.getData();
    },
  }
};
</script>

<style lang="less" scoped="scoped">
  .el-breadcrumb{
    font-size: 16px;
    margin: 10px 0;
  }
.container {
  padding: 30px;
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 5px;
  .handle-box {
    margin-bottom: 20px;
  }
  .create-btn {
    float: right;
    padding: 10px 15px;
    line-height: 1;
    font-size: 12px;
    border-radius: 3px;
    color: #FFF;
    background-color: #409EFF;
    border-color: #409EFF;
  }
  .marginR{
    margin-right: 15px;
  }

}
.table {
      width: 100%;
      font-size: 14px;
      text-align: center;
  }
  .el-table th{
    text-align: center;
    background-color: #EBEEF5;
  }
.pagination{
  margin: 20px 0;
  text-align: center;
}
</style>
