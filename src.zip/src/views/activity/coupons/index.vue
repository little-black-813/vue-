<template>
  <div class="activity-wrapper">
    <div class="crumbs"><span>虚拟卡券管理</span></div>
    <div class="container">
      <div class="handle-box">
       <!-- <el-select v-model="query.activityType" size="small" placeholder="活动类型" value-key="label" @change="changeActivityType">
          <el-option v-for="item in selList" :key="item.activityType" :label="item.label" :value="item"></el-option>
        </el-select>-->
      </div>
      <el-table :data="tableData" class-name="table" ref="multipleTable" header-cell-class-name="table-header" @selection-change="handleSelectionChange">
        <!-- <el-table-column type="selection" width="55" align="center"></el-table-column> -->
        <!-- <el-table-column prop="activityId" label="ID" width="55" align="center"></el-table-column> -->
        <el-table-column prop="prizeName" align="center" label="奖品名称"></el-table-column>
        <el-table-column prop="userPhone" align="center" label="手机号"></el-table-column>
        <!-- <el-table-column prop="createName" align="center" label="创建人"></el-table-column> -->
        <el-table-column label="操作" width="200" align="center">
          <template slot-scope="scope">
            <el-button type="text" icon="el-icon-edit" @click="handleEdit(scope.row)">处理</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination">
        <el-pagination
          background
          :hide-on-single-page="true"
          layout="total, prev, pager, next"
          :current-page="query.pageSize"
          :page-size="query.limite"
          :total="total"
          @current-change="handlePageChange"
        ></el-pagination>
      </div>
    </div>
    <v-deldialog v-if="delVisiable" :show="delVisiable" :name="multipleSelection[0].activityName" :id="multipleSelection[0].id" :selInd="selInd"></v-deldialog>
    <v-linkdialog v-if="linkVisiable"  :show="linkVisiable" :activityId="multipleSelection[0].activityId"></v-linkdialog>
  </div>
</template>

<script>
import bus from 'components/common/bus';
import vLinkdialog from 'components/dialog/LinkDialog';
import vDeldialog from 'components/dialog/delDialog';
import { getCouponsData } from 'api/coupons.js';
import { modifyStatus } from 'api/coupons.js';
export default {
  components:{
    vDeldialog,
    vLinkdialog
  },
  data() {
    return {
      selList: [
        {
          label: '转盘抽奖',
          key: '1',
          activityType: '1',
          value: '转盘抽奖'
        },
        {
          label: '春节抽奖',
          key: '2',
          value: '2',
          activityType: '2'
        }
      ],
      query: {
       /* activityType: '',*/
        pageSize: 1,
        limite: 10
      },
      tableData: [],
      total: 0,
      multipleSelection: [],
      delVisiable:false,
      selInd:'',//选择table的下标,
      linkVisiable:false
    };
  },
  created() {
    bus.$on('closeDel',flag=>{
      this.linkVisiable = flag;
      this.delVisiable = flag;
      this.multipleSelection = [];
      this.selInd = '';
    })
    this.getData();
  },
  methods: {
    getData() {
      // this.$store.dispatch('setLoading',true);
      getCouponsData(this.query).then(res => {
        if(res.flag){
          res.data.list = res.data;
          this.tableData = res.data.data;
          this.total = res.data.total || 0;
        }

      });
    },
    updateStatus(recordId){
      modifyStatus({couponsForm:{recordId:recordId}}).then(res => {
        if(res.flag){
          res.data.list = res.data;
        }
        if (res.code==200){

          location.reload();
        }

      });
    },
    changeActivityType(e) {
      this.$set(this.query, 'activityType', e.activityType);
      this.getData();
    },
    // 多选操作
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    // 分页导航
    handlePageChange(val) {
      this.$set(this.query, 'pageSize', val);
      this.getData();
    },
    handleDelete(ind,row){
      this.delVisiable = true;
      this.selInd = ind;
      this.multipleSelection = [row];
    },
    handleEdit(row,t){
      this.$confirm(`确定要处理【${row.userPhone}】这条虚拟卡券记录吗？`, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
              }).then(() => {
                this.updateStatus(row.recordId);
              }).catch(() => {
                this.$message({
                  type: 'info',
                  message: '已取消处理'
                });
              });
    },
    //查看详情
    lookDetail(row){
      this.$router.push({path:"detail",query:{id:row.activityId}});
    },
    getLink(row){
      this.linkVisiable = true;
      // bus.$emit('openLink', true);
      // row.creatUrl='124'
      this.multipleSelection = [row];
    }
  }
};
</script>

<style lang="less" scoped="scoped">
.crumbs {
  margin: 10px 0;
}
.container {
  padding: 30px;
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 5px;
  .handle-box {
    margin-bottom: 20px;
  }
  .create-btn {
    float: right;
  }
}
.table {
      width: 100%;
      font-size: 14px;
      text-align: center;
  }
  .el-table th{
    text-align: center;
    background-color: #EBEEF5;
  }
.pagination{
  margin: 20px 0;
  text-align: center;
}
</style>
