<template>
  <div class="activity-wrapper">
    <el-breadcrumb separator="/">
      <el-breadcrumb-item :to="{ path: '/data' }">数据管理</el-breadcrumb-item>
      <el-breadcrumb-item>中奖记录</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="container">
      <div class="handle-box">
        <a class="create-btn" download type="primary" size="small" href="/data/excelExport/TypeOne">导出</a>
      </div>
      <el-table :data="tableData" class-name="table" ref="multipleTable" header-cell-class-name="table-header">
        <el-table-column prop="creatTime" align="center" label="姓名"></el-table-column>
        <el-table-column prop="activityName" align="center" label="手机号"></el-table-column>
        <el-table-column prop="peopleNum" align="center" label="中奖时间"></el-table-column>
        <el-table-column prop="peopleCount" align="center" label="奖项"></el-table-column>
        <el-table-column prop="shareNum" align="center" label="奖品名称"></el-table-column>
      </el-table>
      <div class="pagination">
        <el-pagination
          background
          :hide-on-single-page="true"
          layout="total, prev, pager, next"
          :current-page="query.pageIndex"
          :page-size="query.pageSize"
          :total="total"
          @current-change="handlePageChange"
        ></el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import { getLotteryInfoReq } from 'api/data.js';
export default {
  components:{
  },
  data() {
    return {
      selList: [
        {
          label: '转盘抽奖',
          key: '1',
          activityType: '1',
          value: '转盘抽奖'
        },
        {
          label: '春节抽奖',
          key: '2',
          value: '2',
          activityType: '2'
        }
      ],
      query: {
        pageSize: 1,
        limite: 10,
      },
      tableData: [],
      total: 0,
    };
  },
  created() {
    this.getData();
  },
  methods: {
    getData() {
      const {id} = this.$route.query;
      getLotteryInfoReq({...this.query,activityId:id}).then(res => {
        console.log(res);
        this.tableData = res.data.data;
        this.total = res.data.total;
      });
    },
    // 分页导航
    handlePageChange(val) {
      this.$set(this.query, 'pageSize', val);
      this.getData();
    },
  }
};
</script>

<style lang="less" scoped="scoped">
  .el-breadcrumb{
    font-size: 16px;
    margin: 10px 0;
  }
.container {
  padding: 30px;
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 5px;
  .handle-box {
    margin-bottom: 20px;
  }
  .create-btn {
    float: right;
    padding: 10px 15px;
    line-height: 1;
    font-size: 12px;
    border-radius: 3px;
    color: #FFF;
    background-color: #409EFF;
    border-color: #409EFF;
  }
  .marginR{
    margin-right: 15px;
  }

}
.table {
      width: 100%;
      font-size: 14px;
      text-align: center;
  }
  .el-table th{
    text-align: center;
    background-color: #EBEEF5;
  }
.pagination{
  margin: 20px 0;
  text-align: center;
}
</style>
