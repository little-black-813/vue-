<template>
  <div class="activity-wrapper">
    <div class="crumbs"><span>数据管理</span></div>
    <div class="container">
      <div class="handle-box">
        <el-input class="input0617 marginR" v-model="query.activityName" size="small" placeholder="请输入活动名称内容"></el-input>
        <!-- <el-select class="marginR" v-model="query.activityType" size="small" placeholder="活动类型" value-key="label" >
          <el-option v-for="item in selList" :key="item.activityType" :label="item.label" :value="item.activityType"></el-option>
        </el-select> -->
        <el-date-picker
          class="marginR"
          size="small"
          v-model="query.beginTime"
          type="date"
          placeholder="选择开始日期"
        ></el-date-picker>
        <el-date-picker
          class="marginR"
          size="small"
          v-model="query.endTime"
          type="date"
          placeholder="选择截至日期"
        ></el-date-picker>
        <el-button class="marginR" size="small" type="primary" @click="search">查询</el-button>
        <el-button class="create-btn"  type="primary" size="small" @click="downloadSelection" >导出</el-button>
      </div>
      <el-table :data="tableData" class-name="table" ref="multipleTable" header-cell-class-name="table-header">
        <!-- <el-table-column prop="activityId" label="ID" width="55" align="center"></el-table-column> -->
        <el-table-column prop="creatTime" align="center" label="创建日期"></el-table-column>
        <el-table-column prop="activityName" align="center" label="活动名称"></el-table-column>
        <el-table-column prop="peopleNum" align="center" label="参与人数"></el-table-column>
        <el-table-column prop="peopleCount" align="center" label="参与次数"></el-table-column>
        <el-table-column prop="shareNum" align="center" label="分享人数"></el-table-column>

        <el-table-column prop="shareCount" align="center" label="分享次数"></el-table-column>
        <!-- <el-table-column label="操作" width="200" align="center">
          <template slot-scope="scope">
            <el-button type="text" icon="el-icon-view" @click="lookDetail(scope.row)">查看中奖记录</el-button>
          </template>
        </el-table-column> -->
      </el-table>
      <div class="pagination">
        <el-pagination
          background
          :hide-on-single-page="true"
          layout="total, prev, pager, next,jumper"
          :current-page="query.pageSize"
          :page-size="query.limite"
          :total="total"
          @current-change="handlePageChange"
        ></el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import {judgePath} from '@/utils/utils'
import { getData } from 'api/data.js';
export default {
  components:{
  },
  data() {
    return {
      selList: [
        {
          label: '转盘抽奖',
          key: '1',
          activityType: '1',
          value: '转盘抽奖'
        },
        {
          label: '春节抽奖',
          key: '2',
          value: '2',
          activityType: '2'
        }
      ],
      query: {
        activityName: '',
        pageSize: 1,
        limite: 10,
        endTime:'',
        beginTime:''
      },
      tableData: [],
      total: 0,
    };
  },
  created() {
    this.getData();
  },
  methods: {
    downloadSelection(){
      const {activityName,endTime,beginTime} = this.query;
      let a = document.createElement("a");
      a.href =`${judgePath()}/manager/api/data/excelExport/TypeOne?activityName=${activityName}&beginTime=${beginTime}&endTime=${endTime}`;
      document.body.appendChild(a);
      a.click();  //下载
      URL.revokeObjectURL(a.href);    // 释放URL 对象
      document.body.removeChild(a);   // 删除 a 标签
    },
    getData() {
      getData(this.query).then(res => {
        if(res.flag){
          this.tableData = res.data.data;
          this.total = res.data.total || 0;
        }else{
          this.$message({
            type: 'error',
            message: `${res.message}`
          });
        }
      });
    },
    // changeActivityType(e) {
    //   this.$set(this.query, 'activityType', e.activityType);

    // },
    search(){
      this.$set(this.query, 'pageSize', 1);
      this.getData();
    },
    // 分页导航
    handlePageChange(val) {
      this.$set(this.query, 'pageSize', val);
      this.getData();
    },
    //查看详情
    lookDetail(row){
      this.$router.push({path:"record",query:{id:row.activityId}})
    }
  }
};
</script>

<style lang="less" scoped="scoped">
.crumbs {
  margin: 10px 0;
}
.container {
  padding: 30px;
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 5px;
  .handle-box {
    margin-bottom: 20px;
  }
  .create-btn {
    float: right;
    padding: 10px 15px;
    line-height: 1;
    font-size: 12px;
    border-radius: 3px;
    color: #FFF;
    background-color: #409EFF;
    border-color: #409EFF;
  }
  .marginR{
    margin-right: 15px;
  }
  .input0617 {
    width: 225px;
  }
}
.table {
      width: 100%;
      font-size: 14px;
      text-align: center;
  }
  .el-table th{
    text-align: center;
    background-color: #EBEEF5;
  }
.pagination{
  margin: 20px 0;
  text-align: center;
}
</style>
