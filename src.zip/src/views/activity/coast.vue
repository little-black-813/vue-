<template>
  <div class="activity-wrapper">
    <div class="crumbs"><span>抽奖话费券管理</span></div>
    <div class="container">
      <div class="handle-box">
        <label for="activityName" class="marginR">活动名称:</label>
        <el-input id="activityName" class="input0617 marginR" v-model="query.activityName" size="small" placeholder="请输入活动名称内容"></el-input>
        <label for="prizeStatus" class="marginR">奖品状态:</label>
        <el-select class="marginR" v-model="query.prizeStatus" size="small" placeholder="奖品状态" value-key="label" >
          <el-option v-for="item in selList" :key="item.prizeStatus" :label="item.label" :value="item.prizeStatus"></el-option>
        </el-select>
        <el-button class="marginR" size="small" type="primary" @click="search">查询</el-button>
        <el-button class="marginR" size="small" type="danger" @click="batchStatus">批量操作</el-button>
      </div>
      <el-table :data="tableData" class-name="table" ref="multipleTable" header-cell-class-name="table-header">
        <el-table-column :selectable="checkSelectable" type="selection" width="55" align="center"></el-table-column>
        <!-- <el-table-column prop="activityId" label="ID" width="55" align="center"></el-table-column> -->
        <el-table-column prop="activityName" align="center" label="活动名称"></el-table-column>
        <el-table-column prop="userPhone" align="center" label="手机号"></el-table-column>
        <el-table-column prop="prizeName" align="center" label="奖品名称"></el-table-column>
        <el-table-column prop="prizeStatus" align="center" label="奖品状态">
          <template slot-scope="scope">
            <el-tag :type="statusList[scope.row.prizeStatus]" disable-transitions>{{statusType[scope.row.prizeStatus]}}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200" align="center">
          <template slot-scope="scope">
            <el-button v-if="scope.row.prizeStatus==='2'" type="text" icon="el-icon-edit" @click="handleEdit(scope.row)">处理</el-button>
            <el-button v-else type="text" disabled>{{statusType[scope.row.prizeStatus]}}</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination">
        <el-pagination
          background
          :hide-on-single-page="true"
          layout="total, prev, pager, next,jumper"
          :current-page="query.pageSize"
          :page-size="query.limite"
          :total="total"
          @current-change="handlePageChange"
        ></el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import bus from 'components/common/bus';
import { getCoastData, modifyStatus } from 'api/coast.js';
export default {
  data() {
    return {
      statusType:['未领取','已处理','待处理'],
      statusList:['primary','success','danger'],
      selList:[{
        label:'全部',
        prizeStatus:''
      },{
        label:'未领取',
        prizeStatus:'0'
      },
      {
        label:'已处理',
        prizeStatus:'1'
      },
      {
        label:'待处理',
        prizeStatus:'2'
      }
      ],
      query: {
        activityName: '',
        prizeStatus:'',
        pageSize: 1,
        limite: 7
      },
      tableData: [],
      total: 0,
    };
  },
  created() {
    this.getData();
  },
  methods: {
    search(){
      this.$set(this.query,'pageSize',1);
      console.log(this.query)
      this.getData();
    },
    getData() {
      // this.$store.dispatch('setLoading',true);
      getCoastData(this.query).then(res => {
        if (res.flag) {
          this.tableData = res.data.data;
          this.total = res.data.total || 0;
        }
      });
    },
    updateStatus(ids) {
      console.log('in00')
      modifyStatus({ ids }).then(res => {
        this.$message({
          type: 'info',
          message:`${res.mess}`
        });
        if (res.code == 200) {
          this.getData();
        }
      });
    },
    checkSelectable(row,index){
      if(row.prizeStatus==='1' || row.prizeStatus==='0') {return false};
      return true;
    },
    // 分页导航
    handlePageChange(val) {
      this.$set(this.query, 'pageSize', val);
      this.getData();
    },
    handleEdit(row, t) {
      this.$confirm(`确定要处理【${row.userPhone}】用户这条话费记录吗？`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then((action) => {
        console.log(action)
        let ids = [row.recordId].join(',');
          this.updateStatus(ids);
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消处理'
          });
        });
    },
    batchStatus(){
      let selArr = this.$refs.multipleTable.selection;
      let ids = selArr.map((item,ind)=>item.recordId)
      this.updateStatus(ids.join(','));
    },
  }
};
</script>

<style lang="less" scoped="scoped">
.crumbs {
  margin: 10px 0;
}
.container {
  padding: 30px;
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 5px;
  .handle-box {
    margin-bottom: 20px;
    label {
      font-size: 12px;
    }
  }
  .marginR {
    margin-right: 15px;
  }
  .input0617 {
    width: 225px;
  }
}
.table {
  width: 100%;
  font-size: 14px;
  text-align: center;
}
.el-table th {
  text-align: center;
  background-color: #ebeef5;
}
.pagination {
  margin: 20px 0;
  text-align: center;
}
</style>
