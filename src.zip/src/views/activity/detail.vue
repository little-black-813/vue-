<template>
  <div class="detail-wrapper">
    <el-breadcrumb separator="/">
      <el-breadcrumb-item :to="{ path: '/' }">抽奖活动管理</el-breadcrumb-item>
      <el-breadcrumb-item>活动详情</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="detail-cont">
      <h1 class="main-title">{{ activityInfoAll.activityName }}抽奖活动</h1>
      <el-row class="card-user-info">
        <el-col :span="12">
          <span>状态：</span>
          <i>{{ activityInfoAll.activityState = '0' ? '生效' : '失效' }}</i>
        </el-col>
        <el-col :span="12">
          <span>创建时间：</span>
          <i>{{ activityInfoAll.createTime }}</i>
        </el-col>
        <el-col :span="12">
          <span>开始时间：</span>
          <i>{{ activityInfoAll.activityStartTime }}</i>
        </el-col>
        <el-col :span="12">
          <span>截止时间：</span>
          <i>{{ activityInfoAll.activityEndTime }}</i>
        </el-col>
      </el-row>
      <!-- <div class="el-card-outbox">
        <el-card class="card-el-card">
          <el-progress type="circle" :percentage="50"></el-progress>
          <div>
            <p class="font12">抽奖人次/人数</p>
            <p>
              <span class="font32">{{ AcountlotteryTime }}</span>
              / {{ AcountlotteryNum }}
            </p>
          </div>
        </el-card>
        <el-card class="card-el-card">
          <el-progress type="circle" :percentage="50"></el-progress>
          <div>
            <p class="font12">分享次数</p>
            <p class="font32">{{ AcountshareNum }}</p>
          </div>
        </el-card>
        <el-card class="card-el-card">
          <el-progress type="circle" :percentage="50"></el-progress>
          <div>
            <p class="font12">中奖人次</p>
            <p class="font32">{{ AcountwinningTime }}</p>
          </div>
        </el-card>
      </div> -->
    </div>
    <record/>
    <div class="card-style-border">
      <h2 class="font16">抽奖情况</h2>
      <el-button class="create-btn"  type="primary" size="small" @click="excleLottery" >导出</el-button>
      <el-table :data="lotterDetailData.list" style="width: 100%">
        <el-table-column label="序号" type="index" width="90px"></el-table-column>
        <el-table-column v-for="(items, indexs) in lotterDetailLabel" :key="indexs" :prop="items.prop" :label="items.lable"></el-table-column>
      </el-table>
      <div class="page-wrapper">
        <el-pagination
          class="current-page"
          layout="prev, pager, next, total,jumper"
          :total="lotterDetailData.total"
          @current-change="queryLotteryS"
          :current-page.sync="queryLottery.pageSize"
          :page-size="queryLottery.limite"
          background
        >
        </el-pagination>
      </div>
    </div>
    <div style="height: 40px;"></div>
  </div>
</template>
<script>
import Record from '@/components/activity/detail/record.vue'
import {judgePath} from '@/utils/utils'
import {getDetailReq,getRecordsReq,getLotteryReq} from 'api/detail'

export default {
  components:{Record},
  data() {
    return {
      activityInfoAll: {
        activityId: 'XXX',
        activityName: 'XXX',
        activityType: 'XXX',
        activityState: 'XXX',
        activityStartTime: 'XXX',
        activityEndTime: 'XXX',
        creatTime: 'XXX',
        createName: 'XXX'
      },
      AcountlotteryTime: '0',
      AcountlotteryNum: '0',
      AcountshareNum: '0',
      AcountwinningTime: '0',
      queryAll:{
        pageSize:1,
        limite:100000000
      },
      lotterDetailData:{
        list:[],
        total:0,
      },
      lotterDetailLabel: [
        {
          lable: "手机号",
          type: "normal",
          prop: "userMobile"
        },
        {
          lable: "累计抽奖次数",
          type: "normal",
          prop: "peopleCount"
        },
        {
          lable: "分享次数",
          type: "normal",
          prop: "shareNum"
        },
        {
          lable: "领奖成功次数",
          type: "normal",
          prop: "peopleWinCount"
        }
      ],
      queryLottery:{
        pageSize:1,
        limite:10
      },
    };
  },
  created() {
    this.initData();
  },
  methods: {
    excleLottery(){
      const {id} = this.$route.query;
      let a = document.createElement("a");
      a.href =`${judgePath()}/manager/api/data/excelExport/TypeThread?activityId=`+id;
      document.body.appendChild(a);
      a.click();  //下载
      URL.revokeObjectURL(a.href);    // 释放URL 对象
      document.body.removeChild(a);   // 删除 a 标签
    },
    downloadSelection() {
      const {id} = this.$route.query;
      let a = document.createElement("a");
      a.href =`${judgePath()}/manager/api/data/excelExport/TypeTwo?activityId=`+id;
      document.body.appendChild(a);
      a.click();  //下载
      URL.revokeObjectURL(a.href);    // 释放URL 对象
      document.body.removeChild(a);   // 删除 a 标签
    },

    queryLotteryS(val){
      const {id} = this.$route.query;
      this.$set(this.queryLottery, 'pageSize', val);
      this.getLottery(id);
    },
    async initData(){
      const {id} = this.$route.query;
      await this.getDetail(id);
      // await this.getRecord(id);
      await this.getLottery(id);
    },
    getDetail(id){
      getDetailReq({activityId:id}).then(res=>{
        if(res.flag){
          this.activityInfoAll = {...res.data};
        }else{
          this.$message({
            type: 'error',
            message: `${res.message}`
          });
        }
      }).catch(err=>{
        console.log(err)
      })
    },
    getLottery(id){
      getLotteryReq({activityId:id,...this.queryLottery}).then(res=>{
        if(res.flag){
          this.lotterDetailData = {
            list:res.data.data,
            total:res.data.total
          }
        }else{
          this.$message({
            type: 'error',
            message: `${res.message}`
          });
        }
      }).catch(err=>{
        console.log(err)
      })
    },
  }
};
</script>

<style lang="less" scoped="scoped">
.el-breadcrumb {
  font-size: 16px;
  margin: 10px 0;
}
.create-btn {
    float: right;
    padding: 10px 15px;
    line-height: 1;
    font-size: 12px;
    border-radius: 3px;
    color: #FFF;
    background-color: #409EFF;
    border-color: #409EFF;
  }
.detail-cont {
  background-color: #ffffff;
  .main-title {
    padding: 20px;
    font-size: 20px;
    color: #333;
    text-align: left;
    margin-top: 10px;
  }
  .card-user-info {
    padding: 20px;
    line-height: 25px;
    margin-bottom: 15px;
  }
  .card-user-info span {
    font-size: 14px;
    color: #666;
  }
  .card-user-info i {
    font-size: 14px;
    color: #999;
  }
  .el-card-outbox {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .el-card-outbox {
    width: inherit;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #f0f0f0;
    padding: 20px;
  }
  .card-el-card {
    width: 30%;
    background: #fff;
    box-sizing: border-box;
    font-size: 16px;
    color: #666;
    text-align: center;
  }

  .card-el-card p {
    padding-bottom: 10px;
    width: 100%;
  }
  .font12 {
    margin-top: 10px;
    font-size: 12px;
  }
  .font32 {
    font-size: 16px;
  }
}
.card-style-border {
  border: 1px dashed #666;
  padding: 20px 30px;
  background-color: #ffffff;
  margin-bottom: 15px;
  .font16 {
    font-size: 16px;
    color: #333;
    font-weight: normal;
  }
  .fr{
    float: right;
  }
  .page-wrapper{
    margin: 20px auto;
    padding: 10px 0;
    text-align: center;
  }
}
</style>
