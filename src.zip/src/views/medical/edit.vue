<template>
  <div class="add-activity-wrapper">
    <el-breadcrumb separator="/">
      <el-breadcrumb-item :to="{ path: '/medical/index' }">套餐体检站</el-breadcrumb-item>
      <el-breadcrumb-item>编辑活动</el-breadcrumb-item>
    </el-breadcrumb>
    <section class="step-warpper">
      <el-steps :active="active" align-center>
        <el-step>
          <i class="icon-txt" @click="checkStep(1)" slot="icon">基础信息</i>
        </el-step>
         <el-step>
          <i class="icon-txt" @click="checkStep(2)" slot="icon">分享设置</i>
        </el-step>
         <el-step>
          <i class="icon-txt" @click="checkStep(3)" slot="icon">热销业务</i>
        </el-step>
        <el-step>
          <i class="icon-txt" @click="checkStep(4)" slot="icon">套餐设置</i>
        </el-step>
      </el-steps>
      <div class="step-con">
        <v-baseform v-if="active===1" type="edit"></v-baseform>
        <v-shareform v-if="active===2" type="edit"></v-shareform>
        <v-prize v-if="active===3" type="edit"></v-prize>
        <v-combosetform v-if="active === 4" type="edit"></v-combosetform>
      </div>
    </section>
  </div>
</template>

<script>
  import bus from 'components/common/bus';
  import vBaseform from 'components/medical/base'
  import vPrize from 'components/medical/prize'
  import vShareform from 'components/medical/share'
  import vCombosetform from "components/medical/comboset";
  import { getmedicalActivityDataByid } from "api/medical/dyActivity.js";
  export default{
    components:{
      vBaseform,
      vPrize,
      vShareform,
      vCombosetform
    },
    data(){
      return {
        active:0
      }
    },
    created() {
      this.getDetail()
      bus.$on('medicalOp',flag=>{
        console.log('medicalOp',flag)
        if( flag === 'add'){//下一步，上一步
          this.next();
        }else{
          this.prev();
        }
      })
    },
    beforeDestroy() {
      bus.$off('medicalOp');
    },
    methods:{
      getDetail(){
      const {id} = this.$route.query;
      let that = this;
       getmedicalActivityDataByid({activityId:id}).then (res=>{
          that.active = 1;
         that.$store.dispatch('medical/setEditbaseInfo', { activityInfo: {...res.data}});
      })
      },
      next(){
        debugger
        if (this.active++ > 4) this.active = 0;
      },
      prev(){
        if(this.active--<=0) this.active = 0;
      },
      checkStep(step){
      // console.log(step)
      this.active = step;
    }
    }
  }
</script>

<style scoped="scoped" lang="less">
  .el-breadcrumb{
    font-size: 16px;
    margin: 10px 0;
  }
  .step-warpper{
    background-color: #FFFFFF;
    padding: 20px 0;
    .step-con{
      margin-top: 30px;
    }
  }
  .icon-txt {
  font-style: normal;
  width: 80px;
  height: 80px;
  line-height: 80px;
  cursor: pointer;
}
  ::v-deep {
    .el-step__icon{
      width: 70px;
      height: 70px;

    }
    .el-step.is-center .el-step__line{
      top: 50%;
      transform: translateY(-50%);
    }
  }

</style>
