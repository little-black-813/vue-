<template>
  <div class="activity-wrapper">
    <div class="crumbs"><span>权益查询</span></div>
    <div class="container">
      <div class="handle-box">
        <!-- <el-select v-model="query.activityType" size="small" placeholder="活动类型" value-key="label" @change="changeActivityType">
           <el-option v-for="item in selList" :key="item.activityType" :label="item.label" :value="item"></el-option>
         </el-select>-->
        <el-button class="create-btn"  type="primary" size="small" @click="createActivity"  v-if="false">创建活动</el-button>
      </div>
      <el-table :data="tableData" class-name="table" ref="multipleTable" header-cell-class-name="table-header" @selection-change="handleSelectionChange">
        <!-- <el-table-column type="selection" width="55" align="center"></el-table-column> -->
        <!-- <el-table-column prop="activityId" label="ID" width="55" align="center"></el-table-column> -->
        <el-table-column prop="activityName" align="center" label="活动名称"></el-table-column>
        <!-- <el-table-column prop="activityType" align="center" label="活动类型"></el-table-column> -->
        <el-table-column prop="activityStartTime" align="center" label="开始日期"></el-table-column>
        <el-table-column prop="activityEndTime" align="center" label="结束日期"></el-table-column>
        <el-table-column prop="createTime" align="center" label="创建日期"></el-table-column>
         <el-table-column prop="participateTotal" align="center" label="总参与人数"></el-table-column>
        <!-- <el-table-column prop="createName" align="center" label="创建人"></el-table-column> -->
        <el-table-column label="操作" width="200" align="center">
          <template slot-scope="scope">
            <el-button type="text" icon="el-icon-edit" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button type="text" icon="el-icon-view" @click="interestRecord(scope.row)">查询记录</el-button>
            <el-button type="text" icon="el-icon-paperclip" class="red" @click="getLink(scope.row)">获取链接</el-button>
            <el-button type="text" icon="el-icon-delete" class="red" @click="handleDelete(scope.row,scope.$index)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination">
        <el-pagination
          background
          :hide-on-single-page="true"
          layout="total, prev, pager, next"
          :current-page="query.pageSize"
          :page-size="query.limite"
          :total="total"
          @current-change="handlePageChange"
        ></el-pagination>
      </div>
    </div>
    <v-deldialog v-if="delVisiable" :show="delVisiable" :name="multipleSelection[0].activityName" :id="multipleSelection[0].activityId"  url="/data/activityManager/updateActivityState"></v-deldialog>
    <v-linkdialog v-if="linkVisiable"  :show="linkVisiable" :activityId="multipleSelection[0].activityId" activityType="interestActivity"></v-linkdialog>
  </div>
</template>

<script>
  import bus from 'components/common/bus';
  import vLinkdialog from 'components/dialog/LinkDialog';
  import vDeldialog from 'components/dialog/delDialogmedical';
  import { getInterestActivityData } from 'api/interest/interestActivity.js';
  export default {
    components:{
      vDeldialog,
      vLinkdialog
    },
    data() {
      return {
        query: {
          /* activityType: '',*/
          pageSize: 1,
          limite: 10,
          activityType:'interestActivity'
        },
        tableData: [],
        total: 0,
        multipleSelection: [],
        delVisiable:false,
        selInd:'',//选择table的下标,
        linkVisiable:false
      };
    },
    created() {
      bus.$on('closeDel',params=>{
        // debugger
        this.linkVisiable = params.show;
        this.delVisiable = params.show;
        this.multipleSelection = [];
        this.selInd = '';
        params.reqFlag && this.getData();
      })
      this.getData();
    },
    beforeDestroy(){
      bus.$off('closeDel')
    },
    methods: {
      createActivity(){//创建活动
        this.$store.dispatch('interest/setActivityBaseInfo', { activityInfo: {} });
        this.$store.dispatch('interest/setActivityBaseInfo', { prizeList: [] });
        this.$store.dispatch('interest/setActivityId', '');
        this.$router.push('/interest/add');
      },
      getData() {
        getInterestActivityData(this.query).then(res => {
          if(res.flag){
            res.data.list = res.data;
            this.tableData = res.data.data;
            this.total = res.data.total || 0;
          }

        });
      },
      changeActivityType(e) {
        this.$set(this.query, 'activityType', e.activityType);
        this.getData();
      },
      // 多选操作
      handleSelectionChange(val) {
        this.multipleSelection = val;
      },
      // 分页导航
      handlePageChange(val) {
        this.$set(this.query, 'pageSize', val);
        this.getData();
      },
      handleDelete(row,ind){
        // debugger
        this.delVisiable = true;
        this.multipleSelection = [row];
      },
      handleEdit(row){
        this.$router.push({path:"edit",query:{id:row.activityId}});
      },
      getLink(row){
        this.linkVisiable = true;
        this.multipleSelection = [row];
      },
      interestRecord(row){
        this.$router.push({path:"detail",query:{id:row.activityId}});
      }
    }
  };
</script>

<style lang="less" scoped="scoped">
  .crumbs {
    margin: 10px 0;
  }
  .container {
    padding: 30px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    .handle-box {
      margin-bottom: 20px;
    }
    .create-btn {
      float: right;
    }
  }
  .table {
    width: 100%;
    font-size: 14px;
    text-align: center;
  }
  .el-table th{
    text-align: center;
    background-color: #EBEEF5;
  }
  .pagination{
    margin: 20px 0;
    text-align: center;
  }
</style>
