<template>
  <div class="card-wrapper">
    <div class="crumbs">家庭流量优惠-卡券有效期</div>
    <section class="container">
      <el-form ref="creatForm" :model="creatForm" :rules="rules" label-width="140px" class="creat-act-form">
        <el-form-item label="活动名称：" prop="activityName">
          <el-col :span="18"><el-input v-model.trim="creatForm.activityName"></el-input></el-col>
          </el-form-item>
        <el-form-item label="优惠开始时间" required>
          <el-col :span="18">
            <el-form-item prop="startTime">
              <el-date-picker type="datetime" placeholder="选择开始日期" @change="changeTime1" v-model="creatForm.startTime" style="width: 100%;"></el-date-picker>
            </el-form-item>
          </el-col>
        </el-form-item>
        <el-form-item label="优惠结束时间" required>
          <el-col :span="18">
            <el-form-item prop="endTime">
              <el-date-picker type="datetime" placeholder="选择截至日期" @change="changeTime2" v-model="creatForm.endTime" style="width: 100%;"></el-date-picker>
            </el-form-item>
          </el-col>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm('creatForm')">立即提交</el-button>
          <!--<el-button @click="resetForm('creatForm')">{{creatForm.activityType}}重置</el-button>-->
        </el-form-item>
        </el-form>
    </section>
  </div>
</template>

<script>
import {formatDate} from '@/utils/utils'
import {getCardData,createTimeReq} from '@/api/liuliang/card.js'
export default{
  data(){
    return{
      creatForm:{
        activityName:'',
        startTime:'',
        endTime:'',
        id:0
      },
      rules: {
        activityName: [{ type: 'string', required: true, message: '请选择活动开始时间', trigger: 'blur' }],
          startTime: [{ type: 'string', required: true, message: '请选择活动开始时间', trigger: 'change' }],
          endTime: [{ type: 'string', required: true, message: '请选择活动结束时间', trigger: 'change' }],
        }
      };
  },
  created() {
    getCardData().then(res=>{
      console.log(res)
      if(res.flag){
        this.creatForm = res.data[0];
      }
    })
  },
  methods:{
    changeTime1(val){
        this.$set(this.creatForm,'startTime',formatDate(val,'yyyy-MM-dd HH:mm:ss'));
    },
    changeTime2(val){
        this.$set(this.creatForm,'endTime',formatDate(val,'yyyy-MM-dd HH:mm:ss'));
    },
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        console.log( this.creatForm)
        if (valid) {
          //存储vuex，上一步时，可以会显
          this.createActivity({reqUrl:'/campaign/setCampaign',creatForm:{...this.creatForm}});
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
	createActivity(params){
		createTimeReq(params).then(res=>{
      if(res.flag){
        this.$message({
          message: `${res.message}`,
          type: 'success'
        });
      }else{
        this.$message({
          message: `${res.message}`,
          type: 'error'
        });
      }
			console.log(res)
		})
	}
  }
}
</script>

<style lang="less" scoped="scoped">
.card-wrapper{
  .crumbs {
    margin: 10px 0;
  }
  .container{
    padding: 30px;
    min-height: 500px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;

  }
  .creat-act-form {
    width: 60%;
  }
}
</style>
