// 生产
module.exports = {
  title: '活动管理系统',
  baseApi: 'http://wx.10086.cn/jiangxinew/chinamobile/hollycrm',// 本地api请求地址,注意：如果你使用了代理，请设置成'/'
  baseApiAli:'https://wx.online-cmcc.cn/jiangxinew/chinamobile/hollycrm',
  baseWechatUrl:'https://wechat.jxydzx.cn/chinamobile/hollycrm',
  baseUploadUrl:'https://wechat.jxydzx.cn/chinamobile/hollycrm/testLottery/api',
  baseImgPath:'',
  lotteryApi:'/lottery/api',
  dyApi:'/dy/api'


}
//https://wechat.jxydzx.cn/chinamobile/hollycrm http://wx.10086.cn/jiangxinew/chinamobile/hollycrm/api/weChatAuthorize/getUserInfor
