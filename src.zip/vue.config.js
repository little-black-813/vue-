const path = require('path')
const defaultSettings = require('./src/config/index.js')
const IS_PROD = ['production', 'prod'].includes(process.env.NODE_ENV);
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin
function resolve(dir) {
  return path.join(__dirname, dir)
}
const name = defaultSettings.title || '活动配置管理';

module.exports = {
  outputDir: 'lottery-admin-manager',
  publicPath: './',
  assetsDir: 'static',
  productionSourceMap: false,
  lintOnSave: false,
  devServer: {
    proxy: {
      '/data': {
         target: 'http:localhost:7109',
       // target: 'http://wx.10086.cn/jiangxinew/chinamobile/hollycrm',
        changeOrigin: true,
      },
      '/dy': {
        target: 'http://wx.10086.cn/jiangxinew/chinamobile/hollycrm',
        changeOrigin: true,
        pathRewrite:{
          '^/dy':'/'
        }
      },
      '/api': {
          target: 'http://wx.10086.cn/jiangxinew/chinamobile/hollycrm',
          changeOrigin: true,
      },
      '/notice': {
          target: 'http://192.168.1.10:7106/',
          changeOrigin: true,
      },
      '/campaign': {
          target: 'http://192.168.1.10:7106/',
          changeOrigin: true,
      },
    }

  },
  /* css: {
    extract: true, // 是否使用css分离插件 ExtractTextPlugin
    sourceMap: false, // 开启 CSS source maps
    loaderOptions: {

    },
    requireModuleExtension: false // 启用 CSS modules for all css / pre-processor files.
  }, */
  chainWebpack: config => {
    config
      .plugin('html')
      .tap(args => {
        args[0].title = name;
        return args;
      })
      .end()
      .resolve.alias
      .set('@', resolve('src'))
      .set('components', resolve('src/components'))
      .set('@assets', resolve('src/assets'))
      .set('api', resolve('src/api'))
      .end()
    /**
     * 打包分析
     */
    if (IS_PROD) {
      config.plugin('webpack-report').use(BundleAnalyzerPlugin, [{
        analyzerMode: 'static'
      }])
    }
    config
      // https://webpack.js.org/configuration/devtool/#development
      .when(!IS_PROD, config => config.devtool('cheap-source-map'))
      .end()
    config.optimization.splitChunks({
      chunks: 'all',
      cacheGroups: {
        // cacheGroups 下可以可以配置多个组，每个组根据test设置条件，符合test条件的模块
        commons: {
          name: 'chunk-commons',
          test: resolve('src/components'),
          minChunks: 3, //  被至少用三次以上打包分离
          priority: 5, // 优先级
          reuseExistingChunk: true // 表示是否使用已有的 chunk，如果为 true 则表示如果当前的 chunk 包含的模块已经被抽取出去了，那么将不会重新生成新的。
        },
        node_vendors: {
          name: 'chunk-libs',
          chunks: 'initial', // 只打包初始时依赖的第三方
          test: /[\\/]node_modules[\\/]/,
          priority: 10
        },
        elementUI: {
          name: 'chunk-elementUI', // 单独将 elementUI 拆包
          priority: 20, // 数字大权重到，满足多个 cacheGroups 的条件时候分到权重高的
          test: /[\\/]node_modules[\\/]_?element-ui(.*)/
        }
      }
    })
    config.optimization.runtimeChunk('single')
  },
}
