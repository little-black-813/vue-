<template>
  <div class="activity-wrapper">
    <div class="crumbs"><span>任务管理</span></div>
    <div class="container">
      <div class="handle-box">
        <el-button class="create-btn"  type="primary" size="small" @click="closeFrom()">新增任务</el-button>
      </div>
      <el-table :data="tableData" class-name="table" ref="multipleTable" header-cell-class-name="table-header">
        <el-table-column label="序号" width="50" align="center">
          <template scope="scope">
            <span>{{(query.currentPage - 1) * query.pageSize + scope.$index + 1}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="taskType" align="center" label="任务类型"></el-table-column>
        <el-table-column prop="taskName" align="center" label="任务名称"></el-table-column>
         <el-table-column prop="icon" align="center" label="icon">
          <template slot-scope="scope">
              <!-- :preview-src-list="[scope.row.imageId]"可点击查看大图 -->
            <el-image class="table-td-thumb" :src="scope.row.icon" ></el-image>
          </template>
         </el-table-column>
        <el-table-column prop="taskRemark" align="center" label="任务摘要"></el-table-column>
        <el-table-column prop="foodAmount" align="center" label="获得食物"></el-table-column>
        <el-table-column prop="createTime" align="center" label="创建时间"></el-table-column>
        <el-table-column label="操作" width="200" align="center">
          <template slot-scope="scope">
            <el-button type="text" icon="el-icon-edit" @click="dialogFormVisible = true;form=scope.row;title='编辑任务'">编辑</el-button>
            <el-dialog :title="title" :visible.sync="dialogFormVisible">
              <el-form :model="form">
                <el-form-item label="任务名称">
                  <el-input v-model="form.taskName"  autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="任务摘要">
                  <el-input v-model="form.taskRemark"  autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="获得食物">
                  <el-input v-model="form.foodAmount"  autocomplete="off"></el-input>
                </el-form-item>
<el-form-item  label="icon:">
  <el-upload
    class="avatar-uploader"
    action="http://localhost:8080/data/image/data/imgUpload"
    :show-file-list="false"
    :on-success="handleAvatarSuccess"
    :before-upload="beforeAvatarUpload">
    <img v-if="form.icon" :src="form.icon" class="avatar">
    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
  </el-upload>
</el-form-item>
                <el-form-item label="跳转链接">
                  <el-input v-model="form.address"  autocomplete="off"></el-input>
                </el-form-item>
              </el-form>
              <div slot="footer" class="dialog-footer">
                <el-button @click="this.dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="handleEdit(form)">确 定</el-button>
              </div>
            </el-dialog>
            <el-button type="text" icon="el-icon-delete" class="red" @click="handleDelete(scope.$index,scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
     <div class="pagination">
            <el-pagination
              background
              :hide-on-single-page="true"
              layout="total, prev, pager, next"
              :current-page="query.currentPage"
              :page-size="query.pageSize"
              :total="total"
              @current-change="handlePageChange"
            ></el-pagination>
          </div>
    </div>
  </div>
</template>

<script>
  import bus from 'components/common/bus';
  import { editOrSaveTask,deleteTask,getTask } from 'api/mc/task.js';
  export default {
   
    data() {
      return {
        query: {
          currentPage: 1,
          pageSize: 5,
          taskType: ""
        },
        tableData: [],
        total: 0,

        dialogFormVisible: false,
        title:"",
        form: {
          taskName: "",
          taskRemark: "",
          foodAmount: "",
          address:"",
          icon:""
        },
       
     options: [{
            value: '1',
            label: '普通任务'
            }, {
            value: '2',
            label: '业务办理任务'
            }, {
            value: '3',
            label: '浏览页面任务'
            }],
        };
    },
    created() {
      this.getData();
    },
    beforeDestroy(){
      bus.$off('closeDel')
    },
    methods: {
      // 对话框取消事件
      closeFrom(){
        this.dialogFormVisible = true;
        this.title='新增话费充值卡';
        this.form = {id:'',chargeCard: '',moodValue: '',number: ''};
      },
      getData() {
        getTask(this.query).then(res => {
          if(res.success){
             this.total = res.data.total
             res.data.list.forEach(element => {
                 if(element.taskType==1){
                    element.taskType ="普通任务"
                 }else if(element.taskType==2){
                    element.taskType ="业务办理任务"
                 }else{
                    element.taskType ="浏览页面任务"
                 }
            });
            this.tableData = res.data.list;
          }
        });
      },
      
      // 分页导航
      handlePageChange(val) {
        console.log(val)
        this.$set(this.query, 'currentPage', val);
        this.getData();
      },
      handleDelete(ind,row){
        this.confirmDel({id:row.id,});
      },
      resetForm(){
            this.dialogVisible = false;
          },
      async confirmDel(params){
        console.log(params)
        let that = this;
        await that.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '是',
          cancelButtonText: '否',
          type: 'warning',
          callback:actions=>{
            if(actions == 'confirm'){
              deleteTask(params).then(res=>{
                if(res.success){
                  this.getData()
                }
                this.$message({
                  type: 'info',
                  message:  `删除成功`
                });
              })
            }
          }
        })
      },
      handleEdit(form){
        this.confirmUpdate(form);
      },
      async confirmUpdate(params){
                editOrSaveTask(params).then(res=>{
                  if(res.success){
                    this.dialogFormVisible = false;
                    this.getData();
                    this.message = '操作成功';
                  }else{
                    this.message = '操作失败';
                  }
                  this.$message({
                    type: 'info',
                    message: this.message
                  });
                })
            }
      ,
     
     handleAvatarSuccess(res, file) {
        if(res.code==='200' || res.code==='0000'){
        console.log("111111111111:"+URL.createObjectURL(file.raw))
        this.form.icon = res.data.getImage
        // this.animalImageUrl = URL.createObjectURL(file.raw);
      }else{
        this.upLoading = false;
        this.$message.error('上传失败，请稍后再试')
      }
      },
      handleError(err,file,FileList){
        this.upLoading = false;
        this.$message.error('上传失败，请稍后再试')
      },
      beforeAvatarUpload(file) {
        this.upLoading = true;
        const isJPG = file.type === 'image/jpeg' || file.type === 'image/jpg' || file.type === 'image/JPG' || file.type === 'image/png' || file.type === 'image/PNG';
        return isJPG;
      }
    }
  };
</script>

<style lang="less" scoped="scoped">
  .crumbs {
    margin: 10px 0;
  }
  .container {
    padding: 30px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    .handle-box {
      margin-bottom: 20px;
    }
    .create-btn {
      float: right;
    }
  }
  .table {
    width: 100%;
    font-size: 14px;
    text-align: center;
  }
  .el-table th{
    text-align: center;
    background-color: #EBEEF5;
  }
  .pagination{
    margin: 20px 0;
    text-align: center;
  }
  
.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>
