<template>
  <div class="activityInfo-query" >
    <div>
      <quill-editor ref="myTextEditor" v-model="content" :options="editorOption" style="height:600px;"></quill-editor>
    </div>
    <el-form class="actInfo-query-form">
      <el-form-item label="活动名称：">
        <el-input v-model="searchInfo.mobile" placeholder="活动名称" ></el-input>
      </el-form-item >
      <el-date-picker
        v-model="searchInfo.value"
        type="datetime"
        placeholder="选择日期时间">
      </el-date-picker>
      <el-date-picker
        size="mini"
        v-model="searchInfo.value"
        value-format="yyyy-MM-dd HH:mm:ss"
        type="datetimerange"
        range-separator="-"
        start-placeholder="开始日期"
        end-placeholder="结束日期">
      </el-date-picker>
      <el-form-item class="actInfo-query-it3">
        <el-button type="primary" @click="bindFoodInfo()">查询</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  import { quillEditor } from 'vue-quill-editor';
  import 'quill/dist/quill.core.css';
  import 'quill/dist/quill.snow.css';
  import 'quill/dist/quill.bubble.css'

    export default {
      components: {
        quillEditor
      },
      data(){
        return{
          searchInfo: {
            mobile: '',
            source: '',
            isAdd: '',
            value: ''
          },
          content: '',
          editorOption: {
            placeholder: '编辑文章内容'
          },
        }
      },
    }
</script>

<style scoped>

</style>
