<template>
  <div class="food-activity-wrapper">
    <el-breadcrumb separator="/">
      <el-breadcrumb-item :to="{ path: '/activityInfo/index' }">活动信息查询</el-breadcrumb-item>
      <el-breadcrumb-item>用户明细</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="food-crumbs">
      <div class="food-container">
        <div class="food-handle-box">
          <el-form class="actInfo-query-form" size="mini" :inline="true">
            <el-form-item class="actInfo-query-it1">
              <el-input v-model="query.mobile" oninput="value=value.replace(/[^\d]/g,'')" maxlength="11" placeholder="用户手机号" clearable></el-input>
            </el-form-item >
            <el-form-item label="动物类型">
              <el-select v-model="query.animalType" placeholder="全部" >
                <el-option label="全部" value=""></el-option>
                <el-option label="猫" value="2"></el-option>
                <el-option label="狗" value="1"></el-option>
                <el-option label="鹦鹉" value="3"></el-option>
              </el-select>
            </el-form-item>
            <el-form-item class="actInfo-query-it3">
              <el-button type="primary" @click="searchInfo()">查询</el-button>
            </el-form-item>
            <el-form-item class="actInfo-query-it3">
              <el-button type="primary" @click="download()">导出</el-button>
            </el-form-item>
          </el-form>
        </div>
        <el-table :data="tableData" class-name="food-table" ref="multipleTable" header-cell-class-name="table-header" @selection-change="">
          <el-table-column label="序号" width="50" align="center">
            <template scope="scope">
              <span>{{(query.currentPage - 1) * query.pageSize + scope.$index + 1}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="mobile" align="center" label="用户手机号"></el-table-column>
          <el-table-column prop="name" align="center" label="动物名称"></el-table-column>
          <el-table-column prop="animalType" align="center" label="动物类型"></el-table-column>
          <el-table-column prop="foodType" align="center" label="食物类型"></el-table-column>
          <el-table-column prop="currentFoodAmount" align="center" label="当前食物量"></el-table-column>
          <el-table-column prop="currentMoodAmount" align="center" label="当前心情值"></el-table-column>
          <el-table-column label="明细信息" width="200" align="center" >
            <template slot-scope="scope">
              <el-button type="text" icon="el-icon-search" @click="handleFoodInfo(scope.row.mobile)">食物明细</el-button>
              <el-button type="text" icon="el-icon-search" @click="handleMoodInfo(scope.row.mobile)">心情明细</el-button>
            </template>
          </el-table-column>
        </el-table>
        <div class="pagination">
          <el-pagination
            background
            :hide-on-single-page="true"
            layout="total, prev, pager, next"
            :current-page="query.currentPage"
            :page-size="query.pageSize"
            :total="total"
            @current-change="handlePageChange"
          ></el-pagination>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {getAnimalInfo,downloadAnimalInfo} from '../../api/activityInfo/activityInfo.js';
  import Query from '../../components/activityInfo/query.vue';
  export default {
    components:{Query},
    data(){
      return{
        query:{
          currentPage: 1,
          pageSize: 6,
          id: '',
          mobile: '',
          name: '',
          animalType: '',
          foodType: '',
          currentFoodAmount: '',
          currentMoodAmount: '',
        },
        tableData: [],
        total: 0,
      }
    },
    created() {
      this.getData();
    },
    methods: {
      getData(){
        getAnimalInfo(this.query).then(res => {
          if(res.success){
            res.data.list.forEach(list =>{
              console.log()
              if(list.animalType==='1'){
                list.animalType='狗';
              }else if(list.animalType==='2'){
                list.animalType='猫';
              }else if(list.animalType==='3'){
                list.animalType='鹦鹉';
              }
            });
            this.tableData = res.data.list;
            this.total = res.data.total || 0
          }
        });
      },
      // 分页导航
      handlePageChange(val) {
        this.$set(this.query, 'currentPage', val);
        this.getData();
      },
      //按条件查找
      searchInfo(){
        this.getData();
      },
      //食物明细
      handleFoodInfo(mobile){
        this.$router.push({name:"foodInfo",params: {mobile: mobile}});
      },
      //心情明细
      handleMoodInfo(mobile){
        this.$router.push({name:"moodInfo",params: {mobile: mobile}});
      },
      download(){
        downloadAnimalInfo(this.query).then(res => {
          console.log(111111111);
          console.log(res);
          // 文件导出
          if (!res) {
            return
          }
          let url = window.URL.createObjectURL(new Blob([res]));
          console.log(111111111);
          console.log(url);
          let link = document.createElement('a');
          link.style.display = 'none';
          link.href = url;
          link.setAttribute('download', '用户明细信息'+'.xls');
          document.body.appendChild(link);
          link.click()
        });
      }
    },
  }
</script>

<style lang="less" scoped="scoped">
  .food-crumbs {
    margin: 10px 0;
  }
  .food-container {
    padding: 30px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    .food-handle-box {
      margin-bottom: 20px;
    }
    /*.create-btn {*/
    /*float: right;*/
    /*}*/
  }
  .food-table {
    width: 100%;
    font-size: 14px;
    text-align: center;
  }
  .el-table th{
    text-align: center;
    background-color: #EBEEF5;
  }
</style>
