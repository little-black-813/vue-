<template>
  <div class="food-activity-wrapper">
    <el-breadcrumb separator="/">
      <el-breadcrumb-item :to="{ path: '/activityInfo/index' }">活动信息查询</el-breadcrumb-item>
      <el-breadcrumb-item :to="{ path: '/activityInfo/animalInfo' }">用户明细</el-breadcrumb-item>
      <el-breadcrumb-item>心情明细</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="food-crumbs">
      <div class="food-container">
        <div class="food-handle-box">
          <Query v-on:childClick="searchInfo"/>
        </div>
        <el-table :data="tableData" class-name="food-table" ref="multipleTable" header-cell-class-name="table-header" @selection-change="">
          <el-table-column label="序号" width="50" align="center">
            <template scope="scope">
              <span>{{(query.currentPage - 1) * query.pageSize + scope.$index + 1}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="mobile" align="center" label="用户手机号"></el-table-column>
          <el-table-column prop="mood" align="center" label="心情变化量"></el-table-column>
          <el-table-column prop="isAdd" align="center" label="心情变化方向"></el-table-column>
          <el-table-column prop="createTime" align="center" label="心情变化时间"></el-table-column>
          <el-table-column prop="bz" align="center" label="心情变化原因"></el-table-column>
          <el-table-column prop="source" align="center" label="操作来源"></el-table-column>
        </el-table>
        <div class="pagination">
          <el-pagination
            background
            :hide-on-single-page="true"
            layout="total, prev, pager, next"
            :current-page="query.currentPage"
            :page-size="query.pageSize"
            :total="total"
            @current-change="handlePageChange"
          ></el-pagination>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {getMoodInfo} from '../../api/activityInfo/activityInfo.js';
  import Query from '../../components/activityInfo/query.vue';
  export default {
    components:{Query},
    data(){
      return{
        query:{
          currentPage: 1,
          pageSize: 5,
          id: '',
          mobile: '',
          mood: '',
          isAdd: '',
          createTime: '',
          bz: '',
          source: '',
          beginTime: '',
          endTime: '',
        },
        tableData: [],
        total: 0,
        mobile: this.$route.params.mobile
      }
    },
    created() {
        this.getData();
    },
    methods: {
      getData(){
        if (this.mobile != null){
          this.query.mobile=this.mobile;
        }
        getMoodInfo(this.query).then(res => {
          if(res.success){
            res.data.list.forEach(element => {
                 if(element.isAdd==0){
                    element.isAdd ="增加"
                 }else{
                    element.isAdd ="减少"
                 }
            });
            this.tableData = res.data.list;
            this.total = res.data.total || 0
          }
        });
      },
      // 分页导航
      handlePageChange(val) {
        this.$set(this.query, 'currentPage', val);
        this.getData();
      },
      //按条件查找
      searchInfo(searchInfo){
        // this.query.mobile=searchInfo.mobile;
        if(searchInfo.value !== null){
          this.query.beginTime=searchInfo.value[0];
          this.query.endTime=searchInfo.value[1];
        } else{
          this.query.beginTime="";
          this.query.endTime="";
        }
        this.query.source=searchInfo.source;
        this.query.isAdd=searchInfo.isAdd;
        this.getData();
      }
    },
  }
</script>

<style lang="less" scoped="scoped">
  .food-crumbs {
    margin: 10px 0;
  }
  .food-container {
    padding: 30px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    .food-handle-box {
      margin-bottom: 20px;
    }
    /*.create-btn {*/
    /*float: right;*/
    /*}*/
  }
  .food-table {
    width: 100%;
    font-size: 14px;
    text-align: center;
  }
  .el-table th{
    text-align: center;
    background-color: #EBEEF5;
  }
</style>
