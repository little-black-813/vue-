<template>
  <div class="food-activity-wrapper">
    <el-breadcrumb separator="/">
      <el-breadcrumb-item :to="{ path: '/activityInfo/index' }">活动信息查询</el-breadcrumb-item>
      <el-breadcrumb-item>奖品兑换明细</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="food-crumbs">
      <div class="food-container">
        <div class="food-handle-box">
          <el-form class="actInfo-query-form" size="mini" :inline="true">
            <el-form-item class="actInfo-query-it1">
              <el-input v-model="query.mobile" oninput="value=value.replace(/[^\d]/g,'')" maxlength="11" placeholder="用户手机号" clearable></el-input>
            </el-form-item >
            <el-form-item label="话费券类型">
              <el-select v-model="query.chargeCard" placeholder="全部">
                <el-option label="全部" value=""></el-option>
                <el-option
                  v-for="data in formData"
                  :label="data.chargeCard +'元话费券'"
                  :value="data.chargeCard +'元话费券'"
                ></el-option>
              </el-select>
            </el-form-item>
            <el-date-picker class="prizeInfo-date-it"
               size="mini"
               v-model="value"
               value-format="yyyy-MM-dd HH:mm:ss"
               type="datetimerange"
               range-separator="-"
               start-placeholder="开始日期"
               end-placeholder="结束日期">
            </el-date-picker>
            <el-form-item class="prizeInfo-button-it">
              <el-button type="primary" @click="searchInfo()">查询</el-button>
            </el-form-item>
          </el-form>
        </div>
        <el-table :data="tableData" class-name="food-table" ref="multipleTable" header-cell-class-name="table-header" @selection-change="">
          <el-table-column label="序号" width="50" align="center">
            <template scope="scope">
              <span>{{(query.currentPage - 1) * query.pageSize + scope.$index + 1}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="mobile" align="center" label="用户手机号"></el-table-column>
          <el-table-column prop="chargeCard" align="center" label="话费充值卡金额"></el-table-column>
          <el-table-column prop="createTime" align="center" label="兑换时间"></el-table-column>
        </el-table>
        <div class="pagination">
          <el-pagination
            background
            :hide-on-single-page="true"
            layout="total, prev, pager, next"
            :current-page="query.currentPage"
            :page-size="query.pageSize"
            :total="total"
            @current-change="handlePageChange"
          ></el-pagination>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {getPrizeInfo,getChargeCardInfo} from '../../api/activityInfo/activityInfo.js';
  import Query from '../../components/activityInfo/query.vue';
  export default {
    components:{Query},
    data(){
      return{
        query:{
          currentPage: 1,
          pageSize: 6,
          id: '',
          mobile: '',
          chargeCard: '',
          createTime: '',
          beginTime: '',
          endTime: '',
        },
        value:'',
        formData:[],
        tableData: [],
        total: 0,
      }
    },
    created() {
      this.getCharge();
      this.getData();
    },
    methods: {
      getData(){
        getPrizeInfo(this.query).then(res => {
          if(res.success){
            this.tableData = res.data.list;
            this.total = res.data.total || 0
          }
        });
      },
      // 分页导航
      handlePageChange(val) {
        this.$set(this.query, 'currentPage', val);
        this.getData();
      },
      //按条件查找
      searchInfo(){
        if(this.value !== null){
          this.query.beginTime=this.value[0];
          this.query.endTime=this.value[1];
        } else{
          this.query.beginTime="";
          this.query.endTime="";
        }
        this.getData();
      },
      //话费券卡类型明细
      getCharge(){
        getChargeCardInfo().then(res => {
          if(res.success){
            this.formData = res.data;
          }
        });
      },
     /* download(){
        downloadAnimalInfo(this.query).then(res => {
          console.log(111111111);
          console.log(res);
          // 文件导出
          if (!res) {
            return
          }
          let url = window.URL.createObjectURL(new Blob([res]));
          console.log(111111111);
          console.log(url);
          let link = document.createElement('a');
          link.style.display = 'none';
          link.href = url;
          link.setAttribute('download', '用户明细信息'+'.xls');
          document.body.appendChild(link);
          link.click()
        });
      }*/
    },
  }
</script>

<style lang="less" scoped="scoped">
  .food-crumbs {
    margin: 10px 0;
  }
  .food-container {
    padding: 30px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    .food-handle-box {
      margin-bottom: 20px;
    }
    /*.create-btn {*/
    /*float: right;*/
    /*}*/
  }
  .prizeInfo-button-it{
    margin-left: 10px;
  }
  .food-table {
    width: 100%;
    font-size: 14px;
    text-align: center;
  }
  .el-table th{
    text-align: center;
    background-color: #EBEEF5;
  }
</style>
