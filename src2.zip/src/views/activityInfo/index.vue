<template>
    <div class="activity-wrapper">
      <div class="crumbs"><span>活动信息查询</span>
        <div class="container">
          <div class="handle-box"></div>
          <el-table :data="tableData" class-name="table" ref="multipleTable" header-cell-class-name="table-header" @selection-change="">
            <el-table-column label="序号" width="50" align="center">
              <template scope="scope">
                <span>{{(query.currentPage - 1) * query.pageSize + scope.$index + 1}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="activityName" align="center" label="活动名称"></el-table-column>
            <el-table-column prop="beginTime" align="center" width="150" label="开始日期"></el-table-column>
            <el-table-column prop="endTime" align="center" width="150" label="结束日期"></el-table-column>
            <el-table-column prop="activityRule" align="center" width="150" label="活动规则">
              <template slot-scope="scope">
                <div v-html="scope.row.activityRule"></div>
              </template>
            </el-table-column>
            <el-table-column prop="amount" align="center" label="参与人数" >
              <template slot-scope="scope">
                <el-button type="text" @click="handleAnimalInfo()">{{scope.row.amount}}</el-button>
              </template>
            </el-table-column>
            <el-table-column label="明细信息" align="center" >
              <template slot-scope="scope">
                <el-button type="text" icon="el-icon-search" @click="handlePrizeInfo()">奖品明细</el-button>
              </template>
            </el-table-column>
            <el-table-column label="操作" align="center" >
              <template slot-scope="scope">
                <!--<el-button type="text" icon="el-icon-edit" @click="handleEdit(scope.row)">编辑</el-button>-->
                <el-button type="text" icon="el-icon-edit" @click="popup(scope.row)">编辑</el-button>

                <el-dialog title="编辑活动信息" :visible.sync="dialogFormVisible">
                  <el-form :model="form">
                    <el-form-item label="活动名称："> <!--:label-width="formLabelWidth"-->
                      <el-input class="el-input-activityInfo" v-model="form.activityName" autocomplete="off"></el-input>
                    </el-form-item>
                    <el-form-item label="开始时间："> <!--:label-width="formLabelWidth"-->
                      <el-date-picker class="el-date-picker-activityInfo1"
                        v-model="form.beginTime"
                        value-format="yyyy-MM-dd HH:mm:ss"
                        type="datetime"
                        placeholder="选择日期时间">
                      </el-date-picker>
                    </el-form-item>
                    <el-form-item label="结束时间：" > <!--:label-width="formLabelWidth"-->
                      <el-date-picker class="el-date-picker-activityInfo2"
                        v-model="form.endTime"
                        value-format="yyyy-MM-dd HH:mm:ss"
                        type="datetime"
                        placeholder="选择日期时间">
                      </el-date-picker>
                    </el-form-item>
                    <el-form-item label="活动规则：" > <!--:label-width="formLabelWidth"-->
                        <quill-editor class="quill-editor" ref="myTextEditor" v-model="form.activityRule" style="height:100px;"></quill-editor>
                    </el-form-item>
                  </el-form>
                  <div slot="footer" class="dialog-footer">
                    <el-button @click="dialogFormVisible = false">取 消</el-button>
                    <el-button type="primary" @click="handleEdit(form)">确 定</el-button>
                  </div>
                </el-dialog>
              </template>
            </el-table-column>
          </el-table>
          <div class="pagination">
            <el-pagination
              background
              :hide-on-single-page="true"
              layout="total, prev, pager, next"
              :current-page="query.currentPage"
              :page-size="query.pageSize"
              :total="total"
              @current-change="handlePageChange"
            ></el-pagination>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
  import {getActivityInfo,editActivityInfo} from '../../api/activityInfo/activityInfo.js';
  import { quillEditor } from 'vue-quill-editor';
  import 'quill/dist/quill.core.css';
  import 'quill/dist/quill.snow.css';
  import 'quill/dist/quill.bubble.css'

    export default {
      components: {
        quillEditor
      },
      data(){
        return{
          query:{
            currentPage: 1,
            pageSize: 5,
            id: '',
            activityName: '',
            beginTime: '',
            endTime: '',
            activityRule: '',
            amount: ''
          },
          tableData: [],
          total: 0,
          dialogFormVisible: false,
          form: {
            id:'',
            activityName: '',
            beginTime: '',
            endTime: '',
            activityRule: '',
          },
        }
      },
      created() {
        this.getData();
      },
      methods: {
        getData(){
          getActivityInfo(this.query).then(res => {
              if(res.success){
                this.tableData = res.data.list;
                this.total = res.data.total || 0
              }
          });
        },
        // 分页导航
        handlePageChange(val) {
          this.$set(this.query, 'currentPage', val);
          this.getData();
        },
        handleAnimalInfo(){
          this.$router.push({path:"animalInfo"});
        },
        handlePrizeInfo(){
          this.$router.push({path:"prizeInfo"});
        },
        /*handleEdit(){
          this.$router.push({path:"activityEdit"});
        },*/
        handleEdit(form){
          this.confirmUpdate(form);
        },
        popup(form){
          this.dialogFormVisible=true;
          this.form.activityName=form.activityName;
          this.form.beginTime=form.beginTime;
          this.form.endTime=form.endTime;
          this.form.activityRule=form.activityRule;
        },
        async confirmUpdate(params){
          let that = this;
          this.popupMessage='是否确认修改活动信息？';
          await that.$confirm(this.popupMessage, '提示', {
            confirmButtonText: '是',
            cancelButtonText: '否',
            type: 'warning',
            callback:actions=>{
              if(actions === 'confirm'){
                editActivityInfo(params).then(res=>{
                    if(res.success){
                      this.dialogFormVisible = false;
                      this.form = {id:'',activityName: '',beginTime: '',endTime: '',activityRule: ''};
                      this.getData();
                      this.message = '修改成功';
                    }else{
                      this.message = '修改失败';
                    }
                    this.$message({
                      type: 'info',
                      message: this.message
                    });
                  })
              }
            }
          })
        },
      },
    }
</script>

<style lang="less" scoped="scoped">
  .crumbs {
    margin: 10px 0;
  }
  .container {
    padding: 30px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    .handle-box {
      margin-bottom: 20px;
    }
    /*.create-btn {*/
      /*float: right;*/
    /*}*/
  }
  .table {
    width: 100%;
    font-size: 14px;
    text-align: center;
  }
  .el-table th{
    text-align: center;
    background-color: #EBEEF5;
  }
  .dialog-footer{
    padding-top: 50px;
    /*padding: 50px 20px 50px;*/
    /*padding: 10% 6% 5% 50%;*/
  }
  .quill-editor{
    margin-top: 50px;
  }
  .el-input-activityInfo{
    width: 220px;
    margin-right: 320px;
  }
  .el-date-picker-activityInfo1,.el-date-picker-activityInfo2{
    margin-right: 320px;
  }
</style>
