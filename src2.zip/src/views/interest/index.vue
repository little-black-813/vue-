<template>
  <div class="activity-wrapper">
    <div class="crumbs"><span>话费券查询</span></div>
    <div class="container">
      <div class="handle-box">
        <el-button class="create-btn"  type="primary" size="small" @click="closeFrom()">新增话费券</el-button>
        <!--<el-button class="create-btn"  type="primary" size="small" @click="createActivity"  v-if="false">创建活动</el-button>-->
      </div>
      <el-table :data="tableData" class-name="table" ref="multipleTable" header-cell-class-name="table-header" @selection-change="handleSelectionChange">
        <el-table-column label="序号" width="50" align="center">
          <template scope="scope">
            <span>{{(query.currentPage - 1) * query.pageSize + scope.$index + 1}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="chargeCard" align="center" label="话费充值卡金额"></el-table-column>
        <el-table-column prop="moodValue" align="center" label="兑换心情值"></el-table-column>
        <el-table-column prop="number" align="center" label="数量"></el-table-column>
        <el-table-column prop="createTime" align="center" label="创建时间"></el-table-column>
        <el-table-column prop="updatetime" align="center" label="更新时间"></el-table-column>
        <el-table-column label="操作" width="200" align="center">
          <template slot-scope="scope">
            <!--<el-button type="text" icon="el-icon-edit" @click="handleEdit(scope.row)">编辑</el-button>-->
            <el-button type="text" icon="el-icon-edit" @click="popup(scope.row)">编辑</el-button>

            <el-dialog :title="title" :visible.sync="dialogFormVisible">
              <el-form :model="form">
                <el-form-item label="话费充值卡金额"> <!--:label-width="formLabelWidth"-->
                  <el-input v-model="form.chargeCard" oninput="value=value.replace(/[^0-9]/g,'')" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="兑换心情值"> <!--:label-width="formLabelWidth"-->
                  <el-input v-model="form.moodValue" oninput="value=value.replace(/[^0-9]/g,'')" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="数量" > <!--:label-width="formLabelWidth"-->
                  <el-input v-model="form.number" oninput="value=value.replace(/[^0-9]/g,'')" autocomplete="off"></el-input>
                </el-form-item>
              </el-form>
              <div slot="footer" class="dialog-footer">
                <el-button @click="this.dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="handleEdit(form)">确 定</el-button>
              </div>
            </el-dialog>

            <!--<el-button type="text" icon="el-icon-view" @click="interestRecord(scope.row)">查询记录</el-button>-->
             <!--<el-button type="text" icon="el-icon-paperclip" class="red" @click="getLink(scope.row)">获取链接</el-button>-->
            <el-button type="text" icon="el-icon-delete" class="red" @click="handleDelete(scope.$index,scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination">
        <el-pagination
          background
          :hide-on-single-page="true"
          layout="total, prev, pager, next"
          :current-page="query.currentPage"
          :page-size="query.pageSize"
          :total="total"
          @current-change="handlePageChange"
        ></el-pagination>
      </div>
    </div>
    <!--<v-deldialog v-if="delVisiable" :show="delVisiable" :name="multipleSelection[0].activityName" :id="multipleSelection[0].activityId"  url="/data/activityManager/updateActivityState"></v-deldialog>-->
    <!--<v-linkdialog v-if="linkVisiable"  :show="linkVisiable" :activityId="multipleSelection[0].activityId" activityType="interestActivity"></v-linkdialog>-->
  </div>
</template>

<script>
  import bus from 'components/common/bus';
  import { getChargeCard,deleteChargeCard,updateChargeCard,addChargeCard } from 'api/interest/interestActivity.js';
  export default {
   
    data() {
      return {
        query: {
          currentPage: 1,
          pageSize: 5,
          // chargeCard: 2,
          createTime: "string",
          isDelete: "string",
          moodValue: "string",
          number: "string",
          updatetime: "string"
        },
        tableData: [],
        total: 0,
        title: '',
        dialogFormVisible: false,
        form: {
          id:'',
          chargeCard: '',
          moodValue: '',
          number: ''
        },
        dialogTitleType: '',
        message: '',
        popupMessage: '',
        multipleSelection: [],
        delVisiable:false,
        selInd:'',//选择table的下标,
        linkVisiable:false
      };
    },
    created() {
    /*  bus.$on('closeDel',params=>{
        // debugger
        this.linkVisiable = params.show;
        this.delVisiable = params.show;
        this.multipleSelection = [];
        this.selInd = '';
        params.reqFlag && this.getData();
      })*/
      this.getData();
    },
    beforeDestroy(){
      bus.$off('closeDel')
    },
    methods: {
      // 对话框取消事件
      closeFrom(){
        this.dialogFormVisible = true;
        this.title='新增话费充值卡';
        // 点击取消 数据重置
        // this.$refs[formName].resetFields();
        this.form = {id:'',chargeCard: '',moodValue: '',number: ''};
      },
     /* // 对话框关闭事件
      closeDialog(){
        // 点击关闭 数据重置
        this.form = {id:'',chargeCard: '',moodValue: '',number: ''};
        // this.$refs['form'].resetFields();
      },*/
      /*createActivity(){//创建活动
        this.$store.dispatch('interest/setActivityBaseInfo', { activityInfo: {} });
        this.$store.dispatch('interest/setActivityBaseInfo', { prizeList: [] });
        this.$store.dispatch('interest/setActivityId', '');
        this.$router.push('/interest/add');
      },*/
      getData() {

        getChargeCard(this.query).then(res => {
          if(res.success){
            // res.data.list = res.data;
            this.tableData = res.data.list;
            this.total = res.data.total || 0;
          }

        });
      },
      /*changeActivityType(e) {
        this.$set(this.query, 'activityType', e.activityType);
        this.getData();
      },*/
      // 多选操作
      handleSelectionChange(val) {
        this.multipleSelection = val;
      },
      // 分页导航
      handlePageChange(val) {
        this.$set(this.query, 'currentPage', val);
        this.getData();
      },
      handleDelete(ind,row){
        // debugger
        this.confirmDel({id:row.id,});
        // this.delVisiable = true;
        // this.multipleSelection = [row];
      },
      popup(form){
        this.dialogFormVisible = true;
        this.title='更改话费充值卡';
        this.form.chargeCard=form.chargeCard;
        this.form.moodValue=form.moodValue;
        this.form.number=form.number;
      },
      async confirmDel(params){
        console.log(params)
        let that = this;
        await that.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '是',
          cancelButtonText: '否',
          type: 'warning',
          callback:actions=>{
            if(actions == 'confirm'){
              deleteChargeCard(params).then(res=>{
                if(res.success){
                  this.getData()
                }
                this.$message({
                  type: 'info',
                  message:  `删除成功`
                });
              })
            }
          }
        })
      },
      handleEdit(form){
        this.confirmUpdate(form);
      },
      async confirmUpdate(params){
        let that = this;
        this.popupMessage=params.id === ''?'是否确认增加话费券信息？':'是否确认更改话费券信息？';
        await that.$confirm(this.popupMessage, '提示', {
          confirmButtonText: '是',
          cancelButtonText: '否',
          type: 'warning',
          callback:actions=>{
            if(actions === 'confirm'){
              if(params.id === ''){
                addChargeCard(params).then(res=>{
                  if(res.success){
                    this.dialogFormVisible = false;
                    this.form = {id:'',chargeCard: '',moodValue: '',number: ''};
                    this.getData();
                    this.message = '添加成功';
                  }else{
                    this.message = '添加失败';
                  }
                  this.$message({
                    type: 'info',
                    message: this.message
                  });
                })
              }else {
                updateChargeCard(params).then(res=>{
                  if(res.success){
                    this.dialogFormVisible = false;
                    this.form = {id:'',chargeCard: '',moodValue: '',number: ''};
                    this.getData();
                    this.message = '更改成功';
                  }else{
                    this.message = '更改失败';
                  }
                  this.$message({
                    type: 'info',
                    message: this.message
                  });
                })
              }
            }
          }
        })
      },
      // handleEdit(row){
      //   this.$router.push({path:"edit",query:{id:row.activityId}});
      // },
      getLink(row){
        this.linkVisiable = true;
        this.multipleSelection = [row];
      },
      interestRecord(row){
        this.$router.push({path:"detail",query:{id:row.activityId}});
      }
    }
  };
</script>

<style lang="less" scoped="scoped">
  .crumbs {
    margin: 10px 0;
  }
  .container {
    padding: 30px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    .handle-box {
      margin-bottom: 20px;
    }
    .create-btn {
      float: right;
    }
  }
  .table {
    width: 100%;
    font-size: 14px;
    text-align: center;
  }
  .el-table th{
    text-align: center;
    background-color: #EBEEF5;
  }
  .pagination{
    margin: 20px 0;
    text-align: center;
  }
</style>
