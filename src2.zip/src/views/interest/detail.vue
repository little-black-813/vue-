<template>
  <div class="detail-wrapper">
    <el-breadcrumb separator="/" class="crumbs">
      <el-breadcrumb-item>权益记录</el-breadcrumb-item>
    </el-breadcrumb>
    <div class="detail-cont">
    </div>
    <record/>
    <div style="height: 40px;"></div>
  </div>
</template>
<script>
import Record from '@/components/interest/record.vue'
import {judgePath} from '@/utils/utils'
export default {
  components:{Record},
  data() {
    return {
      queryAll:{
        pageSize:1,
        limite:100000000
      },
      lotterDetailData:{
        list:[],
        total:0,
      },
    };
  },
  created() {
  },
  methods: {
    excleLottery(){
      const {id} = this.$route.query;
      let a = document.createElement("a");
      a.href =`${judgePath()}/manager/api/data/excelExport/TypeThread?activityId=`+id;
      document.body.appendChild(a);
      a.click();  //下载
      URL.revokeObjectURL(a.href);    // 释放URL 对象
      document.body.removeChild(a);   // 删除 a 标签
    },
    downloadSelection() {
      const {id} = this.$route.query;
      let a = document.createElement("a");
      a.href =`${judgePath()}/manager/api/data/excelExport/TypeTwo?activityId=`+id;
      document.body.appendChild(a);
      a.click();  //下载
      URL.revokeObjectURL(a.href);    // 释放URL 对象
      document.body.removeChild(a);   // 删除 a 标签
    },
  }
};
</script>

<style lang="less" scoped="scoped">
.el-breadcrumb {
  font-size: 16px;
  margin: 10px 0;
}
.create-btn {
    float: right;
    padding: 10px 15px;
    line-height: 1;
    font-size: 12px;
    border-radius: 3px;
    color: #FFF;
    background-color: #409EFF;
    border-color: #409EFF;
  }
.detail-cont {
  background-color: #ffffff;
  .main-title {
    padding: 20px;
    font-size: 20px;
    color: #333;
    text-align: left;
    margin-top: 10px;
  }
  .card-user-info {
    padding: 20px;
    line-height: 25px;
    margin-bottom: 15px;
  }
  .card-user-info span {
    font-size: 14px;
    color: #666;
  }
  .card-user-info i {
    font-size: 14px;
    color: #999;
  }
  .el-card-outbox {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .el-card-outbox {
    width: inherit;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #f0f0f0;
    padding: 20px;
  }
  .card-el-card {
    width: 30%;
    background: #fff;
    box-sizing: border-box;
    font-size: 16px;
    color: #666;
    text-align: center;
  }

  .card-el-card p {
    padding-bottom: 10px;
    width: 100%;
  }
  .font12 {
    margin-top: 10px;
    font-size: 12px;
  }
  .font32 {
    font-size: 16px;
  }
}
.card-style-border {
  border: 1px dashed #666;
  padding: 20px 30px;
  background-color: #ffffff;
  margin-bottom: 15px;
  .font16 {
    font-size: 16px;
    color: #333;
    font-weight: normal;
  }
  .fr{
    float: right;
  }
  .page-wrapper{
    margin: 20px auto;
    padding: 10px 0;
    text-align: center;
  }
}
</style>
