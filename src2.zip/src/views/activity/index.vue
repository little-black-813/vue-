<template>
  <div class="activity-wrapper">
    <div class="crumbs"><span>萌宠后台管理</span></div>
    <div class="container">
      <el-table :data="tableData" class-name="table" ref="multipleTable" header-cell-class-name="table-header" @selection-change="handleSelectionChange">
         <el-table-column prop="animalType" align="center" label="宠物类型"></el-table-column>
         <el-table-column prop="animalTypeName" align="center" label="宠物类型名字"></el-table-column>
/*         <el-table-column prop="animalFood" align="center" label="宠物口粮"></el-table-column>*/ 
    
          <el-table-column label="宠物图片" align="center">
          <template slot-scope="scope">
              <!-- :preview-src-list="[scope.row.imageId]"可点击查看大图 -->
            <el-image class="table-td-thumb" :src="scope.row.imageUrl" ></el-image>
          </template>
        </el-table-column>

        <el-table-column label="动态图片" align="center">
        <template slot-scope="scope">
            <!-- :preview-src-list="[scope.row.imageId]"可点击查看大图 -->
          <el-image class="table-td-thumb" :src="scope.row.dynamicImageUrl" ></el-image>
        </template>
      </el-table-column>

         <el-table-column prop="createTime" align="center" label="创建日期"></el-table-column>

         <el-table-column label="操作" width="200" align="center">
          <template slot-scope="scope">
            <el-button type="text" icon="el-icon-edit" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button type="text" icon="el-icon-delete" class="red" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    
    </div>
      <el-dialog title="设置动物类型" :visible.sync="dialogVisible">
        <el-form class="form" :model="form" label-width="90px">
        
           <el-form-item label="动物类型">
              <el-select v-model="form.animalType" placeholder="宠物类型" >
                <el-option label="全部" value=""></el-option>
                <el-option label="狗" value="1"></el-option>
                <el-option label="猫" value="3"></el-option>
                <el-option label="鹦鹉" value="2"></el-option>
              </el-select>
            </el-form-item>
          <el-form-item  label="动物名称:">
            <el-input v-model="form.animalTypeName"  placeholder="动物名称" ></el-input>
          </el-form-item>
          <el-form-item  label="宠物图片:">
<el-upload
  class="avatar-uploader"
  action="http://localhost:8080/data/image/data/imgUpload"
  :show-file-list="false"
  :on-success="handleAvatarSuccess"
  :before-upload="beforeAvatarUpload">
  <img v-if="form.imageUrl" :src="form.imageUrl" class="avatar">
  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
</el-upload>
          </el-form-item>

         <el-form-item  label="宠物动态图:">
<el-upload
  class="avatar-uploader"
  action="http://localhost:8080/data/image/data/imgUpload"
  :show-file-list="false"
  :on-success="handleAvatarDynamicImageUrlSuccess"
  :before-upload="beforeAvatarDynamicUpload">
  <img v-if="form.dynamicImageUrl" :src="form.dynamicImageUrl" class="avatar">
  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
</el-upload>
          </el-form-item>

        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="resetForm()">取 消</el-button>
          <el-button type="primary" :loading="$store.state.loading" @click="submitForm(form)">确 定</el-button>
        </div>
      </el-dialog>
  </div>
  </template>

<script>
import bus from 'components/common/bus';
import { getAll , deleteAnimal ,editAnimal} from 'api/animal/animal.js';

export default {

  data() {
    return {
      query: {
        },
        tableData: [

        ],
       form: {
         animalType:"",
         animalTypeName:"",
         imageUrl:"",
         dynamicImageUrl:"",
         id:""
       },
      total: 0,
      multipleSelection: [],
      saveOrupdateVisiable:false,
      dialogVisible: false,
      selRow: {}
    };
  },
  created() {
    bus.$on('closeDel',flag=>{
      this.multipleSelection = [];
      this.selInd = '';
    })
    this.getData();
  },
  methods: {
    getData() {
      getAll(this.query).then(res => {
        if(res.success){
          res.data.forEach(element => {
                 if(element.animalType==1){
                    element.animalType ="狗"
                 }else if(element.animalType==2){
                    element.animalType ="鹦鹉"
                 }else{
                    element.animalType ="猫"
                 }
            });
          this.tableData = res.data;
          this.total = res.data.total || 0;
        }
      });
    },
    // 多选操作
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    // 分页导航
    handlePageChange(val) {
     // this.$set(this.query, 'pageSize', val);
      this.getData();
    },
    handleDelete(ind,row){
      this.confirmDel({id:row.id});
    },
    async confirmDel(params){
      console.log(params)
      let that = this;
      await that.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '是',
          cancelButtonText: '否',
          type: 'warning',
          callback:actions=>{
            if(actions == 'confirm'){
               deleteAnimal(params).then(res=>{
                    if(res.success){
                      this.getData()
                    }
                    this.$message({
                      type: 'info',
                      message:  `删除成功`
                    });
                  })
          }
        }
    })
    },
    handleEdit(row){
       this.dialogVisible = true;
       this.form.animalType=row.animalType,
       this.form.id=row.id,
       this.form.animalTypeName=row.animalTypeName,
       this.form.imageUrl=row.imageUrl,
       this.form.dynamicImageUrl=row.dynamicImageUrl
    },
    resetForm(){
       this.dialogVisible = false;
    },
  

    submitForm(params){
       editAnimal(params).then(res => {
           if(res.success){
              this.getData();
             this.dialogVisible = false;
          }
       })

    },
    handleAvatarSuccess(res, file) {
        if(res.code==='200' || res.code==='0000'){
        console.log("111111111111:"+URL.createObjectURL(file.raw))
        this.form.imageUrl = res.data.getImage
        // this.animalImageUrl = URL.createObjectURL(file.raw);
      }else{
        this.upLoading = false;
        this.$message.error('上传失败，请稍后再试')
      }
    },
      handleAvatarDynamicImageUrlSuccess(res, file) {
        if(res.code==='200' || res.code==='0000'){
        console.log("111111111111:"+URL.createObjectURL(file.raw))
        this.form.dynamicImageUrl = res.data.getImage
        // this.animalImageUrl = URL.createObjectURL(file.raw);
      }else{
        this.upLoading = false;
        this.$message.error('上传失败，请稍后再试')
      }
    },
     handleError(err,file,FileList){
      this.upLoading = false;
      this.$message.error('上传失败，请稍后再试')
    },
    beforeAvatarUpload(file) {
      this.upLoading = true;
      const isJPG = file.type === 'image/jpeg' || file.type === 'image/jpg' || file.type === 'image/JPG' || file.type === 'image/png' || file.type === 'image/PNG';
      return isJPG;
    },
      beforeAvatarDynamicUpload(file) {
        console.log(file)
      this.upLoading = true;
      const isJPG = file.type === 'image/gif' ;
      return isJPG;
    }
  }       
   
};



</script>

<style lang="less" scoped="scoped">
.crumbs {
  margin: 10px 0;
}
.container {
  padding: 30px;
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 5px;
  .handle-box {
    margin-bottom: 20px;
  }
  .create-btn {
    float: right;
  }
}
.table {
      width: 100%;
      font-size: 14px;
      text-align: center;
  }
  .el-table th{
    text-align: center;
    background-color: #EBEEF5;
  }
.pagination{
  margin: 20px 0;
  text-align: center;
}
.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>
