<template>
  <div class="login-wrap">
    <div class="ms-login">
      <div class="ms-title">活动配置后台管理系统</div>
      <el-form :model="loginForm" :rules="rules" ref="loginForm" label-width="0px" class="ms-content">
        <el-form-item prop="mobile">
          <el-input v-model="loginForm.mobile" placeholder="请输入移动号码"><el-button slot="prepend" icon="el-icon-user"></el-button></el-input>
        </el-form-item>
        <el-form-item prop="password">
          <el-input type="password" placeholder="请输入密码" v-model="loginForm.password" @keyup.enter.native="submitForm()">
            <el-button slot="prepend" icon="el-icon-lock"></el-button>
          </el-input>
        </el-form-item>
        <!-- <el-form-item prop="code">
          <el-input v-model="loginForm.code" placeholder="请输入验证码" @keyup.enter.native="submitForm()"><el-button slot="append" :disabled="canClick" @click="getCode">{{btnText}}</el-button></el-input>
        </el-form-item> -->
        <div class="login-btn"><el-button type="primary" @click="submitForm()">登录</el-button></div>
      </el-form>
    </div>
  </div>
</template>

<script>
import { login, getCode } from '@/api/user';
import { mapActions, mapMutations, mapState } from 'vuex';
import avatar from "@assets/img/img.jpg"
import { isEmptyValue } from '@/utils/utils'
export default {
  data: function() {
    return {
      timmer: null,
      btnText: '获取验证码',
      canClick: false,
      countdown: 60,
      loginForm: {
        mobile: '',
        password: ''
        // code: ''
      },
      rules: {
        mobile: [{ required: true, message: '请输入移动号码', trigger: 'change' },
        {pattern:/^1\d{10}$/,message: '请输入正确的用户移动手机号', trigger: 'change'}
        ],
        password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
        //  code: [{ required: true, message: '请输入验证码', trigger: 'blur' },
        // {pattern:/^\d{6}$/,message: '请输入正确的验证码', trigger: 'change'}]
      }
    };
  },
  computed: {
    ...mapState('mc',['adminName','token'])
  },
  methods: {
    ...mapMutations('mc',['setUserInfo']),
    countdownFn () {
          const that = this
          if (!that.canClick) return
         const timmer = setInterval(function () {
            that.canClick = true
            that.countdown--
            that.btnText = '重新获取(' + that.countdown + 's)'
            if (that.countdown === 0) {
              that.countdown = 60
              that.btnText = '获取验证码'
              clearInterval(timmer)
              that.canClick = false
            }
          }, 1000)
        },
    //获取验证码
    getCode() {
      let that = this;
      that.$refs.loginForm.validateField(['mobile'],(valid) => {
        console.log(valid)
        if(!valid){
          getCode({userMobile:that.loginForm.mobile}).then((res=>{
            console.log(res)
            that.canClick = true
            that.countdownFn()
          }))
        }
      })
    },
    submitForm() {
    	let that = this;
      that.$refs.loginForm.validate((valid) => {
          //   if (true) {
          console.log(that.loginForm)
          login(that.loginForm).then(res=>{
            if (res.success) {
              this.setUserInfo({adminName:that.loginForm.mobile,token:res.data.token})
          //  	that.$store.commit("mc/setUserInfo", {adminName:that.loginForm.mobile})
              that.$message({
                type: 'success',
                message: '登录成功'
              });
         //     sessionStorage.setItem('n',"true")
         console.log("/activityInfo/index")
              that.$router.push({path:"/activityInfo/index"});
            } else {
              this.$message({
                type: 'error',
                message: `${res.message}`
              });
            }
          }).catch(err=>{
        console.log(err)
      })

      });
    }
  }
};
</script>

<style scoped>
.login-wrap {
  position: relative;
  width: 100%;
  height: 100%;
  background-image: url(../assets/img/login-bg.jpg);
  background-size: 100%;
}
.ms-title {
  width: 100%;
  line-height: 50px;
  text-align: center;
  font-size: 20px;
  color: #fff;
  border-bottom: 1px solid #ddd;
}
.ms-login {
  position: absolute;
  left: 50%;
  top: 50%;
  width: 350px;
  margin: -190px 0 0 -175px;
  border-radius: 5px;
  background: rgba(255, 255, 255, 0.3);
  overflow: hidden;
}
.ms-content {
  padding: 30px 30px;
}
.login-btn {
  text-align: center;
}
.login-btn button {
  width: 100%;
  height: 36px;
  margin-bottom: 10px;
}
</style>
