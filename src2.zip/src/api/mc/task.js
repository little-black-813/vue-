import request from '@/utils/axios'
//查询全部任务
export const getTask = params=>{
  return request({
    url: '/manager/queryTaskList',
    method: 'post',
    params: params
  });
}
//删除任务
export const deleteTask = params => {
  return request({
    url:'/manager/deleteTask',
    method:'get',
    params:params
  })
}

//编辑任务
export const editOrSaveTask = params => {
  return request({
    url:'/manager/editOrSaveTask',
    method:'post',
    params:params
  })
}

//添加任务
export const addTask = params => {
    return request({
      url:'/manager/addTask',
      method:'post',
      params:params
    })
  }