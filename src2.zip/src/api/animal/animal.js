import request from '@/utils/axios'
//查询全部动物类型
export const getAll = params=>{
  return request({
    url: '/manager/queryAllType',
    method: 'post',
    params: params
  });
}
//删除动物类型
export const deleteAnimal = params => {
  return request({
    url:'/manager/deleteAnimalType',
    method:'get',
    params:params
  })
}

//编辑动物类型
export const editAnimal = params => {
  return request({
    url:'/manager/editAnimalType',
    method:'post',
    params:params
  })
}
