import request from '@/utils/axios'

//获取活动信息
export const getActivityInfo = params=>{
  return request({
    url: '/manager/ActivityInfo/selectActivityInfo',
    method: 'post',
    params: params
  });
};

//获取活动信息
export const editActivityInfo = params=>{
  return request({
    url: '/manager/ActivityInfo/editActivityInfo',
    method: 'post',
    params: params
  });
};

//获取用户信息
export const getAnimalInfo = params=>{
  return request({
    url: '/manager/animal/getAllAnimalInfo',
    method: 'post',
    params: params
  });
};

//获取食物信息
export const getFoodInfo = params=>{
  return request({
    url: '/manager/food/selectAllFood',
    method: 'post',
    params: params
  });
};

//获取心情信息
export const getMoodInfo = params=>{
  return request({
    url: '/manager/mood/getAllMoodRecord',
    method: 'post',
    params: params
  });
};

//获取奖品兑换信息
export const getPrizeInfo = params=>{
  return request({
    url: '/manager/chargeCardChange/getAllCardChange',
    method: 'post',
    params: params
  });
};

//获取话费券卡信息
export const getChargeCardInfo = params=>{
  return request({
    url: '/manager/chargeCard/queryMcChargeCardInfo',
    method: 'post',
    params: params
  });
};

//导出用户信息
export const downloadAnimalInfo = params=>{
  return request({
    url: '/manager/data/excelExport/exportAnimalRecord',
    method: 'post',
    params: params,
    responseType: 'blob'
  });
};
