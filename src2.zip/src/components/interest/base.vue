<template>
  <div class="base-wrapper">
    <p class="base-title">基础信息</p>
    <el-form
      ref="creatForm"
      :model="creatForm"
      :rules="rules"
      class="creat-act-form"
      label-width="190px">

      <el-form-item label="活动名称：" prop="activityName">
        <el-input v-model.trim="creatForm.activityName"></el-input
      ></el-form-item>
      <el-form-item label="活动时间：" required>
        <el-col :span="11">
          <el-form-item prop="activityStartTime">
            <el-date-picker
              type="datetime"
              placeholder="选择开始日期"
              @change="changeTime1"
              v-model="creatForm.activityStartTime"
              style="width: 100%;"
            ></el-date-picker>
          </el-form-item>
        </el-col>
        <el-col class="line" :span="2">-</el-col>
        <el-col :span="11">
          <el-form-item prop="activityEndTime">
            <el-date-picker
              type="datetime"
              placeholder="选择截至日期"
              @change="changeTime2"
              v-model="creatForm.activityEndTime"
              style="width: 100%;"
            ></el-date-picker>
          </el-form-item>
        </el-col>
      </el-form-item>

      <el-form-item label="其他活动链接：" prop="otherActivityUrl"
        ><el-input v-model.trim="creatForm.otherActivityUrl"></el-input
      ></el-form-item>

       <el-form-item label="图片：" prop="settingPhoto">
       <el-input
         type="hidden"
         v-model="creatForm.settingPhoto"
       ></el-input>
        <v-uploadimg :id="creatForm.activityId"
         labelKey="settingPhoto"
         c="interestImgCb"
         upImagSize="704px * 296px" :imgUrl="creatForm.settingPhotoFront">
         </v-uploadimg>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="submitForm('creatForm')">立即创建</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import bus from "components/common/bus";
import vUploadimg from 'components/common/uploadImg'
import { mapState } from "vuex";
import { createOrEditBaseActivityReq } from "api/interest/interestActivity.js";
import { isEmptyObject, formatDate, isEmptyValue } from "@/utils/utils";
export default {
  components:{
    vUploadimg
  },
  data() {
    return {
      isShowCenter: false,
      creatForm: {
        activityName: "",
        otherActivityUrl: "",
        settingUrl  : "",
        activityStartTime: "",
        activityEndTime: "",
        activityType:"interestActivity",
        activityId:"",
        settingPhoto: '',
        settingPhotoFront:""
      },

      rules: {
        activityStartTime: [
          {
            type: "string",
            required: true,
            message: "请选择活动开始时间",
            trigger: "change"
          }
        ],
        activityEndTime: [
          {
            type: "string",
            required: true,
            message: "请选择活动结束时间",
            trigger: "change"
          }
        ],
        activityName: [
          { required: true, message: "请输入活动名称", trigger: "blur" }
        ],
        otherActivityUrl: [
          { required: true, message: "请输入其他信息活动", trigger: "blur" }
        ],
        contactService: [
          { required: true, message: "请输入配置链接", trigger: "blur" }
        ],
        settingPhoto : [
          { required: true, message: "请输入配置图片", trigger: "blur" }
        ]
      }
    };
  },
  props: ["type"],
  computed:{
  },
  created() {
    this.creatForm = this.initForm();
    bus.$on('interestImgCb',params=>{
console.log(params.id)
      this.creatForm.settingPhoto = params.id;
      this.creatForm.settingPhotoFront  = params.url;
    })

  },
  beforeDestroy() {
  	bus.$off('interestImgCb');
  },
  methods: {
    changeTime1(val) {
      this.$set(
        this.creatForm,
        "activityStartTime",
        formatDate(val, "yyyy-MM-dd HH:mm:ss")
      );
    },
    changeTime2(val) {
      this.$set(
        this.creatForm,
        "activityEndTime",
        formatDate(val, "yyyy-MM-dd HH:mm:ss")
      );
    },
    initForm() {
      let activityInfo = this.$store.state.interest.activityBaseInfo.activityInfo;
      let activityId=this.$store.state.interest.activityBaseInfo.activityId;

      if (this.type === "edit") {
        //编辑
        // debugger
        activityInfo = this.$store.state.interest.editBaseInfo.activityInfo;
        activityInfo.settingPhotoFront = activityInfo.settingPhotoFront || activityInfo.settingPhoto;
      }
      if (isEmptyObject(activityInfo)) {
        return this.creatForm;
      } else {
        let p_info = activityInfo;
        return { ...p_info };
      }
    },

    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        this.$set(this.creatForm,'activityType', 'interestActivity')
        if (valid) {
          //存储vuex，上一步时，可以会显
          // this.$store.dispatch('setActivityBaseInfo', { activityInfo: this.creatForm })
          let s_id = this.$store.state.interest.activityId;
          let reqUrl = "/data/activity/addActivity";
          if (!isEmptyValue(s_id) && this.type === "add") {
            reqUrl = "/data/activity/updateActivityInfo";
          }
          console.log(this.type);
          if (this.type === "edit") {
            reqUrl = "/data/activity/updateActivityInfo";
            s_id = this.$route.query.id;
          //  this.creatForm.settingPhoto = this.creatForm.settingPhotoFront || this.creatForm.settingPhoto;
          }
          // console.log({...this.creatForm,activityId:s_id})
         this.createActivity({reqUrl,creatForm:{...this.creatForm,activityId:s_id}});
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    //创建活动基础信息
    createActivity(params) {
      createOrEditBaseActivityReq(params).then(res => {
        if (res.flag === true) {
          this.$message({
            message: "恭喜你，创建基础信息成功",
            type: "success"
          });
          if (this.type === "edit") {
            this.$store.dispatch("interest/setEditbaseInfo", {
              activityInfo: { ...params.creatForm }
            });
          } else {
            this.$store.dispatch("interest/setActivityBaseInfo", {
              activityInfo: { ...params.creatForm }
            });
            if (isEmptyValue(params.creatForm.activityId)) {
            }
          }
          bus.$emit("interestOp", "add");
        }
      });
    }

  }
}
;
</script>

<style scoped="scoped" lang="less">
.base-wrapper {
  .line {
    text-align: center;
  }
  .base-title {
    font-size: 20px;
    margin: 15px 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eeeeee;
  }
  .creat-act-form {
    width: 60%;
  }
}
</style>
