<template>
  <div class="base-wrapper">
    <p class="base-title">分享设置</p>
    <el-form ref="shareForm" :model="shareForm" :rules="getRules" label-width="180px" class="creat-act-form">
      <el-form-item label="分享标题：" prop="shareTitle">
        <el-input
          type="text"
          v-model.trim="shareForm.shareTitle"
        ></el-input>
      </el-form-item>
      <el-form-item label="分享摘要：" prop="shareSummaries">
        <el-input
          type="textarea"
          v-model.trim="shareForm.shareSummaries"
        ></el-input>
      </el-form-item>
      <!-- {{shareForm.sharePhoto}} -->
     <el-form-item label="分享图：" prop="sharePhoto">
       <el-input
         type="hidden"
         v-model="shareForm.sharePhoto"
       ></el-input>
        <v-uploadimg :id="getId" labelKey="sharePhoto" c="interestShareImgCb" upImagSize="200px * 200px" :imgUrl="shareForm.sharePhotoUrlFront"/>
      </el-form-item>
      <el-form-item>
        <el-button  @click="prevForm()">上一步</el-button>
        <el-button type="primary" @click="submitForm('shareForm')">完成</el-button>
        <!--<el-button type="danger" @click="resetForm('shareForm')">重置</el-button>-->
      </el-form-item>
    </el-form>
  </div>
</template>

<!-- <script>
import bus from 'components/common/bus';
import {mapState} from 'vuex';
import { setShareReq } from 'api/activity.js';
import {isEmptyObject,isEmptyValue} from '@/utils/utils'
import vUploadimg from 'components/common/uploadImg'
export default {
  components:{
    vUploadimg
  },
  data() {
    return {
      creatForm: {
        shareTitle: '',
        shareSummaries: '',
        sharePhoto:'',
        sharePhotoUrlFront:''
      },
      rules: {
        shareTitle: [{ required: true, message: '请输入分享标题', trigger: 'blur'  }],
        shareSummaries: [{ required: true, message: '请输入分享摘要', trigger: 'blur'  }],
        sharePhoto: [{ required: false, message: '请上传分享图片', trigger: 'change'  }]
      }
    };
  },
  props:['type'],
  computed:{
    shareForm(){
      let shareInfo = {};
      if(this.type==='edit'){
        shareInfo = this.$store.state.interest.editBaseInfo.activityInfo;
        shareInfo.sharePhotoUrlFront = shareInfo.sharePhotoUrlFront || shareInfo.sharePhoto;
      }else{
        shareInfo = this.$store.state.interest.activityBaseInfo.shareInfo;
      }
      if(isEmptyObject(shareInfo)){
        return this.creatForm;
      }
      console.log(shareInfo)
      return shareInfo;
    },
    getRules(){
      if(this.type==='edit'){
        this.rules.sharePhoto = [{ required: false, message: '请上传分享图片', trigger: 'change'  }]
      }
      return this.rules;
    },
    getId(){
     let id=this.$store.state.interest.activityId;
    	if(this.type==='edit'){
    		id = this.$route.query.id;
    	}
      return id;
    }
  },
  created() {
    bus.$on('interestShareImgCb',params=>{
      this.shareForm.sharePhoto = params.id;
      this.shareForm.sharePhotoUrlFront  = params.url;
    })
  },
  beforeDestroy() {
  	bus.$off('interestShareImgCb');
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          //存储vuex，上一步时，可以会显
          //判断编辑还是新增
          console.log(this.shareForm, 'shareForm')
          let reqUrl ='/data/activity/setActivityShare';
          setShareReq({shareForm:{...this.shareForm,activityId:this.getId},reqUrl}).then(res=>{
            if(res.flag){
               this.$message({
                  message: '恭喜你，设置分享信息成功。',
                  type: 'success'
                });
                //存储vuex，上一步时，可以会显
                console.log(this.type, 'typehcsh')
                if(this.type==='edit'){
                  this.$store.dispatch('setEditbaseInfo',{activityInfo:this.shareForm})
                  // alert('编辑')
                }else{
                  // alert('创建cd')
                  this.$store.dispatch('setActivityBaseInfo',{shareInfo:this.shareForm})
                }
             // bus.$emit('interestOp','add');
            }else{
              this.$message.error(`${res.message}`);
            }
            this.$router.push({path: '/interest/index'});

          })

        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    prevForm(){
      bus.$emit('interestOp','minus');
    },
    changeShare(val){
        this.rules = {
        // shareGames: [{ required: true, message: '请选择活动类型', trigger: 'change' }],
        // increTimes: [{ required: val, message: '请输入每日可增加次数', trigger: 'change' }],
        shareTitle: [{ required: val, message: '请输入分享标题', trigger: 'blur'  }],
        shareSummaries: [{ required: val, message: '请输入分享摘要', trigger: 'blur'  }],
        sharePhoto: [{ required: val, message: '请上传分享图片', trigger: 'change'  }]
      }
    }
  }
};
</script>
 -->
<style scoped="scoped" lang="less">
.base-wrapper {
  .line{
    text-align: center;
  }
  .base-title{
    font-size: 20px;
    margin: 15px 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid #EEEEEE;
  }
  .creat-act-form{
    width: 60%;
  }
}
</style>
