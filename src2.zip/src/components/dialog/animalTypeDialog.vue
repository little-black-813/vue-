<template>
  <el-dialog :title="title" center :visible.sync="showDia" :show-close="true"  :close-on-click-modal="false" :close-on-press-escape="false" :destroy-on-close="true" :before-close="beforeHide">
    <el-form class="form" ref="animalForm" :model="animalForm" :rules="rules" label-width="90px">
      <el-form-item  label="宠物类型:" prop="animalType"><el-input v-model.trim="animalType"  placeholder="宠物类型"></el-input></el-form-item>
      <el-form-item  label="宠物口粮:" prop="animalFood"><el-input v-model.trim="animalFood"  placeholder="宠物口粮" ></el-input></el-form-item>
       <el-form-item  label="宠物图片:" prop="imageId"><el-input type="hidden" v-model="imageId" ></el-input>
        <v-uploadimg labelKey="animalImage" :id="getActivityId" c="prizeImgUrl" :imgUrl="imageId"></v-uploadimg>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="resetForm('animalForm')">取 消</el-button>
      <el-button type="primary" :loading="$store.state.loading" @click="submitForm('animalForm')">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
import bus from 'components/common/bus';
import {mapState} from 'vuex';
import vUploadimg from 'components/common/uploadImg'
import { editAnimal } from 'api/animal/animal.js'
import {isEmptyValue,formatDate} from '@/utils/utils';
export default {
  props: ['formInit','show','title'],
  data() {
    return {
      animalForm:this.$props.formInit,
      showDia:this.$props.show
    },
    {
      animalType:"",
      animalFood:""
    }
  },
  computed:{
    prizeForm(){
      let that = this;
      if(that.formInit){
         that.title = "编辑奖品";
         that.animalType= that.formInit.animalType;
         return that.formInit
      }
    }
  },
  created() {
    //this.getData();
  },
methods: {
  /* getData() {
      getAll(this.query).then(res => {
        if(res.success){
          this.animalForm = res.data;
        }
      });
    } */
}
};
</script>

<style lang="less" scoped="scoped">
  .line {
    text-align: center;
  }
  ::v-deep {
    /* .el-dialog{
      min-width: 200px;
    } */
    .el-input {
    width: 200px;
    }
    .el-dialog__body{
      max-height: 500px;
      overflow-y: auto;
      overflow-x: hidden;
    }
    .el-dialog__footer{
      border-top: 1px solid #EEEEEE;
    }
  }
</style>
