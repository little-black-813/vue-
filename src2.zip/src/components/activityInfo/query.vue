<template>
  <div class="activityInfo-query" >
    <el-form class="actInfo-query-form" size="mini" :inline="true">
      <!--<el-form-item class="actInfo-query-it1">
        <el-input v-model="searchInfo.mobile" placeholder="用户手机号" ></el-input>
      </el-form-item >-->
      <el-form-item label="方向">
        <el-select v-model="searchInfo.isAdd" placeholder="全部" >
          <el-option label="全部" value=""></el-option>
          <el-option label="增加" value="0"></el-option>
          <el-option label="减少" value="1"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="来源">
        <el-select v-model="searchInfo.source" placeholder="全部" >
          <el-option label="全部" value=""></el-option>
          <el-option label="支付宝" value="支付宝"></el-option>
          <el-option label="微信" value="微信"></el-option>
        </el-select>
      </el-form-item>
      <el-date-picker
        size="mini"
        v-model="searchInfo.value"
        value-format="yyyy-MM-dd HH:mm:ss"
        type="datetimerange"
        range-separator="-"
        start-placeholder="开始日期"
        end-placeholder="结束日期">
      </el-date-picker>
      <el-form-item class="actInfo-query-it3">
        <el-button type="primary" @click="bindFoodInfo()">查询</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
    export default {
      data(){
        return{
          searchInfo: {
            mobile: '',
            source: '',
            isAdd: '',
            value: ''
          },
        }
      },
      // props: ['mobile'],
      methods: {
        bindFoodInfo(){
          this.$emit("childClick",this.searchInfo);
        }
      }
    }
</script>

<style scoped="scoped" lang="less">
  .actInfo-query-it3{
    margin-left: 10px;
  }
  /*::v-deep {
    .el-input, .el-input__inner {
      width: 75%;
    }
  }
  .el-form--inline {
    display: inline-block;
    margin-right: -50px;
    vertical-align: top;
  }*/
</style>
