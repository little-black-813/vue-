<template>
  <!-- /imgUpload https://jsonplaceholder.typicode.com/posts/-->
  <el-upload

    class="avatar-uploader"
    :action="path"
    :show-file-list="false"
    :on-success="handleAvatarSuccess"
    :on-error="handleError"
    :before-upload="beforeAvatarUpload"
    :data="extendDataFile">
    <div v-if="imageUrl" v-loading.lock="loading" style="position: relative;">
      <img  @load="loadImage" :src="imageUrl" class="avatar" />
    </div>
    <i v-else v-loading.lock="upLoading" class="el-icon-plus avatar-uploader-icon"></i>
    <!-- ，图片尺寸为{{upImagSize}} -->
    <div slot="tip" class="el-upload__tip">仅支持JPG、PNG格式；{{upImagSize ? '图片尺寸：'+upImagSize : upImagSize}}</div>
  </el-upload>
</template>

<script>
import bus from './bus';
import { judgePath, isEmptyValue } from '@/utils/utils';
export default {
  data() {
    return {
      loading:true,
      upLoading: false,
      imageUrl: this.imgUrl,
    };
  },
  props: ["labelKey", 'imgType', 'imgUrl','id','c','upImagSize','upUrl','extendData'],
  computed:{
    // 上传编辑奖品图片
    path(){
      // return `${judgePath()}/testLottery/api/data/imgUpload`  //测试
      return this.upUrl || `${judgePath()}/manager/api/data/imgUpload` // 生产
    },
    extendDataFile () {
      console.log((this.imgType || this.labelKey))
      return this.extendData || {imageType:(this.imgType || this.labelKey), activityId:this.id}
    }
  },
  methods: {
    loadImage(){
      this.loading = false;
    },
    handleAvatarSuccess(res, file) {
      const { labelKey, imgType } = this.$props;
      let cb = this.c || 'imgUrlCallback';
      console.log(res.code==='200' || res.code==='0000')
      if(res.code==='200' || res.code==='0000'){
        this.imageUrl = URL.createObjectURL(file.raw);
        let params = '';
        if(!isEmptyValue(imgType)){//兼容旭凯上传文件
          params = {labelKey,url:res.data.imageName,id:res.data.id}
        }else{
          params = {labelKey,url:res.returnData.imaggeUrl,id:res.returnData.id};
        }
        console.log('cb',cb,params)
        bus.$emit(cb, params)
      }else{
        this.upLoading = false;
        this.$message.error('上传失败，请稍后再试')
      }
    },
    handleError(err,file,FileList){
      this.upLoading = false;
      this.$message.error('上传失败，请稍后再试')
    },
    beforeAvatarUpload(file) {
      this.upLoading = true;
    	// console.log(this.id)
      const isJPG = file.type === 'image/jpeg' || file.type === 'image/jpg' || file.type === 'image/JPG' || file.type === 'image/png' || file.type === 'image/PNG';
      /* const isLt2M = file.size / 1024 / 1024 < 2;
      if (!isLt2M) {
        this.$message.error('上传头像图片大小不能超过 2MB!');
      }
      return isLt2M; */
      return isJPG;
    }
  }
};
</script>

<style scoped="scoped" lang="less">
  .avatar-uploader{
    margin-top: -26px;
  }
  ::v-deep{
    .el-upload {
      border: 1px dashed #d9d9d9;
      border-radius: 6px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }
    .el-upload:hover {
      border-color: #409eff;
    }
    .el-loading-spinner{
      transform: translateY(-33%);
    }
  }
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}
.avatar {
  position: relative;
  width: 178px;
  min-height: 42px;
  // height: auto;
  // height: 178px;
  display: block;
}
</style>
