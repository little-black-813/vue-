<template>
  <div class="menu0805" v-if="!item.hidden">
    <template
      v-if="hasOneShowingChild(item.children,item) && (!onlyOneChildShow.children||onlyOneChildShow.noShowingChildren)"
    >
      <el-menu-item
        :index="resolvePath(onlyOneChildShow.path)"
        :key="onlyOneChildShow.path"
      >{{onlyOneChildShow.meta.title}}</el-menu-item>
    </template>
    <el-submenu v-else ref="subMenu" :index="resolvePath(item.path)" popper-append-to-body>
      <template slot="title">
          <span v-if="item.meta">{{item.meta.title}}</span>
      </template>
      <sidebar-item
        v-for="child in item.children"
        :key="child.path"
        :is-nest="true"
        :item="child"
        :base-path="resolvePath(child.path)"
        class="nest-menu"
      />
    </el-submenu>
  </div>
</template>
<script>
import path from "path";
export default {
  name: "sidebarItem",
  props: {
    //route
    item: {
      type: Object,
      required: true
    },
    basePath: {
      type: String,
      default: ""
    },
    isNest: {
      type: Boolean,
      default: false
    },
  },
  data() {
    this.onlyOneChildShow = null;
    return {};
  },
  methods: {
    hasOneShowingChild(children = [], parent) {
      const showingChild = children.filter(item => {
        if (item.hidden) {
          return false;
        } else {
          this.onlyOneChildShow = item;
          return true;
        }
      });
      //如果只有一个子路由，默认展示子路由
      if (showingChild.length === 1) {
        return true;
      }
      //没有子路由，用父级路由进行展示
      if (showingChild.length === 0) {
        this.onlyOneChildShow = {
          ...parent,
          path: "",
          noShowingChildren: true
        };
        return true;
      }
      return false;
    },
    resolvePath(routePath) {
      if (/^(https?:|mailto:|tel:)/.test(routePath)) {
        return routePath;
      }
      if (/^(https?:|mailto:|tel:)/.test(this.basePath)) {
        return this.basePath;
      }
      return path.resolve(this.basePath, routePath);
    }
  }
};
</script>
<style lang="less" scoped>
 .menu0805{
  width: 200px;
 }
 .menu-item-wrapper {
  display: inline-block;
}
/*.menu-item-wrapper > .el-menu-item.is-active {
  border-bottom: 2px solid #409eff;
  color: #303133;
} */
</style>
