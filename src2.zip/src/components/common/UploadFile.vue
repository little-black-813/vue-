<template>
  <el-upload
    class="upload-file"
    :name="name"
    :action="path"
    :show-file-list="false"
    :on-error="handleFileError"
    :on-success="handleFileSuccess"
    :before-upload="beforeFileUpload"
    :data="extendData"
  >
  <!-- @click="uploadFileJudge()" -->
    <el-button size="medium" plain type="warning" >{{text}}</el-button>
  </el-upload>
</template>

<script>
import bus from 'components/common/bus';
export default {
  props:{
    path: {
      type: String,
      default: ''
    },
    fileType: {
      type: String,
      default: ''
    },
    name: {
      type: String,
      default: 'upPopfile'
    },
    extendData: {
      type: Object,
      default: function(){
        return {}
      }
    },
    text: {
      type: String,
      default: '上传弹窗目标'
    }

  },
  methods:{
    handleFileError(err, file, fileList){
      // console.log(err)
      this.$message({
        message: `${err.message || '对不起，上传失败了，重新尝试'}`,
        type: 'error'
      });
    },
    beforeFileUpload(file) {
      let name = file.name;
      let suffix = name.substr(name.lastIndexOf("."));

      if(".xls" != suffix && ".xlsx" != suffix ){
        //校验不通过
        this.$message({
          message: '请选择文件',
          type: 'warning'
        });
        return false;
      }
    },
    handleFileSuccess(res,file) {
      if(res.code==='9999'){
        this.$message({
          message: `${res.mess || '上传失败了，重新尝试'}`,
          type: 'error'
        });
      }else{
        this.$message({
          message: `${res.mess || '恭喜你，上传成功'}`,
          type: 'success'
        });
        bus.$emit('upFileActon',{show:false,fileId:''});
      }

    },
  }
}
</script>

<style>
</style>
