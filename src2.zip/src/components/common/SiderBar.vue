<template>
    <div class="sidebar">
        <el-menu
            class="sidebar-el-menu"
            :default-active="onRoutes"
            :collapse="collapse"
            background-color="#324157"
            text-color="#bfcbd9"
            active-text-color="#20a0ff"
            unique-opened
            router
        >
        <sidebar-item v-for="route in $router.options.routes" :key="route.path" :item="route" :base-path="route.path"></sidebar-item>
        </el-menu>
    </div>
</template>

<script>
import path from "path";
import bus from '../common/bus';
import sidebarItem from './SiderBarItem.vue'
export default {
  components:{
    sidebarItem
  },
    data() {
      this.onlyOneChildShow=null;
        return {
            collapse: false,
        };
    },
    computed: {
        onRoutes() {
          const route = this.$route;
          const {meta,path} = route;
          if(meta.activeMenu){
            return meta.activeMenu;
          }
          return path;
          //   return this.$route.path.replace('/', '');
        }
    },
    created() {
        // 通过 Event Bus 进行组件间通信，来折叠侧边栏
        bus.$on('collapse', msg => {
            this.collapse = msg;
            bus.$emit('collapse-content', msg);
        });
    },
};
</script>

<style scoped>
.sidebar {
    display: block;
    width: 200px;
    position: absolute;
    left: 0;
    top: 0px;
    bottom: 0;
    overflow-y: scroll;
    background-color: #324157;
}
.sidebar::-webkit-scrollbar {
    width: 0;
}
.sidebar > ul {
    /* height: 100%; */
}
</style>
