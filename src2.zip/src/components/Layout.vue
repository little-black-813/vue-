<template>
  <el-container class="wrapper" v-loading="loading" element-loading-text="拼命加载中"
    element-loading-background="rgba(255,255,255,.5)" element-loading-customClass="loading0610">
    <el-header><v-header></v-header></el-header>
    <el-container>
      <el-aside width="200px"><v-siderbar></v-siderbar></el-aside>
      <el-main>
        <v-tags></v-tags>
        <div class="content">
          <transition name="fade" mode="out-in">
            <keep-alive :include="tagsList"><router-view></router-view></keep-alive>
          </transition>
        </div>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import {mapState} from 'vuex';
import vHeader from './common/Header';
import vSiderbar from './common/SiderBar.vue';
import vTags from './common/Tags.vue';
import bus from './common/bus';
export default {
  data() {
    return {
      tagsList: [],
      // loading:true
    };
  },
  components: {
    vHeader,
    vSiderbar,
    vTags
  },
  computed:{
    ...mapState(['loading'])
  },
  created() {
    // 只有在标签页列表里的页面才使用keep-alive，即关闭标签之后就不保存到内存中了。
    bus.$on('tags', msg => {
      let arr = [];
      for (let i = 0, len = msg.length; i < len; i++) {
        /* if(msg[i].name!=="ActivityAdd"){
          arr.push(msg[i].name);
        } */
        msg[i].name && arr.push(msg[i].name);
      }
      // console.log(arr)
      this.tagsList = arr;
    });
  }
};
</script>

<style scoped="scoped">
.wrapper {

}
.el-header {
  padding: 0;
  background-color: #242f42;
}
.el-container {
  height: 100%;
  position: relative;
}
.el-main {
  padding: 0 0 20px;
  overflow-x: hidden;
}
.content {
  width: auto;
  height: 100%;
  padding: 10px;
  /* padding-top: 30px; */
  overflow-y: scroll;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  background-color: #f0f0f0;
}
</style>
