const state = {
  userInfo: {
    adminName: '',
    token: localStorage.getItem('Authorization') ? localStorage.getItem('Authorization') : ''

}
}
const mutations = {
  setUserInfo(state, payload){
        if(payload.hasOwnProperty('token')){
          state.userInfo.token = payload.token
          localStorage.setItem('Authorization', payload.token);
        }
        state.userInfo.adminName = payload.adminName
 }
}
const actions = {}
export default {
  namespaced: true,
  state,
  mutations,
  actions
}
