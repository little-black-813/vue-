export const interestroute = {
  path: '/interest',
  component: () => import('@/components/Layout.vue'),
  meta: {
    title: '话费券管理'
  },
  hidden: false,
  children: [{
      path: "index",
      component: () => import('@/views/interest/index'),
      name: "interestMan",
      meta: {
        title: '话费管理'
      }
    }
  ]
}
