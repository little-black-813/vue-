import Vue from 'vue'
import VueRouter from 'vue-router'
import {interestroute} from './interest.js'
import {activityInfoRouter} from './activityInfo.js'
Vue.use(VueRouter)
const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}
const routes = [

  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/Login.vue'),
    meta: {
      title: '登录'
    },
    hidden: true
  },

  {
    path: '/activityInfo',
    component: () => import('@/components/Layout.vue'),
    meta: {
      title: '活动明细信息'
    },
    hidden: false,
    children: [{
      path: "index",
      component: () => import('@/views/activityInfo/index'),
      name: "ActivityInfo",
      meta: {
        title: '活动信息'
      },
    },
    {
      path: 'foodInfo',
      component: () => import('@/views/activityInfo/foodInfo.vue'),
      name: 'foodInfo',
      hidden: true,
      meta: {
        title: '食物明细查询',
        activeMenu: '/activityInfo/foodInfo'
      }
    },
    {
      path: 'moodInfo',
      component: () => import('@/views/activityInfo/moodInfo.vue'),
      name: 'moodInfo',
      hidden: true,
      meta: {
        title: '心情明细查询',
        activeMenu: '/activityInfo/moodInfo'
      }
    },
    {
      path: 'AnimalInfo',
      component: () => import('@/views/activityInfo/animalInfo.vue'),
      name: 'AnimalInfo',
      hidden: true,
      meta: {
        title: '用户明细查询',
        activeMenu: '/activityInfo/animalInfo'
      }
    },
    {
      path: 'PrizeInfo',
      component: () => import('@/views/activityInfo/prizeInfo.vue'),
      name: 'PrizeInfo',
      hidden: true,
      meta: {
        title: '奖品明细查询',
        activeMenu: '/activityInfo/prizeInfo'
      }
    },
    ],
  },


  {
    path: '/activity',
    component: () => import('@/components/Layout.vue'),
    meta: {
      title: '宠物管理'
    },
    hidden: false,
    children: [{
        path: "index",
        component: () => import('@/views/activity/index'),
        name: "activityList",
        meta: {
          title: '宠物管理'
        },
      }

    ]
  },
  {
    path: '/interest',
    component: () => import('@/components/Layout.vue'),
    meta: {
      title: '话费券管理'
    },
    hidden: false,
    children: [{
        path: "index",
        component: () => import('@/views/interest/index'),
        name: "interestMan",
        meta: {
          title: '话费管理'
        }
      }
    ]
    },
    {
      path: '/task',
      component: () => import('@/components/Layout.vue'),
      meta: {
        title: '任务管理'
      },
      hidden: false,
      children: [{
          path: "index",
          component: () => import('@/views/task/index'),
          name: "task",
          meta: {
            title: '任务管理'
          }
        }
      ]
      },
 // interestroute,
 // activityInfoRouter,
]
const router = new VueRouter({
  // mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
