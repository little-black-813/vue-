export const activityInfoRouter = {
  path: '/activityInfo',
  component: () => import('@/components/Layout.vue'),
  meta: {
    title: '活动明细信息'
  },
  hidden: false,
  children: [{
    path: "index",
    component: () => import('@/views/activityInfo/index'),
    name: "ActivityInfo",
    meta: {
      title: '活动信息'
    },
  },
  {
    path: 'foodInfo',
    component: () => import('@/views/activityInfo/foodInfo.vue'),
    name: 'foodInfo',
    hidden: true,
    meta: {
      title: '食物明细查询',
      activeMenu: '/activityInfo/foodInfo'
    }
  },
  {
    path: 'moodInfo',
    component: () => import('@/views/activityInfo/moodInfo.vue'),
    name: 'moodInfo',
    hidden: true,
    meta: {
      title: '心情明细查询',
      activeMenu: '/activityInfo/moodInfo'
    }
  },
  {
    path: 'AnimalInfo',
    component: () => import('@/views/activityInfo/animalInfo.vue'),
    name: 'AnimalInfo',
    hidden: true,
    meta: {
      title: '用户明细查询',
      activeMenu: '/activityInfo/animalInfo'
    }
  },
  ],
};
