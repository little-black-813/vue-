import axios from 'axios'
import router from '@/router'
import {
  Notification,
  Message
} from 'element-ui'
// 根据环境不同引入不同api地址
import store from '@/store'
import { judgePath } from '@/utils/utils';
const path = judgePath();
const request = axios.create({
  baseURL: '',
  withCredentials:true,
  crossDomain:true
})
// 拦截器
request.interceptors.request.use(
  config => {
    if(process.env.NODE_ENV!=='development'){
          config.baseURL = judgePath()+ '/manager/api'; 
    }else{
        config.baseURL = judgePath();
    }
    // store.dispatch('setLoading', true);
    if (config.method.toLowerCase() === 'post') {
      config.headers['Content-Type'] = 'application/json;charset=utf-8;'
    }
    if (localStorage.getItem('Authorization')) {
      config.headers.Authorization = localStorage.getItem('Authorization');
    }
    return config
  },
  error => {
    // do something with request error
    return Promise.reject(error)
  }
)
// response拦截器
request.interceptors.response.use(response => {
  let _this = this
  // store.dispatch('setLoading', false);
  const res = response.data;
  // 流文件直接返回
  if(!!res.size){
    return res
  }
  if (res.code ==='200' || res.success==='true') {
    return res;
  }
  Message({
    showClose: true,
    message: `${res.message || res.mess || res.msg }`,
    type: 'error'
  });
  return Promise.reject('err')
}, err => {
  // store.dispatch('setLoading', false);
  err.message = '网络错误，请稍后再试'
  if (err && err.response) {
    switch (err.response.status) {
      case 401:
        localStorage.removeItem('Authorization')
        //console.log(err.response.data.msg)
        err.message = err.response.data.msg
        router.push('/login');
        break
      case 400:
        err.message = '请求错误'
        break
      case 403:
        err.message = '拒绝访问'
        break
      case 404:
        err.message = `请求地址出错: ${err.response.config.url}`
        break
      case 405:
        err.message = '请求地址出错:'
        break
      case 408:
        err.message = '请求超时'
        break
      case 500:
        err.message = '网络错误，请稍后再试'
        break
      case 501:
        err.message = '网络错误，请稍后再试'
        break

      case 502:
        err.message = '网络错误，请稍后再试'
        break

      case 503:
        err.message = '网络错误，请稍后再试'
        break

      case 504:
        err.message = '网络错误，请稍后再试'
        break

      case 505:
        err.message = 'HTTP版本不受支持'
        break

      default:
    }
  }
  Notification.error({
    title: '错误信息',
    message: `${err.message}`
  });
  // Toast(err.message)
  return Promise.reject(err)
})
export default request
