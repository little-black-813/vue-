// 本地
module.exports = {
  title: '活动管理系统',
  baseApi: '',// 本地api请求地址,注意：如果你使用了代理，请设置成'/'
  baseWechatUrl: '',
  // baseWechatUrl:`${document.location.protocol}//wechat.jxydzx.cn/chinamobile/hollycrm`,
  baseUploadUrl:'https://wechat.jxydzx.cn/chinamobile/hollycrm/testLottery/api',
  // baseUploadUrl: 'http://192.168.11.177:7109',
  baseImgPath:'',
  baseImgPath:'/img/'
}
