import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import './plugins/element.js'
import clipboard from 'vue-clipboard2';
import  'element-ui/lib/theme-chalk/index.css'
import './assets/css/icon.css';
Vue.config.productionTip = false
Vue.use(clipboard)

const whitRoute = ['Login'];

router.beforeEach((to, from, next) => {
  if (to.path === '/login') {
    next();
  }else{
    let token = localStorage.getItem('Authorization');
    if (token === null || token === '') {
      next('/login');
    } else {
      next();
    }
  }
   
})

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
